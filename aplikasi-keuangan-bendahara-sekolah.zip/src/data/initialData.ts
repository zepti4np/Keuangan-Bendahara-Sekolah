import { CategoryData, SchoolProfile, Transaction } from '../types';

export const DEFAULT_SCHOOL_PROFILE: SchoolProfile = {
  namaSekolah: 'SMK NEGERI 1 JAKARTA',
  alamat: 'Jl. Budi Utomo No. 7, Pasar Baru, Sawah Besar',
  kota: 'Jakarta Pusat',
  kotaProvinsi: 'Kota Jakarta Pusat, DKI Jakarta 10710',
  telepon: '(021) 3813630 / (021) 3441829',
  email: 'info@smkn1jakarta.sch.id',
  kepalaSekolah: 'Drs. H. Bambang Suherman, M.Pd.',
  nipKepalaSekolah: '19680512 199403 1 004',
  bendahara: 'Hj. Ratna Sari, S.E.',
  nipBendahara: '19750918 200212 2 003'
};

export const DEFAULT_CATEGORIES: CategoryData = {
  'Saldo Awal': [
    'Saldo Kas Utama (Tunai)',
    'Saldo Rekening Bank (BCA/Bank DKI)',
    'Saldo Kas Kecil (Petty Cash)',
    'Saldo Sisa Dana BOS Tahap I'
  ],
  'Pemasukan': [
    'Dana BOS Regular',
    'SPP Kelas X',
    'SPP Kelas XI',
    'SPP Kelas XII',
    'Paket Kelas X',
    'Paket Kelas XI',
    'Paket Kelas XII',
    'Seragam & Atribut Sekolah',
    'Buku Paket & Modul Pembelajaran',
    'Dana Ujian & Praktikum Siswa',
    'Bantuan Pemda / BOSDA',
    'Donasi / Hibah Alumni & Sponsor',
    'Pendapatan Kantin & Koperasi Sekolah'
  ],
  'Pengeluaran': [
    'Biaya Pendidik & Tenaga Kependidikan',
    'Gaji & Honorarium Guru / Staf GTT',
    'Operasional Kantor & Alat Tulis (ATK)',
    'Tagihan Listrik, Air & WiFi Internet',
    'Pemeliharaan Sarpras & Bangunan',
    'Kegiatan Ekstrakurikuler & OSIS',
    'Bahan Praktikum Lab & Bengkel',
    'Konsumsi Rapat & Tamu Sekolah',
    'Transportasi & Perjalanan Dinas',
    'Biaya Kebersihan & Keamanan',
    'Administrasi Bank & Pajak'
  ],
  'Mutasi Kas': [
    'Penarikan Tunai dari Bank',
    'Penyetoran Tunai ke Bank',
    'Transfer antar Rekening Sekolah',
    'Pengisian Kas Kecil Bendahara'
  ]
};

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'TX-2026-0701',
    tanggal: '2026-07-01',
    jenis: 'Saldo Awal',
    kategori: 'Saldo Rekening Bank (BCA/Bank DKI)',
    uraian: 'Saldo Awal Rekening Bank Sekolah Bulan Juli 2026',
    pemasukan: 45000000,
    pengeluaran: 0,
    pihak: 'Bank DKI Cabang Juanda',
    nomorBukti: 'MEMO/07/2026/01',
    metodePembayaran: 'Transfer Bank',
    createdAt: '2026-07-01T08:00:00Z'
  },
  {
    id: 'TX-2026-0702',
    tanggal: '2026-07-01',
    jenis: 'Saldo Awal',
    kategori: 'Saldo Kas Utama (Tunai)',
    uraian: 'Saldo Awal Kas Tunai Bendahara Sekolah Bulan Juli 2026',
    pemasukan: 5000000,
    pengeluaran: 0,
    pihak: 'Kas Bendahara',
    nomorBukti: 'MEMO/07/2026/02',
    metodePembayaran: 'Tunai / Kas',
    createdAt: '2026-07-01T08:15:00Z'
  },
  {
    id: 'TX-2026-0705',
    tanggal: '2026-07-05',
    jenis: 'Pemasukan',
    kategori: 'Dana BOS Regular',
    uraian: 'Pencairan Dana BOS Regular Tahap II Tahun 2026',
    pemasukan: 75000000,
    pengeluaran: 0,
    pihak: 'Dinas Pendidikan DKI Jakarta',
    nomorBukti: 'BKM/07/2026/01',
    metodePembayaran: 'Transfer Bank',
    createdAt: '2026-07-05T10:30:00Z'
  },
  {
    id: 'TX-2026-0708',
    tanggal: '2026-07-08',
    jenis: 'Pemasukan',
    kategori: 'SPP / Sumbangan Pembinaan Pendidikan',
    uraian: 'Penerimaan SPP Kolektif Siswa Kelas X, XI & XII Bulan Juli',
    pemasukan: 18500000,
    pengeluaran: 0,
    pihak: 'Orang Tua / Wali Siswa',
    nomorBukti: 'BKM/07/2026/02',
    metodePembayaran: 'Tunai / Kas',
    createdAt: '2026-07-08T13:00:00Z'
  },
  {
    id: 'TX-2026-0710',
    tanggal: '2026-07-10',
    jenis: 'Pengeluaran',
    kategori: 'Gaji & Honorarium Guru / Staf GTT',
    uraian: 'Pembayaran Honorarium 15 Guru Tidak Tetap (GTT) & Staf Juli 2026',
    pemasukan: 0,
    pengeluaran: 24500000,
    pihak: 'Daftar Penerima Honor GTT',
    nomorBukti: 'BKK/07/2026/01',
    metodePembayaran: 'Transfer Bank',
    createdAt: '2026-07-10T09:00:00Z'
  },
  {
    id: 'TX-2026-0712',
    tanggal: '2026-07-12',
    jenis: 'Pengeluaran',
    kategori: 'Operasional Kantor & Alat Tulis (ATK)',
    uraian: 'Pembelian Kertas HVS, Tinta Printer, Amplop & Alat Tulis Kantor Tahun Ajaran Baru',
    pemasukan: 0,
    pengeluaran: 3450000,
    pihak: 'CV Utama Jaya Stationer',
    nomorBukti: 'BKK/07/2026/02',
    metodePembayaran: 'Tunai / Kas',
    createdAt: '2026-07-12T11:20:00Z'
  },
  {
    id: 'TX-2026-0715',
    tanggal: '2026-07-15',
    jenis: 'Pengeluaran',
    kategori: 'Tagihan Listrik, Air & WiFi Internet',
    uraian: 'Pembayaran Tagihan Listrik PLN & Internet Dedicated Sekolah Bulan Juli',
    pemasukan: 0,
    pengeluaran: 6800000,
    pihak: 'PT PLN & Telkom Indonesia',
    nomorBukti: 'BKK/07/2026/03',
    metodePembayaran: 'Transfer Bank',
    createdAt: '2026-07-15T14:10:00Z'
  },
  {
    id: 'TX-2026-0718',
    tanggal: '2026-07-18',
    jenis: 'Pengeluaran',
    kategori: 'Pemeliharaan Sarpras & Bangunan',
    uraian: 'Perbaikan AC Ruang Komputer & Servis Proyektor Laboratorium',
    pemasukan: 0,
    pengeluaran: 4200000,
    pihak: 'Teknik Jaya AC & Servis',
    nomorBukti: 'BKK/07/2026/04',
    metodePembayaran: 'Tunai / Kas',
    createdAt: '2026-07-18T10:00:00Z'
  },
  {
    id: 'TX-2026-0722',
    tanggal: '2026-07-22',
    jenis: 'Pengeluaran',
    kategori: 'Kegiatan Ekstrakurikuler & OSIS',
    uraian: 'Dana Kegiatan Masa Pengenalan Lingkungan Sekolah (MPLS) 2026',
    pemasukan: 0,
    pengeluaran: 5500000,
    pihak: 'Panitia MPLS / Pembina OSIS',
    nomorBukti: 'BKK/07/2026/05',
    metodePembayaran: 'Tunai / Kas',
    createdAt: '2026-07-22T08:30:00Z'
  },
  {
    id: 'TX-2026-0725',
    tanggal: '2026-07-25',
    jenis: 'Pemasukan',
    kategori: 'Seragam & Atribut Sekolah',
    uraian: 'Pembayaran Seragam Batik, Olahraga & Atribut Peserta Didik Baru',
    pemasukan: 14200000,
    pengeluaran: 0,
    pihak: 'Koperasi & Orang Tua Siswa Baru',
    nomorBukti: 'BKM/07/2026/03',
    metodePembayaran: 'Tunai / Kas',
    createdAt: '2026-07-25T11:00:00Z'
  },
  {
    id: 'TX-2026-0728',
    tanggal: '2026-07-28',
    jenis: 'Pengeluaran',
    kategori: 'Bahan Praktikum Lab & Bengkel',
    uraian: 'Pembelian Komponen Alat Praktikum Teknik Komputer & Jaringan',
    pemasukan: 0,
    pengeluaran: 8900000,
    pihak: 'Toko Elektronik Komputer',
    nomorBukti: 'BKK/07/2026/06',
    metodePembayaran: 'Transfer Bank',
    createdAt: '2026-07-28T15:00:00Z'
  }
];
