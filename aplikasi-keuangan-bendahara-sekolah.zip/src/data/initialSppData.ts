import { Student, SppPayment, AnnualFeePayment } from '../types';

export const INITIAL_STUDENTS: Student[] = [
  {
    id: 'STU-001',
    nisn: '0051234001',
    nama: 'Ahmad Rizky Pratama',
    kelas: 'X IPA 1',
    nominalSppBulanan: 200000,
    nominalTagihanTahunan: 1500000,
    keterangan: 'Regular'
  },
  {
    id: 'STU-002',
    nisn: '0051234002',
    nama: 'Siti Nurhaliza',
    kelas: 'X IPA 1',
    nominalSppBulanan: 200000,
    nominalTagihanTahunan: 1500000,
    keterangan: 'Regular'
  },
  {
    id: 'STU-003',
    nisn: '0051234003',
    nama: 'Budi Santoso',
    kelas: 'X IPS 2',
    nominalSppBulanan: 150000,
    nominalTagihanTahunan: 1200000,
    keterangan: 'Keringanan Yatim'
  },
  {
    id: 'STU-004',
    nisn: '0051234004',
    nama: 'Dewi Anggraini',
    kelas: 'XI IPA 1',
    nominalSppBulanan: 250000,
    nominalTagihanTahunan: 1800000,
    keterangan: 'Regular'
  },
  {
    id: 'STU-005',
    nisn: '0051234005',
    nama: 'Muhammad Fadil',
    kelas: 'XI IPS 1',
    nominalSppBulanan: 100000,
    nominalTagihanTahunan: 1000000,
    keterangan: 'Beasiswa Prestasi'
  },
  {
    id: 'STU-006',
    nisn: '0051234006',
    nama: 'Anisa Rahmawati',
    kelas: 'XII IPA',
    nominalSppBulanan: 250000,
    nominalTagihanTahunan: 2000000,
    keterangan: 'Regular'
  }
];

export const INITIAL_SPP_PAYMENTS: SppPayment[] = [
  {
    id: 'SPP-PAY-001',
    studentId: 'STU-001',
    year: 2026,
    month: 1, // Jan
    nominalDibayar: 200000,
    tanggalBayar: '2026-01-10',
    metodePembayaran: 'Tunai / Kas',
    catatan: 'Lunas SPP Jan'
  },
  {
    id: 'SPP-PAY-002',
    studentId: 'STU-001',
    year: 2026,
    month: 2, // Feb
    nominalDibayar: 200000,
    tanggalBayar: '2026-02-08',
    metodePembayaran: 'Transfer Bank',
    catatan: 'Lunas SPP Feb'
  },
  {
    id: 'SPP-PAY-003',
    studentId: 'STU-002',
    year: 2026,
    month: 1, // Jan
    nominalDibayar: 200000,
    tanggalBayar: '2026-01-12',
    metodePembayaran: 'Tunai / Kas',
    catatan: 'Lunas SPP Jan'
  },
  {
    id: 'SPP-PAY-004',
    studentId: 'STU-003',
    year: 2026,
    month: 1, // Jan
    nominalDibayar: 150000,
    tanggalBayar: '2026-01-15',
    metodePembayaran: 'Tunai / Kas',
    catatan: 'Lunas SPP Jan'
  },
  {
    id: 'SPP-PAY-005',
    studentId: 'STU-004',
    year: 2026,
    month: 1, // Jan
    nominalDibayar: 250000,
    tanggalBayar: '2026-01-05',
    metodePembayaran: 'Transfer Bank',
    catatan: 'Lunas SPP Jan'
  }
];

export const INITIAL_ANNUAL_PAYMENTS: AnnualFeePayment[] = [
  {
    id: 'ANN-PAY-001',
    studentId: 'STU-001',
    year: 2026,
    namaTagihan: 'Tagihan Tahunan 2026',
    nominalDibayar: 1000000,
    tanggalBayar: '2026-01-10',
    metodePembayaran: 'Transfer Bank',
    catatan: 'Cicilan Ke-1 Tagihan Tahunan'
  },
  {
    id: 'ANN-PAY-002',
    studentId: 'STU-002',
    year: 2026,
    namaTagihan: 'Tagihan Tahunan 2026',
    nominalDibayar: 1500000,
    tanggalBayar: '2026-01-12',
    metodePembayaran: 'Tunai / Kas',
    catatan: 'Pelunasan Tagihan Tahunan'
  }
];
