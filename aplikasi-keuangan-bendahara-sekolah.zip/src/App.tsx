import React, { useState, useEffect, useMemo } from 'react';
import { PlusCircle } from 'lucide-react';
import { User } from 'firebase/auth';
import { 
  Transaction, 
  SchoolProfile, 
  CategoryData, 
  TransactionType,
  Student,
  SppPayment,
  AnnualFeePayment
} from './types';
import { 
  DEFAULT_SCHOOL_PROFILE, 
  DEFAULT_CATEGORIES, 
  INITIAL_TRANSACTIONS 
} from './data/initialData';
import { 
  INITIAL_STUDENTS, 
  INITIAL_SPP_PAYMENTS, 
  INITIAL_ANNUAL_PAYMENTS 
} from './data/initialSppData';
import { exportTransactionsToCSV, generateNomorBukti, renumberAllTransactions } from './utils/formatters';
import { exportTransactionsToExcel } from './utils/excelUtils';
import { downloadBackupJSON, BackupData } from './utils/backupUtils';

import { Navbar } from './components/Navbar';
import { StatCard } from './components/StatCard';
import { TransactionForm } from './components/TransactionForm';
import { TransactionList } from './components/TransactionList';
import { MonthlyReportView } from './components/MonthlyReportView';
import { AnalyticsView } from './components/AnalyticsView';
import { CategoryManager } from './components/CategoryManager';
import { SppManagerView } from './components/SppManagerView';
import { RealDailyTransactionView } from './components/RealDailyTransactionView';
import { KwitansiModal } from './components/KwitansiModal';
import { SettingsModal } from './components/SettingsModal';
import { BackupRestoreModal } from './components/BackupRestoreModal';
import { ExcelImportModal } from './components/ExcelImportModal';
import { GoogleSheetSyncModal } from './components/GoogleSheetSyncModal';
import { AuthModal } from './components/AuthModal';
import { initAuthListener, getAccessToken } from './services/firebaseAuth';
import { 
  subscribeTransactions, 
  saveTransactionToCloud, 
  deleteTransactionFromCloud, 
  bulkSaveTransactionsToCloud,
  subscribeSchoolProfile,
  saveSchoolProfileToCloud,
  subscribeCategories,
  saveCategoriesToCloud,
  subscribeStudents,
  bulkSaveStudentsToCloud,
  saveStudentToCloud,
  deleteStudentFromCloud,
  subscribeSppPayments,
  bulkSaveSppPaymentsToCloud,
  saveSppPaymentToCloud,
  deleteSppPaymentFromCloud,
  subscribeAnnualPayments,
  bulkSaveAnnualPaymentsToCloud,
  saveAnnualPaymentToCloud,
  deleteAnnualPaymentFromCloud
} from './services/firestoreService';
import { appendTransactionToSheet, DEFAULT_SPREADSHEET_ID } from './services/googleSheets';

export default function App() {
  // LocalStorage Persistence Keys
  const STORAGE_KEY_TX = 'bendahara_transactions_v1';
  const STORAGE_KEY_SCHOOL = 'bendahara_school_profile_v1';
  const STORAGE_KEY_CAT = 'bendahara_categories_v1';
  const STORAGE_KEY_AUTOSYNC = 'bendahara_autosync_sheets_v1';
  const STORAGE_KEY_STUDENTS = 'bendahara_students_v1';
  const STORAGE_KEY_SPP_PAY = 'bendahara_spp_payments_v1';
  const STORAGE_KEY_ANNUAL_PAY = 'bendahara_annual_payments_v1';

  // Auth State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthOpen, setIsAuthOpen] = useState<boolean>(false);

  // State: Transactions
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_TX);
      if (saved) {
        const parsed: Transaction[] = JSON.parse(saved);
        return renumberAllTransactions(parsed);
      }
    } catch (err) {
      console.error('Failed to load transactions from localStorage', err);
    }
    return renumberAllTransactions(INITIAL_TRANSACTIONS);
  });

  // State: School Profile
  const [schoolProfile, setSchoolProfile] = useState<SchoolProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SCHOOL);
      if (saved) return JSON.parse(saved);
    } catch (err) {
      console.error('Failed to load school profile', err);
    }
    return DEFAULT_SCHOOL_PROFILE;
  });

  // State: Category Data
  const [categoryData, setCategoryData] = useState<CategoryData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CAT);
      if (saved) return JSON.parse(saved);
    } catch (err) {
      console.error('Failed to load categories', err);
    }
    return DEFAULT_CATEGORIES;
  });

  // State: SPP Students
  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_STUDENTS);
      if (saved) return JSON.parse(saved);
    } catch (err) {
      console.error('Failed to load students', err);
    }
    return INITIAL_STUDENTS;
  });

  // State: SPP Payments
  const [sppPayments, setSppPayments] = useState<SppPayment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SPP_PAY);
      if (saved) return JSON.parse(saved);
    } catch (err) {
      console.error('Failed to load SPP payments', err);
    }
    return INITIAL_SPP_PAYMENTS;
  });

  // State: Annual Payments
  const [annualPayments, setAnnualPayments] = useState<AnnualFeePayment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ANNUAL_PAY);
      if (saved) return JSON.parse(saved);
    } catch (err) {
      console.error('Failed to load annual payments', err);
    }
    return INITIAL_ANNUAL_PAYMENTS;
  });

  // LocalStorage Effects
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_TX, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_STUDENTS, JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_SPP_PAY, JSON.stringify(sppPayments));
  }, [sppPayments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_ANNUAL_PAY, JSON.stringify(annualPayments));
  }, [annualPayments]);

  // State: UI Views & Modals
  const [activeTab, setActiveTab] = useState<'dashboard' | 'spp' | 'real-daily' | 'laporan' | 'analytics' | 'categories'>('dashboard');
  const [isFormOpen, setIsFormOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isBackupRestoreOpen, setIsBackupRestoreOpen] = useState<boolean>(false);
  const [isExcelImportOpen, setIsExcelImportOpen] = useState<boolean>(false);
  const [isGoogleSheetModalOpen, setIsGoogleSheetModalOpen] = useState<boolean>(false);
  const [selectedKwitansi, setSelectedKwitansi] = useState<Transaction | null>(null);
  
  const [autoSyncEnabled, setAutoSyncEnabled] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_AUTOSYNC);
      return saved ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  // 1. Firebase Auth Listener
  useEffect(() => {
    const unsub = initAuthListener((user) => {
      setCurrentUser(user);
    });
    return () => unsub();
  }, []);

  // Helper checks for default initial sample data
  const isDefaultTx = (txs: Transaction[]) => {
    if (txs.length === 0) return true;
    if (txs.length === INITIAL_TRANSACTIONS.length) {
      const initialIds = INITIAL_TRANSACTIONS.map(t => t.id);
      return txs.every(t => initialIds.includes(t.id));
    }
    return false;
  };

  const isDefaultStudents = (stdList: Student[]) => {
    if (stdList.length === 0) return true;
    if (stdList.length === INITIAL_STUDENTS.length) {
      const initialIds = INITIAL_STUDENTS.map(s => s.id);
      return stdList.every(s => initialIds.includes(s.id));
    }
    return false;
  };

  // Helper to manually sync all local data to Cloud
  const handleSyncLocalToCloud = async () => {
    if (!currentUser) throw new Error('Silakan login akun Cloud terlebih dahulu');
    const uid = currentUser.uid;
    await bulkSaveTransactionsToCloud(uid, transactions);
    await saveSchoolProfileToCloud(uid, schoolProfile);
    await saveCategoriesToCloud(uid, categoryData);
    await bulkSaveStudentsToCloud(uid, students);
    await bulkSaveSppPaymentsToCloud(uid, sppPayments);
    await bulkSaveAnnualPaymentsToCloud(uid, annualPayments);
  };

  // 2. Real-time Firestore Sync when logged in
  useEffect(() => {
    if (!currentUser) return;

    const uid = currentUser.uid;

    // Subscribe to transactions
    const unsubTx = subscribeTransactions(uid, (cloudTxs) => {
      if (cloudTxs.length > 0) {
        const renumbered = renumberAllTransactions(cloudTxs);
        setTransactions(renumbered);
        // Check if any transaction's nomorBukti was updated during renumbering
        const needsUpdate = cloudTxs.some((t, i) => t.nomorBukti !== renumbered[i]?.nomorBukti);
        if (needsUpdate) {
          bulkSaveTransactionsToCloud(uid, renumbered, true).catch(err => {
            console.error('Failed writing renumbered transactions back to Firestore:', err);
          });
        }
      } else if (!isDefaultTx(transactions)) {
        // Upload custom local transactions if user created them before logging in
        const renumbered = renumberAllTransactions(transactions);
        bulkSaveTransactionsToCloud(uid, renumbered, true);
      } else {
        // If cloud is empty and local is just dummy sample data, clear sample data
        setTransactions([]);
      }
    });

    // Subscribe to school profile
    const unsubSchool = subscribeSchoolProfile(uid, (cloudProfile) => {
      if (cloudProfile && cloudProfile.namaSekolah) {
        setSchoolProfile(cloudProfile);
      } else if (schoolProfile.namaSekolah && schoolProfile.namaSekolah !== DEFAULT_SCHOOL_PROFILE.namaSekolah) {
        saveSchoolProfileToCloud(uid, schoolProfile);
      }
    });

    // Subscribe to categories
    const unsubCat = subscribeCategories(uid, (cloudCat) => {
      if (cloudCat && cloudCat['Pemasukan']) {
        setCategoryData(cloudCat);
      } else {
        saveCategoriesToCloud(uid, categoryData);
      }
    });

    // Subscribe to students
    const unsubStudents = subscribeStudents(uid, (cloudStudents) => {
      if (cloudStudents.length > 0) {
        setStudents(cloudStudents);
      } else if (!isDefaultStudents(students)) {
        bulkSaveStudentsToCloud(uid, students);
      } else {
        setStudents([]);
      }
    });

    // Subscribe to SPP payments
    const unsubSpp = subscribeSppPayments(uid, (cloudSpp) => {
      if (cloudSpp.length > 0) {
        setSppPayments(cloudSpp);
      } else if (sppPayments.length > 0 && !isDefaultTx(transactions)) {
        bulkSaveSppPaymentsToCloud(uid, sppPayments);
      } else if (cloudSpp.length === 0 && isDefaultTx(transactions)) {
        setSppPayments([]);
      }
    });

    // Subscribe to Annual payments
    const unsubAnnual = subscribeAnnualPayments(uid, (cloudAnnual) => {
      if (cloudAnnual.length > 0) {
        setAnnualPayments(cloudAnnual);
      } else if (annualPayments.length > 0 && !isDefaultTx(transactions)) {
        bulkSaveAnnualPaymentsToCloud(uid, annualPayments);
      } else if (cloudAnnual.length === 0 && isDefaultTx(transactions)) {
        setAnnualPayments([]);
      }
    });

    return () => {
      unsubTx();
      unsubSchool();
      unsubCat();
      unsubStudents();
      unsubSpp();
      unsubAnnual();
    };
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_AUTOSYNC, JSON.stringify(autoSyncEnabled));
  }, [autoSyncEnabled]);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_TX, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_SCHOOL, JSON.stringify(schoolProfile));
  }, [schoolProfile]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_CAT, JSON.stringify(categoryData));
  }, [categoryData]);

  // Filtered transactions that are synced to Dashboard & main reports
  const mainTransactions = useMemo(() => {
    return transactions.filter(t => t.syncedToDashboard !== false);
  }, [transactions]);

  // Calculated Financial Metrics
  const { totalPemasukan, totalPengeluaran, totalSaldo, saldoTunai, saldoBank } = useMemo(() => {
    let masuk = 0;
    let keluar = 0;
    let tunai = 0;
    let bank = 0;

    mainTransactions.forEach(t => {
      masuk += t.pemasukan || 0;
      keluar += t.pengeluaran || 0;

      const isCash = !t.metodePembayaran || t.metodePembayaran === 'Tunai / Kas';
      if (isCash) {
        tunai += (t.pemasukan || 0) - (t.pengeluaran || 0);
      } else {
        bank += (t.pemasukan || 0) - (t.pengeluaran || 0);
      }
    });

    const saldo = masuk - keluar;
    return {
      totalPemasukan: masuk,
      totalPengeluaran: keluar,
      totalSaldo: saldo,
      saldoTunai: tunai,
      saldoBank: bank
    };
  }, [mainTransactions]);

  // Save New Transaction
  const handleSaveTransaction = async (newTxData: Omit<Transaction, 'id' | 'createdAt'>) => {
    const nomorBukti = newTxData.nomorBukti || generateNomorBukti(newTxData.jenis, transactions, newTxData.tanggal);
    const newTx: Transaction = {
      ...newTxData,
      nomorBukti,
      id: `TX-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    
    let renumberedList: Transaction[] = [];
    setTransactions(prev => {
      const updated = [newTx, ...prev];
      renumberedList = renumberAllTransactions(updated);
      return renumberedList;
    });
    setIsFormOpen(false);

    // Sync to Firestore Cloud if logged in
    if (currentUser) {
      bulkSaveTransactionsToCloud(currentUser.uid, renumberedList, true).catch(err => {
        console.error('Failed saving transactions to Firestore:', err);
      });
    }

    // Auto-sync to Google Sheets if token available & autoSync enabled
    if (autoSyncEnabled) {
      const token = getAccessToken();
      if (token) {
        try {
          await appendTransactionToSheet(token, newTx, DEFAULT_SPREADSHEET_ID);
          console.log('Transaction auto-synced to Google Sheet!');
        } catch (err) {
          console.error('Failed auto-syncing transaction to Google Sheet', err);
        }
      }
    }
  };

  // Update Transaction
  const handleUpdateTransaction = async (updatedTx: Transaction) => {
    let renumberedList: Transaction[] = [];
    setTransactions(prev => {
      const updated = prev.map(t => t.id === updatedTx.id ? updatedTx : t);
      renumberedList = renumberAllTransactions(updated);
      return renumberedList;
    });

    if (currentUser) {
      bulkSaveTransactionsToCloud(currentUser.uid, renumberedList, true).catch(err => {
        console.error('Failed updating transaction in Firestore:', err);
      });
    }
  };

  // Delete Transaction
  const handleDeleteTransaction = (id: string) => {
    let renumberedList: Transaction[] = [];
    setTransactions(prev => {
      const filtered = prev.filter(t => t.id !== id);
      renumberedList = renumberAllTransactions(filtered);
      return renumberedList;
    });
    if (currentUser) {
      deleteTransactionFromCloud(currentUser.uid, id).catch(err => {
        console.error('Failed deleting transaction from Firestore:', err);
      });
      bulkSaveTransactionsToCloud(currentUser.uid, renumberedList, true).catch(err => {
        console.error('Failed re-syncing transactions after deletion:', err);
      });
    }
  };

  // Reset to Sample Data
  const handleResetData = () => {
    if (window.confirm('Reset aplikasi ke data sampel default Bendahara Sekolah?')) {
      setTransactions(INITIAL_TRANSACTIONS);
      setSchoolProfile(DEFAULT_SCHOOL_PROFILE);
      setCategoryData(DEFAULT_CATEGORIES);
      setStudents(INITIAL_STUDENTS);
      setSppPayments(INITIAL_SPP_PAYMENTS);
      setAnnualPayments(INITIAL_ANNUAL_PAYMENTS);
      localStorage.removeItem(STORAGE_KEY_TX);
      localStorage.removeItem(STORAGE_KEY_SCHOOL);
      localStorage.removeItem(STORAGE_KEY_CAT);
      localStorage.removeItem(STORAGE_KEY_STUDENTS);
      localStorage.removeItem(STORAGE_KEY_SPP_PAY);
      localStorage.removeItem(STORAGE_KEY_ANNUAL_PAY);

      if (currentUser) {
        bulkSaveTransactionsToCloud(currentUser.uid, INITIAL_TRANSACTIONS, true);
        saveSchoolProfileToCloud(currentUser.uid, DEFAULT_SCHOOL_PROFILE);
        saveCategoriesToCloud(currentUser.uid, DEFAULT_CATEGORIES);
      }
    }
  };

  // SPP & Student Operations
  const handleSaveStudent = (student: Student) => {
    setStudents(prev => {
      const exists = prev.some(s => s.id === student.id);
      let updated: Student[];
      if (exists) {
        updated = prev.map(s => s.id === student.id ? student : s);
      } else {
        updated = [student, ...prev];
      }
      return updated.sort((a, b) => a.nama.localeCompare(b.nama, 'id', { sensitivity: 'base' }));
    });

    if (currentUser) {
      saveStudentToCloud(currentUser.uid, student);
    }
  };

  const handleImportStudents = (importedStudents: Student[], mode: 'append' | 'overwrite') => {
    let finalStudents: Student[] = [];
    setStudents(prev => {
      if (mode === 'overwrite') {
        finalStudents = importedStudents;
      } else {
        const map = new Map<string, Student>();
        prev.forEach(s => map.set((s.nisn ? s.nisn : s.id).toLowerCase(), s));
        importedStudents.forEach(is => {
          const key = (is.nisn ? is.nisn : is.id).toLowerCase();
          map.set(key, is);
        });
        finalStudents = Array.from(map.values());
      }
      return finalStudents.sort((a, b) => a.nama.localeCompare(b.nama, 'id', { sensitivity: 'base' }));
    });

    if (currentUser && finalStudents.length > 0) {
      bulkSaveStudentsToCloud(currentUser.uid, finalStudents);
    }
  };

  const handleDeleteStudent = (studentId: string) => {
    setStudents(prev => prev.filter(s => s.id !== studentId));
    if (currentUser) {
      deleteStudentFromCloud(currentUser.uid, studentId);
    }
  };

  const formatSppCategory = (kelasStr?: string) => {
    if (!kelasStr) return 'SPP Kelas Siswa';
    const k = kelasStr.trim();
    if (k.toLowerCase().startsWith('spp')) return k;
    if (k.toLowerCase().startsWith('kelas')) return `SPP ${k}`;
    return `SPP Kelas ${k}`;
  };

  const formatPaketCategory = (kelasStr?: string) => {
    if (!kelasStr) return 'Paket Kelas Siswa';
    const k = kelasStr.trim();
    if (k.toLowerCase().startsWith('paket')) return k;
    if (k.toLowerCase().startsWith('kelas')) return `Paket ${k}`;
    return `Paket Kelas ${k}`;
  };

  const handleAddSppPayment = (paymentData: Omit<SppPayment, 'id'> | Omit<SppPayment, 'id'>[], syncToCash: boolean) => {
    const payments = Array.isArray(paymentData) ? paymentData : [paymentData];
    if (payments.length === 0) return;

    const newPayments: SppPayment[] = payments.map((p, idx) => ({
      ...p,
      id: `SPP-PAY-${Date.now()}-${idx}`
    }));

    setSppPayments(prev => {
      const keysToRemove = new Set(payments.map(p => `${p.studentId}-${p.month}-${p.year}`));
      const filtered = prev.filter(p => !keysToRemove.has(`${p.studentId}-${p.month}-${p.year}`));
      return [...filtered, ...newPayments];
    });

    if (currentUser) {
      bulkSaveSppPaymentsToCloud(currentUser.uid, newPayments);
    }

    if (syncToCash) {
      const firstP = payments[0];
      const student = students.find(s => s.id === firstP.studentId);
      const studentName = student ? student.nama : 'Siswa';
      const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
      const sppCat = formatSppCategory(student?.kelas);

      const totalAmount = payments.reduce((sum, p) => sum + p.nominalDibayar, 0);

      // Sort chronologically Juli-Des, Jan-Jun
      payments.sort((a, b) => {
        const orderA = a.month >= 7 ? a.month - 6 : a.month + 6;
        const orderB = b.month >= 7 ? b.month - 6 : b.month + 6;
        return orderA - orderB;
      });

      const sameYear = payments.every(p => p.year === firstP.year);
      let monthText = '';
      if (sameYear) {
        const mNames = payments.map(p => months[p.month - 1] || `Bulan ${p.month}`).join(', ');
        monthText = `${mNames} ${firstP.year}`;
      } else {
        monthText = payments.map(p => `${months[p.month - 1] || `Bulan ${p.month}`} ${p.year}`).join(', ');
      }

      handleSaveTransaction({
        tanggal: firstP.tanggalBayar || new Date().toISOString().slice(0, 10),
        jenis: 'Pemasukan',
        kategori: sppCat,
        uraian: `Pembayaran SPP ${monthText} - ${studentName} (${student?.kelas || ''})`,
        pemasukan: totalAmount,
        pengeluaran: 0,
        pihak: studentName,
        metodePembayaran: firstP.metodePembayaran || 'Tunai / Kas'
      });
    }
  };

  const handleDeleteSppPayment = (id: string) => {
    setSppPayments(prev => prev.filter(p => p.id !== id));
    if (currentUser) {
      deleteSppPaymentFromCloud(currentUser.uid, id);
    }
  };

  const handleAddAnnualPayment = (paymentData: Omit<AnnualFeePayment, 'id'>, syncToCash: boolean) => {
    const newPayment: AnnualFeePayment = {
      ...paymentData,
      id: `ANN-PAY-${Date.now()}`
    };

    setAnnualPayments(prev => [...prev, newPayment]);

    if (currentUser) {
      saveAnnualPaymentToCloud(currentUser.uid, newPayment);
    }

    if (syncToCash) {
      const student = students.find(s => s.id === paymentData.studentId);
      const studentName = student ? student.nama : 'Siswa';
      const paketCat = formatPaketCategory(student?.kelas);

      handleSaveTransaction({
        tanggal: paymentData.tanggalBayar,
        jenis: 'Pemasukan',
        kategori: paketCat,
        uraian: `Pembayaran ${paymentData.namaTagihan || 'Tagihan Tahunan'} - ${studentName} (${student?.kelas || ''})`,
        pemasukan: paymentData.nominalDibayar,
        pengeluaran: 0,
        pihak: studentName,
        metodePembayaran: paymentData.metodePembayaran || 'Tunai / Kas'
      });
    }
  };

  const handleDeleteAnnualPayment = (id: string) => {
    setAnnualPayments(prev => prev.filter(p => p.id !== id));
    if (currentUser) {
      deleteAnnualPaymentFromCloud(currentUser.uid, id);
    }
  };

  // Sync all existing SPP & Annual Fee Payments to Main Cash Transactions
  const handleSyncAllSppToTransactions = () => {
    const months = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    let countAdded = 0;

    const existingDescriptions = new Set(transactions.map(t => t.uraian.trim().toLowerCase()));

    const newTxsToSave: Omit<Transaction, 'id' | 'createdAt'>[] = [];

    // 1. Check SPP Payments (Grouped by studentId + tanggalBayar + year)
    const sppGroups = new Map<string, SppPayment[]>();
    sppPayments.forEach(p => {
      const student = students.find(s => s.id === p.studentId);
      const studentName = student ? student.nama : 'Siswa';
      const monthName = months[p.month - 1] || `Bulan ${p.month}`;
      const descSingle = `pembayaran spp ${monthName.toLowerCase()} ${p.year} - ${studentName.toLowerCase()} (${(student?.kelas || '').toLowerCase()})`;

      if (!existingDescriptions.has(descSingle)) {
        const groupKey = `${p.studentId}_${p.tanggalBayar || 'today'}_${p.year}`;
        if (!sppGroups.has(groupKey)) {
          sppGroups.set(groupKey, []);
        }
        sppGroups.get(groupKey)!.push(p);
      }
    });

    sppGroups.forEach((groupPayments) => {
      if (groupPayments.length === 0) return;
      const firstP = groupPayments[0];
      const student = students.find(s => s.id === firstP.studentId);
      const studentName = student ? student.nama : 'Siswa';

      // Sort group chronologically Juli-Des, Jan-Jun
      groupPayments.sort((a, b) => {
        const orderA = a.month >= 7 ? a.month - 6 : a.month + 6;
        const orderB = b.month >= 7 ? b.month - 6 : b.month + 6;
        return orderA - orderB;
      });

      const totalAmount = groupPayments.reduce((sum, p) => sum + p.nominalDibayar, 0);
      const mNames = groupPayments.map(p => months[p.month - 1] || `Bulan ${p.month}`).join(', ');

      newTxsToSave.push({
        tanggal: firstP.tanggalBayar || new Date().toISOString().slice(0, 10),
        jenis: 'Pemasukan',
        kategori: formatSppCategory(student?.kelas),
        uraian: `Pembayaran SPP ${mNames} ${firstP.year} - ${studentName} (${student?.kelas || ''})`,
        pemasukan: totalAmount,
        pengeluaran: 0,
        pihak: studentName,
        metodePembayaran: firstP.metodePembayaran || 'Tunai / Kas'
      });

      groupPayments.forEach(p => {
        const singleM = months[p.month - 1] || `Bulan ${p.month}`;
        existingDescriptions.add(`pembayaran spp ${singleM.toLowerCase()} ${p.year} - ${studentName.toLowerCase()} (${(student?.kelas || '').toLowerCase()})`);
      });
      countAdded++;
    });

    // 2. Check Annual Payments
    annualPayments.forEach(p => {
      const student = students.find(s => s.id === p.studentId);
      const studentName = student ? student.nama : 'Siswa';
      const tagihanName = p.namaTagihan || 'Tagihan Tahunan';
      const desc = `pembayaran ${tagihanName.toLowerCase()} - ${studentName.toLowerCase()} (${(student?.kelas || '').toLowerCase()})`;

      if (!existingDescriptions.has(desc)) {
        newTxsToSave.push({
          tanggal: p.tanggalBayar || new Date().toISOString().slice(0, 10),
          jenis: 'Pemasukan',
          kategori: formatPaketCategory(student?.kelas),
          uraian: `Pembayaran ${tagihanName} - ${studentName} (${student?.kelas || ''})`,
          pemasukan: p.nominalDibayar,
          pengeluaran: 0,
          pihak: studentName,
          metodePembayaran: p.metodePembayaran || 'Tunai / Kas'
        });
        existingDescriptions.add(desc);
        countAdded++;
      }
    });

    if (newTxsToSave.length > 0) {
      newTxsToSave.forEach(tx => {
        handleSaveTransaction(tx);
      });
      alert(`Berhasil menyinkronkan ${countAdded} data pembayaran SPP & Tagihan Tahunan ke Riwayat Transaksi Utama!`);
    } else {
      alert('Semua pembayaran SPP & Tagihan Tahunan sudah tercatat di Riwayat Transaksi Utama.');
    }
  };

  // Backup & Restore Handlers
  const handleDownloadBackup = () => {
    downloadBackupJSON(
      schoolProfile,
      categoryData,
      transactions,
      students,
      sppPayments,
      annualPayments
    );
  };

  const handleRestoreBackup = (backup: BackupData, mode: 'overwrite' | 'merge') => {
    if (mode === 'overwrite') {
      if (backup.schoolProfile && backup.schoolProfile.namaSekolah) {
        setSchoolProfile(backup.schoolProfile);
      }
      if (backup.categoryData && backup.categoryData['Pemasukan']) {
        setCategoryData(backup.categoryData);
      }
      const renumberedTxs = renumberAllTransactions(backup.transactions || []);
      setTransactions(renumberedTxs);
      setStudents(backup.students || []);
      setSppPayments(backup.sppPayments || []);
      setAnnualPayments(backup.annualPayments || []);

      if (currentUser) {
        if (backup.schoolProfile) saveSchoolProfileToCloud(currentUser.uid, backup.schoolProfile);
        if (backup.categoryData) saveCategoriesToCloud(currentUser.uid, backup.categoryData);
        bulkSaveTransactionsToCloud(currentUser.uid, renumberedTxs, true);
        bulkSaveStudentsToCloud(currentUser.uid, backup.students || []);
        bulkSaveSppPaymentsToCloud(currentUser.uid, backup.sppPayments || []);
        bulkSaveAnnualPaymentsToCloud(currentUser.uid, backup.annualPayments || []);
      }
    } else {
      // Merge mode
      if (backup.schoolProfile?.namaSekolah) {
        setSchoolProfile(backup.schoolProfile);
      }
      // Merge transactions by ID and renumber
      let renumberedTxs: Transaction[] = [];
      setTransactions(prev => {
        const map = new Map<string, Transaction>();
        prev.forEach(t => map.set(t.id, t));
        (backup.transactions || []).forEach(t => map.set(t.id, t));
        const merged = Array.from(map.values());
        renumberedTxs = renumberAllTransactions(merged);
        return renumberedTxs;
      });
      if (currentUser) {
        bulkSaveTransactionsToCloud(currentUser.uid, renumberedTxs, true);
      }

      // Merge students by ID
      setStudents(prev => {
        const map = new Map<string, Student>();
        prev.forEach(s => map.set(s.id, s));
        (backup.students || []).forEach(s => map.set(s.id, s));
        return Array.from(map.values());
      });
      // Merge SPP Payments
      setSppPayments(prev => {
        const map = new Map<string, SppPayment>();
        prev.forEach(p => map.set(p.id, p));
        (backup.sppPayments || []).forEach(p => map.set(p.id, p));
        return Array.from(map.values());
      });
      // Merge Annual Payments
      setAnnualPayments(prev => {
        const map = new Map<string, AnnualFeePayment>();
        prev.forEach(p => map.set(p.id, p));
        (backup.annualPayments || []).forEach(p => map.set(p.id, p));
        return Array.from(map.values());
      });
    }

    alert('Berhasil memulihkan data cadangan keuangan!');
  };

  // Category Operations
  const handleAddCategory = (jenis: TransactionType, newCat: string) => {
    if (categoryData[jenis].includes(newCat)) return;
    const updated: CategoryData = {
      ...categoryData,
      [jenis]: [...categoryData[jenis], newCat]
    };
    setCategoryData(updated);
    if (currentUser) {
      saveCategoriesToCloud(currentUser.uid, updated);
    }
  };

  const handleDeleteCategory = (jenis: TransactionType, catToDelete: string) => {
    const updated: CategoryData = {
      ...categoryData,
      [jenis]: categoryData[jenis].filter(c => c !== catToDelete)
    };
    setCategoryData(updated);
    if (currentUser) {
      saveCategoriesToCloud(currentUser.uid, updated);
    }
  };

  // Save School Settings
  const handleSaveSchoolProfile = (updatedProfile: SchoolProfile) => {
    setSchoolProfile(updatedProfile);
    if (currentUser) {
      saveSchoolProfileToCloud(currentUser.uid, updatedProfile);
    }
  };

  // Excel Import Handler
  const handleImportExcelSuccess = (importedTransactions: Transaction[], mode: 'append' | 'overwrite') => {
    let finalTxs: Transaction[] = [];
    if (mode === 'overwrite') {
      finalTxs = importedTransactions;
    } else {
      finalTxs = [...importedTransactions, ...transactions];
    }
    const renumbered = renumberAllTransactions(finalTxs);
    setTransactions(renumbered);

    if (currentUser) {
      bulkSaveTransactionsToCloud(currentUser.uid, renumbered, true);
    }

    // Auto add any new categories discovered in Excel import
    const newCategories: CategoryData = { ...categoryData };
    let hasNewCat = false;

    importedTransactions.forEach(t => {
      const jenis = t.jenis;
      if (jenis && newCategories[jenis] && !newCategories[jenis].includes(t.kategori)) {
        newCategories[jenis] = [...newCategories[jenis], t.kategori];
        hasNewCat = true;
      }
    });

    if (hasNewCat) {
      setCategoryData(newCategories);
      if (currentUser) {
        saveCategoriesToCloud(currentUser.uid, newCategories);
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-emerald-500 selection:text-white">
      
      {/* Header Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        schoolProfile={schoolProfile}
        currentUser={currentUser}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenBackupRestore={() => setIsBackupRestoreOpen(true)}
        onOpenNewTransaction={() => setIsFormOpen(true)}
        onOpenExcelImport={() => setIsExcelImportOpen(true)}
        onOpenGoogleSheetsSync={() => setIsGoogleSheetModalOpen(true)}
        onExportCSV={() => exportTransactionsToCSV(transactions, schoolProfile.namaSekolah)}
        onExportExcel={() => exportTransactionsToExcel(transactions, schoolProfile.namaSekolah)}
        onResetData={handleResetData}
      />

      {/* Modal: Catat Transaksi Keuangan */}
      {isFormOpen && (
        <TransactionForm
          categoryData={categoryData}
          onSave={handleSaveTransaction}
          onClose={() => setIsFormOpen(false)}
          totalTransactionCount={transactions.length}
          transactions={transactions}
        />
      )}

      {/* Main Container */}
      <main className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 ${selectedKwitansi ? 'no-print' : ''}`}>
        
        {/* Metric Summary Cards */}
        <StatCard
          totalSaldo={totalSaldo}
          totalPemasukan={totalPemasukan}
          totalPengeluaran={totalPengeluaran}
          saldoTunai={saldoTunai}
          saldoBank={saldoBank}
          transactions={mainTransactions}
        />

        {/* Tab 1: Dashboard & Transactions */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            
            {/* Action Bar for Quick Form Trigger */}
            <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-2xl p-4 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4 border border-emerald-700/50">
              <div className="flex items-center gap-3">
                <div className="p-2.5 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
                  <PlusCircle className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">Catat Transaksi Keuangan Sekolah</h3>
                  <p className="text-xs text-emerald-200/80">Pemasukan, Pengeluaran, Saldo Kas Awal &amp; Mutasi Kas tersinkronasi otomatis</p>
                </div>
              </div>

              <button
                id="btn-open-modal-catat"
                onClick={() => setIsFormOpen(true)}
                className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold px-5 py-2.5 rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md hover:shadow-emerald-500/20 transition-all cursor-pointer whitespace-nowrap min-h-[44px]"
              >
                <PlusCircle className="w-5 h-5 stroke-[2.5]" />
                <span>+ Catat Transaksi Baru</span>
              </button>
            </div>

            {/* Bottom: Transaction History List */}
            <div className="w-full">
              <TransactionList
                transactions={mainTransactions}
                categoryData={categoryData}
                onDeleteTransaction={handleDeleteTransaction}
                onUpdateTransaction={handleUpdateTransaction}
                onSelectKwitansi={(tx) => setSelectedKwitansi(tx)}
                onOpenExcelImport={() => setIsExcelImportOpen(true)}
              />
            </div>

          </div>
        )}

        {/* Tab: Transaksi Harian Real */}
        {activeTab === 'real-daily' && (
          <RealDailyTransactionView
            transactions={transactions}
            categoryData={categoryData}
            schoolProfile={schoolProfile}
            onSaveTransaction={handleSaveTransaction}
            onEditTransaction={handleUpdateTransaction}
            onDeleteTransaction={handleDeleteTransaction}
            onSelectKwitansi={(tx) => setSelectedKwitansi(tx)}
            onOpenNewTransaction={() => setIsFormOpen(true)}
          />
        )}

        {/* Tab: SPP & Tagihan Siswa */}
        {activeTab === 'spp' && (
          <SppManagerView
            students={students}
            sppPayments={sppPayments}
            annualPayments={annualPayments}
            schoolProfile={schoolProfile}
            onSaveStudent={handleSaveStudent}
            onImportStudents={handleImportStudents}
            onDeleteStudent={handleDeleteStudent}
            onAddSppPayment={handleAddSppPayment}
            onDeleteSppPayment={handleDeleteSppPayment}
            onAddAnnualPayment={handleAddAnnualPayment}
            onDeleteAnnualPayment={handleDeleteAnnualPayment}
            onSyncAllSppToTransactions={handleSyncAllSppToTransactions}
          />
        )}

        {/* Tab 2: Laporan Rekap Bulanan */}
        {activeTab === 'laporan' && (
          <MonthlyReportView
            transactions={mainTransactions}
            schoolProfile={schoolProfile}
          />
        )}

        {/* Tab 3: Analytics & Visual Charts */}
        {activeTab === 'analytics' && (
          <AnalyticsView
            transactions={mainTransactions}
          />
        )}

        {/* Tab 4: Category Manager */}
        {activeTab === 'categories' && (
          <CategoryManager
            categoryData={categoryData}
            onAddCategory={handleAddCategory}
            onDeleteCategory={handleDeleteCategory}
          />
        )}

      </main>

      {/* Kwitansi Modal */}
      {selectedKwitansi && (
        <KwitansiModal
          transaction={selectedKwitansi}
          schoolProfile={schoolProfile}
          onClose={() => setSelectedKwitansi(null)}
        />
      )}

      {/* Settings Modal */}
      {isSettingsOpen && (
        <SettingsModal
          schoolProfile={schoolProfile}
          onSave={handleSaveSchoolProfile}
          onClose={() => setIsSettingsOpen(false)}
          onOpenBackupRestore={() => setIsBackupRestoreOpen(true)}
        />
      )}

      {/* Backup & Restore Modal */}
      {isBackupRestoreOpen && (
        <BackupRestoreModal
          isOpen={isBackupRestoreOpen}
          onClose={() => setIsBackupRestoreOpen(false)}
          onDownloadBackup={handleDownloadBackup}
          onRestoreBackup={handleRestoreBackup}
          totalTransactions={transactions.length}
          totalStudents={students.length}
          totalSppPayments={sppPayments.length}
          currentUser={currentUser}
          onSyncLocalToCloud={handleSyncLocalToCloud}
          onOpenAuth={() => setIsAuthOpen(true)}
        />
      )}

      {/* Auth & Cloud Login Modal */}
      {isAuthOpen && (
        <AuthModal
          currentUser={currentUser}
          onClose={() => setIsAuthOpen(false)}
        />
      )}

      {/* Excel Import Modal */}
      {isExcelImportOpen && (
        <ExcelImportModal
          existingCount={transactions.length}
          onImportSuccess={handleImportExcelSuccess}
          onClose={() => setIsExcelImportOpen(false)}
        />
      )}

      {/* Google Sheets Integration Modal */}
      <GoogleSheetSyncModal
        isOpen={isGoogleSheetModalOpen}
        onClose={() => setIsGoogleSheetModalOpen(false)}
        transactions={transactions}
        autoSyncEnabled={autoSyncEnabled}
        setAutoSyncEnabled={setAutoSyncEnabled}
      />

      {/* Mobile Catat Transaksi FAB */}
      <div className="fixed bottom-6 right-6 lg:hidden z-20 no-print">
        <button
          onClick={() => {
            setActiveTab('dashboard');
            setIsFormOpen(true);
          }}
          className="bg-emerald-500 text-slate-950 font-bold p-4 rounded-full shadow-2xl flex items-center justify-center hover:scale-105 active:scale-95 transition-all"
        >
          <span className="text-sm font-bold flex items-center gap-1">
            + Catat Kas
          </span>
        </button>
      </div>

    </div>
  );
}
