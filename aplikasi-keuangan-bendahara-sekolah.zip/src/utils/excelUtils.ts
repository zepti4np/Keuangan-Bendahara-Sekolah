import * as XLSX from 'xlsx';
import { Transaction, TransactionType } from '../types';

export interface ParsedImportRow {
  rowNumber: number;
  tanggal: string;
  jenis: TransactionType;
  kategori: string;
  uraian: string;
  pemasukan: number;
  pengeluaran: number;
  pihak: string;
  nomorBukti: string;
  metodePembayaran: 'Tunai / Kas' | 'Transfer Bank' | 'Cek / Giro';
  catatan: string;
  isValid: boolean;
  errors: string[];
}

export interface ImportResult {
  validRows: ParsedImportRow[];
  invalidRows: ParsedImportRow[];
  totalRows: number;
}

// Download Excel Template for easy user entry
export function downloadExcelTemplate() {
  const headers = [
    'Tanggal (YYYY-MM-DD atau DD/MM/YYYY)',
    'Jenis (Pemasukan/Pengeluaran/Saldo Awal/Mutasi Kas)',
    'Kategori',
    'Uraian',
    'Pihak Terkait (Dari/Kepada)',
    'Pemasukan (Rp)',
    'Pengeluaran (Rp)',
    'Metode Pembayaran (Tunai / Kas / Transfer Bank / Cek / Giro)',
    'Nomor Bukti',
    'Catatan'
  ];

  const sampleRows = [
    [
      '2026-07-01',
      'Saldo Awal',
      'Kas Tunai Sekolah',
      'Saldo Awal Bulan Juli 2026',
      'Bendahara Sekolah',
      5000000,
      0,
      'Tunai / Kas',
      'SA/07/2026/01',
      'Saldo kas fisik'
    ],
    [
      '2026-07-05',
      'Pemasukan',
      'Dana BOSP Regular',
      'Penerimaan Dana BOSP Tahap II',
      'Dinas Pendidikan',
      25000000,
      0,
      'Transfer Bank',
      'BKM/07/2026/01',
      'Masuk ke Rekening Bank'
    ],
    [
      '2026-07-10',
      'Pengeluaran',
      'Belanja ATK & Bahan Ajar',
      'Pembelian Kertas A4 10 Rim & Spidol',
      'Toko Buku Saraswati',
      0,
      650000,
      'Tunai / Kas',
      'BKK/07/2026/01',
      'Lunas Kwitansi No 142'
    ]
  ];

  const wb = XLSX.utils.book_new();
  const wsData = [headers, ...sampleRows];
  const ws = XLSX.utils.aoa_to_sheet(wsData);

  // Auto column width adjustment
  const colWidths = headers.map(h => ({ wch: Math.max(h.length + 3, 15) }));
  ws['!cols'] = colWidths;

  XLSX.utils.book_append_sheet(wb, ws, 'Template Transaksi');
  XLSX.writeFile(wb, 'Template_Impor_Kas_Sekolah.xlsx');
}

// Export current transactions to formatted Excel (.xlsx)
export function exportTransactionsToExcel(transactions: Transaction[], schoolName: string) {
  const headers = [
    'ID',
    'Nomor Bukti',
    'Tanggal',
    'Jenis',
    'Kategori',
    'Uraian',
    'Pihak Terkait',
    'Pemasukan (Rp)',
    'Pengeluaran (Rp)',
    'Metode Pembayaran',
    'Catatan'
  ];

  const rows = transactions.map(t => [
    t.id,
    t.nomorBukti || '-',
    t.tanggal,
    t.jenis,
    t.kategori,
    t.uraian,
    t.pihak || '-',
    t.pemasukan || 0,
    t.pengeluaran || 0,
    t.metodePembayaran || 'Tunai / Kas',
    t.catatan || ''
  ]);

  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);

  ws['!cols'] = [
    { wch: 15 },
    { wch: 18 },
    { wch: 12 },
    { wch: 14 },
    { wch: 22 },
    { wch: 35 },
    { wch: 25 },
    { wch: 16 },
    { wch: 16 },
    { wch: 18 },
    { wch: 20 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Data Transaksi');
  const fileName = `Laporan_Keuangan_${schoolName.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.xlsx`;
  XLSX.writeFile(wb, fileName);
}

// Parse uploaded Excel / CSV File
export function parseExcelFile(file: File): Promise<ImportResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array', cellDates: true });

        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        // Convert sheet to raw JS array rows
        const rawJson: any[] = XLSX.utils.sheet_to_json(worksheet, { header: 1, raw: true, defval: '' });

        if (!rawJson || rawJson.length < 2) {
          resolve({ validRows: [], invalidRows: [], totalRows: 0 });
          return;
        }

        // Identify header row (first non-empty row containing column keywords)
        let headerIndex = -1;
        for (let i = 0; i < Math.min(rawJson.length, 10); i++) {
          const rowStr = (rawJson[i] || []).join(' ').toLowerCase();
          if (rowStr.includes('tanggal') || rowStr.includes('jenis') || rowStr.includes('uraian') || rowStr.includes('kategori')) {
            headerIndex = i;
            break;
          }
        }

        if (headerIndex === -1) headerIndex = 0;

        const headerRow: string[] = rawJson[headerIndex].map((h: any) => String(h || '').trim());
        const dataRows = rawJson.slice(headerIndex + 1);

        // Clean headers by removing instructions inside parentheses e.g. "Jenis (Pemasukan...)" => "jenis"
        const cleanHeaders = headerRow.map(h => 
          h.replace(/\(.*?\)/g, '').trim().toLowerCase()
        );

        // Explicit and strict column header matching to prevent column index collision
        // 1. Identify idxJenis
        let idxJenis = -1;
        headerRow.forEach((h, i) => {
          const hLower = String(h || '').trim().toLowerCase();
          if (idxJenis === -1 && (hLower === 'jenis' || hLower.startsWith('jenis') || hLower.includes('tipe') || hLower.includes('type'))) {
            idxJenis = i;
          }
        });

        // 2. Identify idxPemasukan (excluding idxJenis)
        let idxPemasukan = -1;
        headerRow.forEach((h, i) => {
          if (i === idxJenis) return;
          const hLower = String(h || '').trim().toLowerCase();
          const cleanH = hLower.replace(/\(.*?\)/g, '').trim();
          if (idxPemasukan === -1) {
            if (cleanH === 'pemasukan' || cleanH.includes('pemasukan') || cleanH === 'debit' || cleanH === 'penerimaan' || cleanH === 'masuk') {
              idxPemasukan = i;
            }
          }
        });

        // 3. Identify idxPengeluaran (excluding idxJenis and idxPemasukan)
        let idxPengeluaran = -1;
        headerRow.forEach((h, i) => {
          if (i === idxJenis || i === idxPemasukan) return;
          const hLower = String(h || '').trim().toLowerCase();
          const cleanH = hLower.replace(/\(.*?\)/g, '').trim();
          if (idxPengeluaran === -1) {
            if (cleanH === 'pengeluaran' || cleanH.includes('pengeluaran') || cleanH === 'kredit' || cleanH === 'belanja' || cleanH === 'keluar') {
              idxPengeluaran = i;
            }
          }
        });

        // 4. Identify idxNominalSingle
        let idxNominalSingle = -1;
        headerRow.forEach((h, i) => {
          if (i === idxJenis || i === idxPemasukan || i === idxPengeluaran) return;
          const hLower = String(h || '').trim().toLowerCase();
          const cleanH = hLower.replace(/\(.*?\)/g, '').trim();
          if (idxNominalSingle === -1) {
            if (cleanH === 'nominal' || cleanH === 'jumlah' || cleanH === 'total' || cleanH === 'nilai' || cleanH === 'sebesar' || cleanH === 'amount') {
              idxNominalSingle = i;
            }
          }
        });

        const usedIndices = [idxJenis, idxPemasukan, idxPengeluaran, idxNominalSingle].filter(x => x !== -1);

        const findCol = (keywords: string[]) => {
          return headerRow.findIndex((h, i) => {
            if (usedIndices.includes(i)) return false;
            const hLower = String(h || '').trim().toLowerCase();
            const cleanH = hLower.replace(/\(.*?\)/g, '').trim();
            return keywords.some(k => cleanH === k || cleanH.includes(k) || hLower.includes(k));
          });
        };

        const idxTanggal = findCol(['tanggal', 'date', 'tgl']);
        const idxKategori = findCol(['kategori', 'category', 'sub']);
        const idxUraian = findCol(['uraian', 'keterangan', 'description', 'detail', 'nama']);
        const idxPihak = findCol(['pihak', 'terima', 'bayar', 'rekanan', 'penerima']);
        const idxMetode = findCol(['metode', 'pembayaran', 'kas/bank', 'payment']);
        const idxNomorBukti = findCol(['bukti', 'no. bukti', 'nomor', 'ref']);
        const idxCatatan = findCol(['catatan', 'note', 'keterangan tambahan']);

        const validRows: ParsedImportRow[] = [];
        const invalidRows: ParsedImportRow[] = [];

        dataRows.forEach((row, rowIndex) => {
          // Skip completely blank rows
          if (!row || row.every((c: any) => String(c || '').trim() === '')) {
            return;
          }

          const actualRowNo = headerIndex + 2 + rowIndex;
          const errors: string[] = [];

          // 1. Tanggal
          let rawTanggal = idxTanggal !== -1 ? row[idxTanggal] : '';
          let formattedDate = sanitizeDate(rawTanggal);
          if (!formattedDate) {
            errors.push('Tanggal tidak valid (Gunakan format YYYY-MM-DD atau DD/MM/YYYY)');
            formattedDate = new Date().toISOString().slice(0, 10);
          }

          // 2. Jenis Transaksi (Deteksi jenis transaksi terlebih dahulu)
          let rawJenis = idxJenis !== -1 ? String(row[idxJenis] || '').trim() : '';
          let normalizedJenis: TransactionType | null = null;
          const jLower = rawJenis.toLowerCase();
          if (jLower.includes('masuk') || jLower.includes('in') || jLower.includes('pemasukan') || jLower.includes('terima')) {
            normalizedJenis = 'Pemasukan';
          } else if (jLower.includes('keluar') || jLower.includes('out') || jLower.includes('pengeluaran') || jLower.includes('belanja')) {
            normalizedJenis = 'Pengeluaran';
          } else if (jLower.includes('saldo awal') || jLower.includes('awal') || jLower.includes('saldo')) {
            normalizedJenis = 'Saldo Awal';
          } else if (jLower.includes('mutasi') || jLower.includes('transfer')) {
            normalizedJenis = 'Mutasi Kas';
          } else if (rawJenis) {
            errors.push(`Jenis transaksi "${rawJenis}" tidak dikenal`);
          }

          const isSaldoAwal = normalizedJenis === 'Saldo Awal';

          // 3. Nominal Pemasukan & Pengeluaran
          let rawPemasukan = idxPemasukan !== -1 ? row[idxPemasukan] : 0;
          let rawPengeluaran = idxPengeluaran !== -1 ? row[idxPengeluaran] : 0;

          let pemasukanNum = cleanNumber(rawPemasukan, isSaldoAwal);
          let pengeluaranNum = cleanNumber(rawPengeluaran, isSaldoAwal);

          // If single nominal column is present and amounts are 0
          if (pemasukanNum === 0 && pengeluaranNum === 0 && idxNominalSingle !== -1) {
            const singleVal = cleanNumber(row[idxNominalSingle], isSaldoAwal);
            if (normalizedJenis === 'Pemasukan' || normalizedJenis === 'Saldo Awal') {
              pemasukanNum = singleVal;
            } else {
              pengeluaranNum = singleVal;
            }
          }

          // Saldo Awal positioning & auto-alignment
          if (isSaldoAwal) {
            if (pemasukanNum === 0 && pengeluaranNum !== 0) {
              pemasukanNum = pengeluaranNum;
              pengeluaranNum = 0;
            }
          }

          // Infer jenis if missing
          if (!normalizedJenis) {
            if (pemasukanNum !== 0 && pengeluaranNum === 0) {
              normalizedJenis = 'Pemasukan';
            } else if (pengeluaranNum !== 0 && pemasukanNum === 0) {
              normalizedJenis = 'Pengeluaran';
            } else {
              normalizedJenis = 'Pengeluaran';
            }
          }

          // Auto-align nominal according to transaction type (for non-Saldo Awal)
          if (!isSaldoAwal) {
            if (normalizedJenis === 'Pemasukan' && pemasukanNum === 0 && pengeluaranNum > 0) {
              pemasukanNum = pengeluaranNum;
              pengeluaranNum = 0;
            } else if (normalizedJenis === 'Pengeluaran' && pengeluaranNum === 0 && pemasukanNum > 0) {
              pengeluaranNum = pemasukanNum;
              pemasukanNum = 0;
            }

            if (pemasukanNum === 0 && pengeluaranNum === 0) {
              errors.push('Nominal Pemasukan atau Pengeluaran harus lebih besar dari 0');
            }
          }

          // 4. Uraian
          let uraian = idxUraian !== -1 ? String(row[idxUraian] || '').trim() : '';
          if (!uraian) {
            if (isSaldoAwal) {
              uraian = 'Saldo Awal Kas';
            } else {
              errors.push('Uraian/Keterangan wajib diisi');
              uraian = 'Transaksi tanpa uraian';
            }
          }

          // 5. Kategori
          let kategori = idxKategori !== -1 ? String(row[idxKategori] || '').trim() : '';
          if (!kategori) {
            if (isSaldoAwal) {
              kategori = 'Saldo Awal Kas';
            } else if (normalizedJenis === 'Pemasukan') {
              kategori = 'Pemasukan Lainnya';
            } else {
              kategori = 'Pengeluaran Lain-lain';
            }
          }

          // 6. Metode Pembayaran
          let rawMetode = idxMetode !== -1 ? String(row[idxMetode] || '').trim().toLowerCase() : '';
          let metodePembayaran: 'Tunai / Kas' | 'Transfer Bank' | 'Cek / Giro' = 'Tunai / Kas';
          if (rawMetode.includes('bank') || rawMetode.includes('transfer')) {
            metodePembayaran = 'Transfer Bank';
          } else if (rawMetode.includes('cek') || rawMetode.includes('giro')) {
            metodePembayaran = 'Cek / Giro';
          }

          // 7. Pihak & Bukti & Catatan
          const pihak = idxPihak !== -1 ? String(row[idxPihak] || '').trim() : '-';
          const nomorBukti = idxNomorBukti !== -1 ? String(row[idxNomorBukti] || '').trim() : '';
          const catatan = idxCatatan !== -1 ? String(row[idxCatatan] || '').trim() : '';

          const parsedRow: ParsedImportRow = {
            rowNumber: actualRowNo,
            tanggal: formattedDate,
            jenis: normalizedJenis,
            kategori,
            uraian,
            pemasukan: pemasukanNum,
            pengeluaran: pengeluaranNum,
            pihak,
            nomorBukti,
            metodePembayaran,
            catatan,
            isValid: errors.length === 0,
            errors
          };

          if (parsedRow.isValid) {
            validRows.push(parsedRow);
          } else {
            invalidRows.push(parsedRow);
          }
        });

        resolve({
          validRows,
          invalidRows,
          totalRows: validRows.length + invalidRows.length
        });
      } catch (err: any) {
        reject(new Error('Gagal membaca berkas Excel: ' + (err?.message || 'Format file tidak didukung')));
      }
    };

    reader.onerror = () => reject(new Error('Gagal membaca berkas. Silakan coba lagi.'));
    reader.readAsArrayBuffer(file);
  });
}

function cleanNumber(val: any, allowNegative: boolean = false): number {
  if (val === null || val === undefined || val === '') return 0;
  if (typeof val === 'number') {
    if (isNaN(val)) return 0;
    return allowNegative ? val : Math.abs(val);
  }

  let str = String(val).trim();
  if (!str || str === '-' || str === '–' || str === '—') return 0;

  let isNegative = false;
  // Handle accounting format in parentheses e.g. (100.000) or (Rp 100.000)
  if (str.startsWith('(') && str.endsWith(')')) {
    str = str.slice(1, -1).trim();
    isNegative = true;
  } else if (str.startsWith('-')) {
    isNegative = true;
  }

  // Remove currency prefix/suffix, trailing ",-" or ".-" and spaces
  str = str
    .replace(/Rp\.?/gi, '')
    .replace(/,-\s*$/g, '')
    .replace(/\.-\s*$/g, '')
    .replace(/\s+/g, '');

  if (!str) return 0;

  // Strip trailing decimal zeros if formatting is e.g. 5000000.00 or 5000000,00
  str = str.replace(/[,.]00$/, '');

  // If both dots and commas exist
  if (str.includes('.') && str.includes(',')) {
    const lastDot = str.lastIndexOf('.');
    const lastComma = str.lastIndexOf(',');
    if (lastComma > lastDot) {
      // Indonesian/European: 1.000.000,50 -> 1000000.50
      str = str.replace(/\./g, '').replace(',', '.');
    } else {
      // US style: 1,000,000.50 -> 1000000.50
      str = str.replace(/,/g, '');
    }
  } else if (str.includes('.')) {
    const parts = str.split('.');
    if (parts.length > 2 || (parts.length === 2 && parts[1].length === 3)) {
      str = str.replace(/\./g, '');
    }
  } else if (str.includes(',')) {
    const parts = str.split(',');
    if (parts.length > 2 || (parts.length === 2 && parts[1].length === 3)) {
      str = str.replace(/,/g, '');
    } else if (parts.length === 2) {
      str = str.replace(',', '.');
    }
  }

  // Strip any remaining non-numeric characters except minus and dot
  str = str.replace(/[^0-9.-]/g, '');

  let num = parseFloat(str);
  if (isNaN(num)) return 0;
  if (isNegative && num > 0) {
    num = -num;
  }

  return allowNegative ? num : Math.abs(num);
}

function sanitizeDate(raw: any): string | null {
  if (raw === null || raw === undefined || raw === '') return null;

  // 1. JS Date object (e.g. from SheetJS or JS Date)
  if (raw instanceof Date) {
    if (isNaN(raw.getTime())) return null;

    // Check local midnight first (e.g. when created in user's browser local time)
    if (raw.getHours() === 0 && raw.getMinutes() === 0) {
      const y = raw.getFullYear();
      const m = String(raw.getMonth() + 1).padStart(2, '0');
      const d = String(raw.getDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    }

    // Check UTC midnight (e.g. standard SheetJS UTC date)
    if (raw.getUTCHours() === 0 && raw.getUTCMinutes() === 0) {
      const y = raw.getUTCFullYear();
      const m = String(raw.getUTCMonth() + 1).padStart(2, '0');
      const d = String(raw.getUTCDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    }

    // If timezone offset shifted UTC hours (e.g. 17:00 UTC = 00:00 WIB UTC+7),
    // adding 12 hours safely moves UTC timestamp into the intended calendar day
    let timeMs = raw.getTime();
    if (raw.getUTCHours() >= 12) {
      timeMs += 12 * 3600 * 1000;
    }
    const adjusted = new Date(timeMs);
    const y = adjusted.getUTCFullYear();
    const m = String(adjusted.getUTCMonth() + 1).padStart(2, '0');
    const d = String(adjusted.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // 2. Excel Serial Date number (e.g. 45931 for 1 Oct 2025)
  if (typeof raw === 'number' || (typeof raw === 'string' && /^\d{5}(\.\d+)?$/.test(raw.trim()))) {
    const num = Number(raw);
    if (!isNaN(num) && num > 10000 && num < 100000) {
      const dateObj = new Date(Math.round((num - 25569) * 86400 * 1000));
      if (!isNaN(dateObj.getTime())) {
        const y = dateObj.getUTCFullYear();
        const m = String(dateObj.getUTCMonth() + 1).padStart(2, '0');
        const d = String(dateObj.getUTCDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
      }
    }
  }

  const str = String(raw).trim();
  if (!str) return null;

  // 3. YYYY-MM-DD or YYYY/MM/DD or YYYY.MM.DD
  const ymdMatch = str.match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})$/);
  if (ymdMatch) {
    const y = ymdMatch[1];
    const m = ymdMatch[2].padStart(2, '0');
    const d = ymdMatch[3].padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // 4. DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY (Indonesian standard format: Hari/Bulan/Tahun)
  const dmyMatch = str.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})$/);
  if (dmyMatch) {
    let day = parseInt(dmyMatch[1], 10);
    let month = parseInt(dmyMatch[2], 10);
    let year = parseInt(dmyMatch[3], 10);
    if (dmyMatch[3].length === 2) {
      year = 2000 + year;
    }

    // In Indonesia region, DD/MM/YYYY is standard.
    // If month > 12 and day <= 12, user entered MM/DD/YYYY (e.g. 07/15/2026)
    if (month > 12 && day <= 12) {
      const temp = day;
      day = month;
      month = temp;
    }

    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      const yStr = String(year);
      const mStr = String(month).padStart(2, '0');
      const dStr = String(day).padStart(2, '0');
      return `${yStr}-${mStr}-${dStr}`;
    }
  }

  // 5. Text date with Indonesian / English month names e.g. "1 Oktober 2025", "15-Ags-2026", "05/Maret/2026"
  const bulanIndo: { [k: string]: string } = {
    jan: '01', januari: '01', january: '01',
    feb: '02', februari: '02', february: '02',
    mar: '03', maret: '03', march: '03',
    apr: '04', april: '04',
    mei: '05', may: '05',
    jun: '06', juni: '06', june: '06',
    jul: '07', juli: '07', july: '07',
    agu: '08', agustus: '08', ags: '08', aug: '08', august: '08',
    sep: '09', september: '09',
    okt: '10', oktober: '10', oct: '10', october: '10',
    nov: '11', november: '11',
    des: '12', desember: '12', dec: '12', december: '12'
  };

  const textMonthMatch = str.match(/^(\d{1,2})[\s\/\-\.]([a-zA-Z]+)[\s\/\-\.](\d{2,4})$/);
  if (textMonthMatch) {
    const day = textMonthMatch[1].padStart(2, '0');
    const monthStr = textMonthMatch[2].toLowerCase();
    let year = textMonthMatch[3];
    if (year.length === 2) year = `20${year}`;
    if (bulanIndo[monthStr]) {
      return `${year}-${bulanIndo[monthStr]}-${day}`;
    }
  }

  // 6. Generic JS Date parse fallback
  const parsed = new Date(str);
  if (!isNaN(parsed.getTime())) {
    let timeMs = parsed.getTime();
    if (parsed.getUTCHours() >= 12) {
      timeMs += 12 * 3600 * 1000;
    }
    const adjusted = new Date(timeMs);
    const y = adjusted.getUTCFullYear();
    const m = String(adjusted.getUTCMonth() + 1).padStart(2, '0');
    const d = String(adjusted.getUTCDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  return null;
}

// ==========================================
// STUDENT DATA EXCEL FUNCTIONS
// ==========================================

import { Student } from '../types';

export interface ParsedStudentRow {
  rowNumber: number;
  nisn: string;
  nama: string;
  kelas: string;
  nominalSppBulanan: number;
  nominalTagihanTahunan: number;
  keterangan: string;
  isValid: boolean;
  errors: string[];
}

export interface StudentImportResult {
  validRows: ParsedStudentRow[];
  invalidRows: ParsedStudentRow[];
  totalRows: number;
}

export function downloadStudentExcelTemplate() {
  const headers = [
    'NISN',
    'Nama Lengkap Siswa',
    'Kelas',
    'Tarif SPP Bulanan (Rp)',
    'Tarif Tagihan Tahunan (Rp)',
    'Keterangan / Status'
  ];

  const sampleRows = [
    ['10293841', 'Ahmad Rizky Pratama', '10 IPA 1', 150000, 1500000, 'Regular'],
    ['10293842', 'Anisa Rahmawati', '10 IPA 1', 150000, 1500000, 'Regular'],
    ['10293843', 'Budi Santoso', '10 IPA 2', 150000, 1500000, 'Regular'],
    ['10293844', 'Citra Kirana', '10 IPS 1', 125000, 1200000, 'Beasiswa Yatim'],
    ['10293845', 'Dewi Lestari', '10 IPS 2', 150000, 1500000, 'Regular']
  ];

  const wb = XLSX.utils.book_new();
  const wsData = [headers, ...sampleRows];
  const ws = XLSX.utils.aoa_to_sheet(wsData);

  const colWidths = [
    { wch: 15 }, // NISN
    { wch: 28 }, // Nama
    { wch: 15 }, // Kelas
    { wch: 22 }, // SPP
    { wch: 24 }, // Tagihan Tahunan
    { wch: 20 }  // Keterangan
  ];
  ws['!cols'] = colWidths;

  XLSX.utils.book_append_sheet(wb, ws, 'Template Siswa');
  XLSX.writeFile(wb, 'Template_Impor_Data_Siswa.xlsx');
}

export function exportStudentsToExcel(students: Student[], schoolName: string) {
  const sortedStudents = [...students].sort((a, b) => a.nama.localeCompare(b.nama, 'id', { sensitivity: 'base' }));

  const headers = [
    'No',
    'NISN',
    'Nama Lengkap Siswa',
    'Kelas',
    'Tarif SPP Bulanan (Rp)',
    'Tarif Tagihan Tahunan (Rp)',
    'Keterangan'
  ];

  const rows = sortedStudents.map((s, idx) => [
    idx + 1,
    s.nisn || '-',
    s.nama,
    s.kelas || '-',
    s.nominalSppBulanan || 0,
    s.nominalTagihanTahunan || 0,
    s.keterangan || 'Regular'
  ]);

  const wb = XLSX.utils.book_new();
  const wsData = [
    [`DATA SISWA - ${schoolName.toUpperCase()}`],
    [`Diunduh pada: ${new Date().toLocaleDateString('id-ID')}`],
    [],
    headers,
    ...rows
  ];

  const ws = XLSX.utils.aoa_to_sheet(wsData);
  ws['!cols'] = [
    { wch: 6 },
    { wch: 16 },
    { wch: 30 },
    { wch: 15 },
    { wch: 22 },
    { wch: 24 },
    { wch: 20 }
  ];

  XLSX.utils.book_append_sheet(wb, ws, 'Data Siswa');
  XLSX.writeFile(wb, `Data_Siswa_${schoolName.replace(/[^a-zA-Z0-9]/g, '_')}.xlsx`);
}

export function parseStudentExcelFile(file: File): Promise<StudentImportResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array', cellDates: true, raw: false });

        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];

        const rawJson: any[][] = XLSX.utils.sheet_to_json(worksheet, { header: 1, defval: '' });

        if (!rawJson || rawJson.length === 0) {
          reject(new Error('File Excel kosong atau tidak dapat dibaca'));
          return;
        }

        // Find header row index
        let headerRowIndex = -1;
        for (let i = 0; i < Math.min(15, rawJson.length); i++) {
          const rowStr = rawJson[i].map(c => String(c).toLowerCase()).join(' ');
          if (rowStr.includes('nama') || rowStr.includes('nisn') || rowStr.includes('siswa')) {
            headerRowIndex = i;
            break;
          }
        }

        if (headerRowIndex === -1) {
          headerRowIndex = 0;
        }

        const headerRow = rawJson[headerRowIndex].map(c => String(c).trim().toLowerCase());

        const nisnCol = headerRow.findIndex(h => h.includes('nisn') || h.includes('nis'));
        const namaCol = headerRow.findIndex(h => h.includes('nama') || h.includes('siswa'));
        const kelasCol = headerRow.findIndex(h => h.includes('kelas') || h.includes('rombel'));
        const sppCol = headerRow.findIndex(h => h.includes('spp') || h.includes('bulanan'));
        const tahananCol = headerRow.findIndex(h => h.includes('tahunan') || h.includes('gedung') || h.includes('sarpras'));
        const ketCol = headerRow.findIndex(h => h.includes('ket') || h.includes('status'));

        const validRows: ParsedStudentRow[] = [];
        const invalidRows: ParsedStudentRow[] = [];

        for (let i = headerRowIndex + 1; i < rawJson.length; i++) {
          const row = rawJson[i];
          if (!row || row.every(cell => String(cell).trim() === '')) {
            continue; // Skip empty rows
          }

          const rowNum = i + 1;
          const errors: string[] = [];

          const nisnVal = nisnCol !== -1 && row[nisnCol] !== undefined ? String(row[nisnCol]).trim() : '';
          let namaVal = namaCol !== -1 && row[namaCol] !== undefined ? String(row[namaCol]).trim() : '';
          
          // Fallback if namaCol wasn't found by header, check first text cell that looks like a name
          if (!namaVal && namaCol === -1) {
            for (let c = 0; c < row.length; c++) {
              const cellStr = String(row[c]).trim();
              if (cellStr && cellStr.length > 2 && isNaN(Number(cellStr))) {
                namaVal = cellStr;
                break;
              }
            }
          }

          const kelasVal = kelasCol !== -1 && row[kelasCol] !== undefined ? String(row[kelasCol]).trim() : 'Umum';
          
          // Parse numbers safely
          const parseCurrency = (val: any, defaultVal = 0): number => {
            if (val === undefined || val === null || val === '') return defaultVal;
            const strVal = String(val).replace(/[^0-9\.]/g, '');
            const num = parseFloat(strVal);
            return isNaN(num) ? defaultVal : num;
          };

          const sppVal = sppCol !== -1 ? parseCurrency(row[sppCol], 150000) : 150000;
          const tahunasnVal = tahananCol !== -1 ? parseCurrency(row[tahananCol], 1500000) : 1500000;
          const ketVal = ketCol !== -1 && row[ketCol] !== undefined ? String(row[ketCol]).trim() : 'Regular';

          if (!namaVal) {
            errors.push('Nama siswa tidak boleh kosong');
          }

          const parsedRow: ParsedStudentRow = {
            rowNumber: rowNum,
            nisn: nisnVal || `NISN-${Math.floor(100000 + Math.random() * 900000)}`,
            nama: namaVal,
            kelas: kelasVal || 'Umum',
            nominalSppBulanan: sppVal,
            nominalTagihanTahunan: tahunasnVal,
            keterangan: ketVal,
            isValid: errors.length === 0,
            errors
          };

          if (parsedRow.isValid) {
            validRows.push(parsedRow);
          } else {
            invalidRows.push(parsedRow);
          }
        }

        resolve({
          validRows,
          invalidRows,
          totalRows: validRows.length + invalidRows.length
        });

      } catch (err) {
        reject(new Error(`Gagal memproses file Excel: ${(err as Error).message}`));
      }
    };

    reader.onerror = () => {
      reject(new Error('Gagal membaca file'));
    };

    reader.readAsArrayBuffer(file);
  });
}

