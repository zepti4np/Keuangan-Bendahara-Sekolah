/**
 * Utility for handling file uploads (images and PDFs) for BKK / BKM / BKKM transaction receipts.
 * Compresses images before converting to Data URL to optimize localStorage/Firestore storage.
 */

export interface ProcessedFileResult {
  dataUrl: string;
  fileName: string;
  fileType: 'image' | 'pdf' | 'other';
  fileSize: number;
}

export async function processReceiptFile(file: File): Promise<ProcessedFileResult> {
  const fileName = file.name;
  const fileSize = file.size;

  if (file.type.startsWith('image/')) {
    const dataUrl = await compressImageFile(file, 1200, 1200, 0.8);
    return {
      dataUrl,
      fileName,
      fileType: 'image',
      fileSize
    };
  } else if (file.type === 'application/pdf') {
    if (fileSize > 3 * 1024 * 1024) {
      throw new Error('Ukuran berkas PDF terlalu besar (maksimal 3MB). Silakan upload foto atau kompres PDF.');
    }
    const dataUrl = await readFileAsDataURL(file);
    return {
      dataUrl,
      fileName,
      fileType: 'pdf',
      fileSize
    };
  } else {
    // Other file types
    if (fileSize > 2 * 1024 * 1024) {
      throw new Error('Ukuran berkas terlalu besar (maksimal 2MB).');
    }
    const dataUrl = await readFileAsDataURL(file);
    return {
      dataUrl,
      fileName,
      fileType: 'other',
      fileSize
    };
  }
}

export function readFileAsDataURL(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (err) => reject(err);
    reader.readAsDataURL(file);
  });
}

export function compressImageFile(
  file: File,
  maxWidth = 1200,
  maxHeight = 1200,
  quality = 0.8
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (e) => {
      const img = new Image();
      img.src = e.target?.result as string;
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width / height > maxWidth / maxHeight) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        // Use JPEG for photographic receipts to minimize data size
        const mimeType = file.type === 'image/png' ? 'image/png' : 'image/jpeg';
        const compressedDataUrl = canvas.toDataURL(mimeType, quality);
        resolve(compressedDataUrl);
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}
