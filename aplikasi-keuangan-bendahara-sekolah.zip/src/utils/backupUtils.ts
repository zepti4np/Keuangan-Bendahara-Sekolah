import { 
  SchoolProfile, 
  CategoryData, 
  Transaction, 
  Student, 
  SppPayment, 
  AnnualFeePayment 
} from '../types';

export interface BackupData {
  app: string;
  version: string;
  exportedAt: string;
  schoolProfile: SchoolProfile;
  categoryData: CategoryData;
  transactions: Transaction[];
  students: Student[];
  sppPayments: SppPayment[];
  annualPayments: AnnualFeePayment[];
}

/**
 * Downloads full app data as a JSON backup file
 */
export function downloadBackupJSON(
  schoolProfile: SchoolProfile,
  categoryData: CategoryData,
  transactions: Transaction[],
  students: Student[],
  sppPayments: SppPayment[],
  annualPayments: AnnualFeePayment[]
) {
  const backup: BackupData = {
    app: 'Aplikasi Keuangan Bendahara Sekolah',
    version: '1.0',
    exportedAt: new Date().toISOString(),
    schoolProfile,
    categoryData,
    transactions,
    students,
    sppPayments,
    annualPayments
  };

  const jsonStr = JSON.stringify(backup, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  const url = URL.createObjectURL(blob);

  const dateStr = new Date().toISOString().slice(0, 10);
  const cleanSchoolName = (schoolProfile.namaSekolah || 'Sekolah').replace(/[^a-zA-Z0-9]/g, '_');
  const filename = `BACKUP_KEUANGAN_${cleanSchoolName}_${dateStr}.json`;

  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * Validates and parses a JSON backup file
 */
export function parseBackupJSON(jsonText: string): { success: boolean; data?: BackupData; error?: string } {
  try {
    const parsed = JSON.parse(jsonText);
    
    // Check basic structure
    if (!parsed || typeof parsed !== 'object') {
      return { success: false, error: 'File JSON tidak valid atau kosong.' };
    }

    if (!Array.isArray(parsed.transactions)) {
      return { success: false, error: 'File backup tidak memiliki daftar transaksi yang valid.' };
    }

    const backupData: BackupData = {
      app: parsed.app || 'Aplikasi Keuangan Bendahara Sekolah',
      version: parsed.version || '1.0',
      exportedAt: parsed.exportedAt || new Date().toISOString(),
      schoolProfile: parsed.schoolProfile || {},
      categoryData: parsed.categoryData || {},
      transactions: Array.isArray(parsed.transactions) ? parsed.transactions : [],
      students: Array.isArray(parsed.students) ? parsed.students : [],
      sppPayments: Array.isArray(parsed.sppPayments) ? parsed.sppPayments : [],
      annualPayments: Array.isArray(parsed.annualPayments) ? parsed.annualPayments : []
    };

    return { success: true, data: backupData };
  } catch (err: any) {
    return { success: false, error: `Gagal membaca file JSON: ${err.message || err}` };
  }
}
