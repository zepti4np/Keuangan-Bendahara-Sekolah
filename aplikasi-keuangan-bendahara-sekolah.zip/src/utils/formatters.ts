import { Transaction } from '../types';

export function formatRupiah(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) return 'Rp 0';
  return 'Rp ' + Math.round(amount).toLocaleString('id-ID');
}

export function formatRupiahNumberOnly(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) return '0';
  return Math.round(amount).toLocaleString('id-ID');
}

export function formatDateIndonesian(dateString: string): string {
  if (!dateString) return '-';
  const parts = dateString.split('-');
  if (parts.length !== 3) return dateString;

  const year = parts[0];
  const monthIdx = parseInt(parts[1], 10) - 1;
  const day = parseInt(parts[2], 10);

  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  if (monthIdx >= 0 && monthIdx < 12) {
    return `${day} ${months[monthIdx]} ${year}`;
  }
  return dateString;
}

export function getMonthYearName(periodStr: string): string {
  // periodStr is YYYY-MM
  if (!periodStr) return '-';
  const parts = periodStr.split('-');
  if (parts.length < 2) return periodStr;

  const year = parts[0];
  const monthIdx = parseInt(parts[1], 10) - 1;

  const months = [
    'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
    'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
  ];

  if (monthIdx >= 0 && monthIdx < 12) {
    return `${months[monthIdx]} ${year}`;
  }
  return periodStr;
}

export function terbilang(n: number): string {
  if (isNaN(n) || n === null || n === undefined) return 'Nol';
  n = Math.abs(Math.round(n));

  if (n === 0) return 'Nol';

  function convert(val: number): string {
    if (val === 0) return '';
    const angka = ['', 'Satu', 'Dua', 'Tiga', 'Empat', 'Lima', 'Enam', 'Tujuh', 'Delapan', 'Sembilan', 'Sepuluh', 'Sebelas'];

    if (val < 12) {
      return ' ' + angka[val];
    } else if (val < 20) {
      return convert(val - 10) + ' Belas';
    } else if (val < 100) {
      return convert(Math.floor(val / 10)) + ' Puluh' + convert(val % 10);
    } else if (val < 200) {
      return ' Seratus' + convert(val - 100);
    } else if (val < 1000) {
      return convert(Math.floor(val / 100)) + ' Ratus' + convert(val % 100);
    } else if (val < 2000) {
      return ' Seribu' + convert(val - 1000);
    } else if (val < 1000000) {
      return convert(Math.floor(val / 1000)) + ' Ribu' + convert(val % 1000);
    } else if (val < 1000000000) {
      return convert(Math.floor(val / 1000000)) + ' Juta' + convert(val % 1000000);
    } else if (val < 1000000000000) {
      return convert(Math.floor(val / 1000000000)) + ' Milyar' + convert(val % 1000000000);
    } else {
      return convert(Math.floor(val / 1000000000000)) + ' Triliun' + convert(val % 1000000000000);
    }
  }

  const res = convert(n).replace(/\s+/g, ' ').trim();
  return res || 'Nol';
}

export function generateNomorBukti(
  jenis: string, 
  transactionsOrCount: Transaction[] | number, 
  dateStr: string
): string {
  let prefix = 'BKM';
  if (jenis === 'Saldo Awal') {
    prefix = 'MEMO';
  } else if (jenis === 'Pengeluaran') {
    prefix = 'BKK';
  } else if (jenis === 'Pemasukan') {
    prefix = 'BKM';
  } else if (jenis === 'Mutasi Kas') {
    prefix = 'BKM';
  }

  const parts = (dateStr || '').split('-');
  const year = parts[0] || new Date().getFullYear().toString();
  const month = parts[1] || String(new Date().getMonth() + 1).padStart(2, '0');
  const targetPeriod = `${year}-${month}`;

  let maxSeq = 0;

  if (Array.isArray(transactionsOrCount)) {
    const matchingTxs = transactionsOrCount.filter(t => {
      if (!t.tanggal || !t.tanggal.startsWith(targetPeriod)) return false;
      if (prefix === 'MEMO') return t.jenis === 'Saldo Awal' || t.nomorBukti?.startsWith('MEMO');
      if (prefix === 'BKM') return (t.jenis === 'Pemasukan' || (t.jenis === 'Mutasi Kas' && t.pemasukan > 0)) && !t.nomorBukti?.startsWith('MEMO');
      if (prefix === 'BKK') return (t.jenis === 'Pengeluaran' || (t.jenis === 'Mutasi Kas' && t.pengeluaran > 0));
      return false;
    });

    maxSeq = matchingTxs.length;

    matchingTxs.forEach(t => {
      if (t.nomorBukti) {
        const digits = t.nomorBukti.match(/(\d+)$/);
        if (digits && digits[1]) {
          const num = parseInt(digits[1], 10);
          if (!isNaN(num) && num > maxSeq) {
            maxSeq = num;
          }
        }
      }
    });
  } else {
    maxSeq = typeof transactionsOrCount === 'number' ? transactionsOrCount : 0;
  }

  const indexStr = String(maxSeq + 1).padStart(2, '0');
  return `${prefix}/${month}/${year}/${indexStr}`;
}

/**
 * Renumbers all transactions sequentially starting from 01 per month for MEMO (Saldo Awal), BKM, and BKK.
 * Format: MEMO/MM/YYYY/01, BKM/MM/YYYY/01, BKK/MM/YYYY/01
 */
export function renumberAllTransactions(txs: Transaction[]): Transaction[] {
  if (!txs || txs.length === 0) return [];

  const sorted = [...txs].sort((a, b) => {
    const dateDiff = (a.tanggal || '').localeCompare(b.tanggal || '');
    if (dateDiff !== 0) return dateDiff;
    return (a.createdAt || '').localeCompare(b.createdAt || '');
  });

  const memoCounters: Record<string, number> = {};
  const bkmCounters: Record<string, number> = {};
  const bkkCounters: Record<string, number> = {};
  const newNomorMap = new Map<string, string>();

  sorted.forEach((t) => {
    const parts = (t.tanggal || '').split('-');
    const year = parts[0] || new Date().getFullYear().toString();
    const month = parts[1] || String(new Date().getMonth() + 1).padStart(2, '0');
    const period = `${year}-${month}`;

    if (t.jenis === 'Saldo Awal') {
      memoCounters[period] = (memoCounters[period] || 0) + 1;
      const seqStr = String(memoCounters[period]).padStart(2, '0');
      newNomorMap.set(t.id, `MEMO/${month}/${year}/${seqStr}`);
    } else if (t.jenis === 'Pemasukan' || (t.jenis === 'Mutasi Kas' && t.pemasukan > 0)) {
      bkmCounters[period] = (bkmCounters[period] || 0) + 1;
      const seqStr = String(bkmCounters[period]).padStart(2, '0');
      newNomorMap.set(t.id, `BKM/${month}/${year}/${seqStr}`);
    } else {
      bkkCounters[period] = (bkkCounters[period] || 0) + 1;
      const seqStr = String(bkkCounters[period]).padStart(2, '0');
      newNomorMap.set(t.id, `BKK/${month}/${year}/${seqStr}`);
    }
  });

  return txs.map((t) => {
    const newNo = newNomorMap.get(t.id);
    if (newNo) {
      return { ...t, nomorBukti: newNo };
    }
    return t;
  });
}

export function exportTransactionsToCSV(transactions: Transaction[], schoolName: string) {
  const headers = ['ID', 'Nomor Bukti', 'Tanggal', 'Jenis', 'Kategori', 'Uraian', 'Pihak Terkait', 'Pemasukan (Rp)', 'Pengeluaran (Rp)', 'Metode Pembayaran'];
  
  const rows = transactions.map(t => [
    `"${t.id}"`,
    `"${t.nomorBukti || '-'}"`,
    `"${t.tanggal}"`,
    `"${t.jenis}"`,
    `"${t.kategori}"`,
    `"${t.uraian.replace(/"/g, '""')}"`,
    `"${(t.pihak || '-').replace(/"/g, '""')}"`,
    t.pemasukan,
    t.pengeluaran,
    `"${t.metodePembayaran || 'Tunai / Kas'}"`
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + 
    [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `Laporan_Keuangan_${schoolName.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
