import React, { useState, useMemo } from 'react';
import { X, Printer, ArrowLeft, Scissors, Calendar, Filter, FileText, CheckCircle2, Layers } from 'lucide-react';
import { SchoolProfile, Transaction } from '../types';
import { formatRupiah, terbilang, formatDateIndonesian } from '../utils/formatters';

interface BatchKwitansiModalProps {
  transactions: Transaction[];
  schoolProfile: SchoolProfile;
  initialMonth?: string; // YYYY-MM
  onClose: () => void;
}

interface KwitansiItemProps {
  transaction: Transaction;
  schoolProfile: SchoolProfile;
  copyType: 'arsip' | 'umum';
  includeReceipt: boolean;
  compact?: boolean;
}

const KwitansiItem: React.FC<KwitansiItemProps> = ({
  transaction,
  schoolProfile,
  copyType,
  includeReceipt,
  compact = false
}) => {
  const isSaldoAwal = transaction.jenis === 'Saldo Awal' || (transaction.nomorBukti && transaction.nomorBukti.startsWith('MEMO'));
  const isMasuk = transaction.jenis === 'Pemasukan' || transaction.jenis === 'Saldo Awal';
  const rawNominal = isMasuk ? transaction.pemasukan : transaction.pengeluaran;
  const isNegativeSaldoAwal = isSaldoAwal && rawNominal < 0;
  const isSchoolCopy = copyType === 'arsip';

  let kwTitle = 'KWITANSI';
  let numberLabel = 'Nomor Kwitansi';

  if (isSaldoAwal) {
    kwTitle = isNegativeSaldoAwal ? 'MEMO PENETAPAN SALDO AWAL (DEFISIT)' : 'MEMO PENETAPAN SALDO AWAL';
    numberLabel = 'Nomor Memo';
  } else if (isSchoolCopy) {
    kwTitle = isMasuk ? 'BUKTI KAS MASUK (BKM)' : 'BUKTI KAS KELUAR (BKK)';
    numberLabel = isMasuk ? 'Nomor BKM' : 'Nomor BKK';
  }

  const rawNumber = transaction.nomorBukti || transaction.id;
  let numberValue = rawNumber;
  if (!isSaldoAwal && !isSchoolCopy) {
    numberValue = (rawNumber.startsWith('BKM') || rawNumber.startsWith('BKK')
      ? rawNumber.replace(/^BKM|^BKK/, 'KW')
      : `KW-${rawNumber}`);
  }

  const terbilangText = isNegativeSaldoAwal
    ? `Defisit ${terbilang(Math.abs(rawNominal))} Rupiah`
    : `${terbilang(rawNominal)} Rupiah`;

  const copyBadgeText = isSchoolCopy
    ? (isSaldoAwal ? 'LEMBAR ARSIP SEKOLAH (MEMO)' : 'LEMBAR ARSIP SEKOLAH (BKM/BKK)')
    : (isSaldoAwal ? 'LEMBAR DOKUMENTASI BENDAHARA' : 'LEMBAR PEMBAYAR / UMUM (KWITANSI)');

  return (
    <div className={`bg-white border border-slate-300 text-slate-900 rounded-xl font-serif relative print:border-slate-800 print:rounded-none break-inside-avoid print:break-inside-avoid batch-kwitansi-item ${
      compact ? 'p-3 print:p-2 text-xs' : 'p-4 print:p-3 text-xs sm:text-sm'
    }`}>
      {/* Category Badge Top Right */}
      <div className="absolute top-2.5 right-2.5 bg-slate-100 border border-slate-400 text-slate-800 font-sans font-bold text-[9px] px-2 py-0.5 rounded uppercase tracking-wider print:top-2 print:right-2 print:text-[8px]">
        {copyBadgeText}
      </div>

      {/* Kop Surat Header */}
      <div className="flex items-center space-x-2.5 border-b-2 border-slate-900 pb-1.5 mb-2 print:pb-1 print:mb-1.5">
        <div className="h-9 w-9 sm:h-10 sm:w-10 rounded border border-slate-300 bg-slate-50 flex items-center justify-center p-0.5 shrink-0 overflow-hidden print:h-7 print:w-7">
          {schoolProfile.logoUrl ? (
            <img src={schoolProfile.logoUrl} alt="Logo" className="h-full w-full object-contain" />
          ) : (
            <span className="font-bold font-sans text-xs text-slate-800">SMK</span>
          )}
        </div>
        <div>
          <h2 className="text-sm sm:text-base font-bold uppercase tracking-tight text-slate-900 m-0 leading-tight print:text-xs">
            {schoolProfile.namaSekolah || 'SMK NEGERI 1 JAKARTA'}
          </h2>
          <p className="text-[10px] font-sans font-semibold text-emerald-800 print:text-[8px]">
            {isSaldoAwal ? 'Dokumen Internal Penetapan Saldo Awal' : 'Bukti Transaksi Keuangan Resmi'}
          </p>
        </div>
      </div>

      {/* Kwitansi Title & Number */}
      <div className="text-center mb-2 print:mb-1">
        <h3 className="text-xs sm:text-sm font-bold underline uppercase text-slate-900 m-0 print:text-[11px]">
          {kwTitle}
        </h3>
        <p className="text-[10px] font-mono text-slate-700 mt-0.5 print:text-[9px]">
          {numberLabel}: <span className="font-bold">{numberValue}</span>
        </p>
      </div>

      {/* Table Content */}
      <table className="w-full text-xs font-sans mb-2 border-collapse print:text-[9.5px] print:mb-1">
        <tbody>
          <tr className="border-b border-slate-200">
            <td className="py-0.5 font-semibold text-slate-700 w-1/3">
              {isSaldoAwal ? 'Penanggung Jawab' : (isMasuk ? 'Sudah Terima Dari' : 'Dibayarkan Kepada')}
            </td>
            <td className="py-0.5 w-3 font-bold">:</td>
            <td className="py-0.5 font-bold text-slate-900">
              {transaction.pihak || (isMasuk ? 'Penyetor' : 'Penerima')}
            </td>
          </tr>

          <tr className="border-b border-slate-200">
            <td className="py-0.5 font-semibold text-slate-700">Tanggal Transaksi</td>
            <td className="py-0.5 font-bold">:</td>
            <td className="py-0.5 font-bold text-slate-900">
              {formatDateIndonesian(transaction.tanggal)}
            </td>
          </tr>

          <tr className="border-b border-slate-200">
            <td className="py-0.5 font-semibold text-slate-700">Terbilang</td>
            <td className="py-0.5 font-bold">:</td>
            <td className="py-0.5 italic font-serif font-bold text-slate-900">
              {terbilangText}
            </td>
          </tr>

          <tr className="border-b border-slate-200">
            <td className="py-0.5 font-semibold text-slate-700">Untuk Pembayaran</td>
            <td className="py-0.5 font-bold">:</td>
            <td className="py-0.5">
              <span className="font-bold text-emerald-800">
                [{transaction.jenis}] - {transaction.kategori}
              </span>
              <div className="text-[11px] print:text-[9px] text-slate-800 leading-tight">
                {transaction.uraian}
              </div>
            </td>
          </tr>
        </tbody>
      </table>

      {/* Amount Badge */}
      <div className="mb-2 print:mb-1 flex items-center justify-between">
        <div className={`inline-block font-mono font-extrabold text-xs print:text-[11px] px-2.5 py-0.5 rounded border ${
          isNegativeSaldoAwal
            ? 'bg-rose-50 text-red-600 border-red-600'
            : 'bg-slate-50 text-slate-900 border-slate-900'
        }`}>
          {formatRupiah(rawNominal)}
        </div>

        {includeReceipt && transaction.buktiNotaUrl && (
          <span className="text-[9px] font-sans font-semibold text-emerald-700 bg-emerald-50 border border-emerald-300 px-2 py-0.5 rounded">
            📎 Ada Lampiran Nota
          </span>
        )}
      </div>

      {/* Signatures */}
      <div className="font-sans text-[10px] print:text-[8.5px] text-center text-slate-800 mt-2 print:mt-1">
        <div className="grid grid-cols-3 gap-1">
          <div>
            <p className="text-[9px] print:text-[7.5px]">Mengetahui,</p>
            <p className="font-bold">Kepala Sekolah</p>
            <div className="h-8 print:h-5" />
            <p className="font-bold underline">{schoolProfile.kepalaSekolah || '....................'}</p>
          </div>

          <div>
            <p className="text-[9px] print:text-[7.5px]">&nbsp;</p>
            <p className="font-bold">
              {isSaldoAwal ? 'Penanggung Jawab' : (isMasuk ? 'Penyetor' : 'Penerima Uang')}
            </p>
            <div className="h-8 print:h-5" />
            <p className="font-bold underline">( {transaction.pihak || '....................'} )</p>
          </div>

          <div>
            <p className="text-[9px] print:text-[7.5px]">
              {schoolProfile.kota || 'Jakarta'}, {formatDateIndonesian(transaction.tanggal)}
            </p>
            <p className="font-bold">Bendahara Sekolah</p>
            <div className="h-8 print:h-5" />
            <p className="font-bold underline">{schoolProfile.bendahara || '....................'}</p>
          </div>
        </div>
      </div>

      {/* Embedded Nota Preview if requested & present */}
      {includeReceipt && transaction.buktiNotaUrl && !transaction.buktiNotaUrl.startsWith('data:application/pdf') && (
        <div className="mt-2 pt-2 border-t-2 border-dashed border-slate-300 print:mt-1.5 print:pt-1 bg-slate-50 p-2 rounded-lg border border-slate-200 break-inside-avoid print:break-inside-avoid bukti-attachment-box">
          <div className="flex items-center justify-between text-[10px] print:text-[8.5px] font-sans font-bold text-slate-700 mb-1">
            <span className="flex items-center gap-1.5 text-emerald-800">
              📎 Lampiran Bukti Fisik Nota / Kwitansi / Struk Asli:
            </span>
            <span className="font-mono text-[9px] text-slate-500">{transaction.buktiNotaName || 'Nota_Terlampir'}</span>
          </div>
          <div className={`${compact ? 'max-h-60 sm:max-h-72 print:max-h-[210px]' : 'max-h-80 sm:max-h-[480px] print:max-h-[380px]'} overflow-hidden flex justify-center bg-white border border-slate-300 p-1.5 rounded-lg shadow-xs break-inside-avoid print:break-inside-avoid`}>
            <img
              src={transaction.buktiNotaUrl}
              alt="Lampiran Bukti Fisik Nota"
              className={`${compact ? 'max-h-56 sm:max-h-68 print:max-h-[190px]' : 'max-h-76 sm:max-h-[460px] print:max-h-[360px]'} w-auto max-w-full object-contain rounded`}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export const BatchKwitansiModal: React.FC<BatchKwitansiModalProps> = ({
  transactions,
  schoolProfile,
  initialMonth,
  onClose
}) => {
  // Extract month options from transactions
  const monthOptions = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach(t => {
      if (t.tanggal && t.tanggal.length >= 7) {
        set.add(t.tanggal.substring(0, 7)); // YYYY-MM
      }
    });
    const sorted = Array.from(set).sort().reverse();
    const MONTH_NAMES = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];

    return sorted.map(ym => {
      const [year, monthStr] = ym.split('-');
      const monthIdx = parseInt(monthStr, 10) - 1;
      const name = MONTH_NAMES[monthIdx] || monthStr;
      return {
        value: ym,
        label: `${name} ${year}`
      };
    });
  }, [transactions]);

  const defaultMonth = initialMonth || (monthOptions[0]?.value || new Date().toISOString().substring(0, 7));

  const [selectedMonth, setSelectedMonth] = useState<string>(defaultMonth);
  const [filterJenis, setFilterJenis] = useState<'ALL' | 'BKK' | 'BKM' | 'MUTASI'>('ALL');
  const [copyMode, setCopyMode] = useState<'both' | 'arsip' | 'umum'>('both');
  const [layoutMode, setLayoutMode] = useState<'auto' | '3-per-page' | '2-per-page' | '1-per-page'>('auto');
  const [includeReceipt, setIncludeReceipt] = useState<boolean>(true);

  React.useEffect(() => {
    document.title = `Bukti_Transaksi_Batch_${selectedMonth}`;
    document.body.classList.add('has-kwitansi-open');
    return () => {
      document.title = 'Sistem Keuangan Sekolah';
      document.body.classList.remove('has-kwitansi-open');
    };
  }, [selectedMonth]);

  // Filter transactions for selected month & jenis
  const targetTransactions = useMemo(() => {
    return transactions.filter(t => {
      if (!t.tanggal || !t.tanggal.startsWith(selectedMonth)) return false;

      if (filterJenis === 'BKK') {
        return t.jenis === 'Pengeluaran';
      }
      if (filterJenis === 'BKM') {
        return t.jenis === 'Pemasukan';
      }
      if (filterJenis === 'MUTASI') {
        return t.jenis === 'Mutasi Kas' || t.jenis === 'Saldo Awal';
      }
      return true; // ALL
    }).sort((a, b) => new Date(a.tanggal).getTime() - new Date(b.tanggal).getTime() || a.id.localeCompare(b.id));
  }, [transactions, selectedMonth, filterJenis]);

  const handlePrintBatch = () => {
    const originalTitle = document.title;
    document.title = `Bukti_Transaksi_Batch_${selectedMonth}`;
    window.print();
    setTimeout(() => {
      document.title = originalTitle;
    }, 1000);
  };

  // Group items into print pages
  const renderPrintPages = () => {
    if (targetTransactions.length === 0) {
      return (
        <div className="bg-white p-12 text-center text-slate-500 rounded-xl border border-slate-200">
          Tidak ada transaksi pada bulan yang dipilih dengan filter tersebut.
        </div>
      );
    }

    // Generate voucher render list (each item represents 1 physical voucher slip)
    const vouchersToRender: { tx: Transaction; copyType: 'arsip' | 'umum' }[] = [];
    
    targetTransactions.forEach(tx => {
      if (copyMode === 'both' || copyMode === 'arsip') {
        vouchersToRender.push({ tx, copyType: 'arsip' });
      }
      if (copyMode === 'both' || copyMode === 'umum') {
        vouchersToRender.push({ tx, copyType: 'umum' });
      }
    });

    if (layoutMode === '1-per-page') {
      return vouchersToRender.map((v, idx) => (
        <div key={`${v.tx.id}-${v.copyType}-${idx}`} className="batch-page bg-white p-4 sm:p-6 mb-6 print:mb-0 print:min-h-[280mm] flex flex-col justify-between border border-slate-200 print:border-none rounded-xl print:rounded-none">
          <KwitansiItem
            transaction={v.tx}
            schoolProfile={schoolProfile}
            copyType={v.copyType}
            includeReceipt={includeReceipt}
          />
        </div>
      ));
    }

    // Dynamic grouping into pages based on layoutMode
    const pages: (typeof vouchersToRender)[] = [];
    let currentPage: typeof vouchersToRender = [];

    for (const voucher of vouchersToRender) {
      const voucherHasReceipt = includeReceipt && !!voucher.tx.buktiNotaUrl;

      let maxItemsForPage = 2;

      if (layoutMode === '3-per-page') {
        maxItemsForPage = 3;
      } else if (layoutMode === '2-per-page') {
        maxItemsForPage = 2;
      } else {
        // 'auto' mode:
        // 2 per page if any voucher in current page or this voucher has a receipt attachment;
        // 3 per page if no voucher has an attachment!
        const pageAlreadyHasReceipt = currentPage.some(item => includeReceipt && !!item.tx.buktiNotaUrl);
        if (pageAlreadyHasReceipt || voucherHasReceipt) {
          maxItemsForPage = 2;
        } else {
          maxItemsForPage = 3;
        }
      }

      if (currentPage.length >= maxItemsForPage) {
        pages.push(currentPage);
        currentPage = [voucher];
      } else {
        currentPage.push(voucher);
      }
    }

    if (currentPage.length > 0) {
      pages.push(currentPage);
    }

    return pages.map((pageGroup, pageIdx) => (
      <div
        key={`page-${pageIdx}`}
        className="batch-page bg-white p-4 sm:p-6 mb-6 print:mb-0 border border-slate-200 print:border-none rounded-xl print:rounded-none space-y-3 print:space-y-2"
      >
        {pageGroup.map((v, itemIdx) => (
          <React.Fragment key={`${v.tx.id}-${v.copyType}-${itemIdx}`}>
            {itemIdx > 0 && (
              <>
                <div className="flex items-center justify-center gap-2 text-slate-400 my-1.5 text-xs font-mono no-print">
                  <Scissors className="w-3.5 h-3.5 text-slate-500" />
                  <span>---------------- POTONG DI SINI ----------------</span>
                </div>
                <div className="hidden print:block border-b border-dashed border-slate-400 my-1 text-center text-[7.5px] font-mono text-slate-400">
                  ---------------- POTONG DI SINI ----------------
                </div>
              </>
            )}
            <KwitansiItem
              transaction={v.tx}
              schoolProfile={schoolProfile}
              copyType={v.copyType}
              includeReceipt={includeReceipt}
              compact={pageGroup.length > 1}
            />
          </React.Fragment>
        ))}
      </div>
    ));
  };

  const selectedMonthLabel = monthOptions.find(m => m.value === selectedMonth)?.label || selectedMonth;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto no-print-bg">
      <div className="bg-slate-900 text-white rounded-2xl shadow-2xl border border-slate-800 w-full max-w-5xl overflow-hidden my-6 print:my-0 print:border-none print:shadow-none print:rounded-none">
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 flex items-center justify-between no-print">
          <div className="flex items-center space-x-3">
            <button
              onClick={onClose}
              className="mr-1 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 py-1.5 rounded-lg text-xs flex items-center gap-1 cursor-pointer border border-slate-700"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Kembali</span>
            </button>
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Cetak Bukti Transaksi 1 Bulan sekaligus (BKK &amp; BKM)</h3>
              <p className="text-xs text-slate-400">
                Batch print dokumen resmi BKK, BKM, dan Kwitansi untuk arsip bulanan
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              id="btn-print-batch-top"
              onClick={handlePrintBatch}
              disabled={targetTransactions.length === 0}
              className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak {targetTransactions.length} Transaksi</span>
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Filter Controls Bar (Screen Only) */}
        <div className="bg-slate-800/90 px-6 py-4 border-b border-slate-700 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs text-white no-print">
          
          {/* Month Selector */}
          <div>
            <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              Pilih Bulan Transaksi:
            </label>
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-bold focus:outline-none focus:border-emerald-500"
            >
              {monthOptions.map(m => (
                <option key={m.value} value={m.value}>{m.label}</option>
              ))}
            </select>
          </div>

          {/* Jenis Bukti Filter */}
          <div>
            <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-emerald-400" />
              Filter Jenis Bukti:
            </label>
            <select
              value={filterJenis}
              onChange={(e) => setFilterJenis(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-bold focus:outline-none focus:border-emerald-500"
            >
              <option value="ALL">Semua (BKK + BKM + Mutasi)</option>
              <option value="BKK">Bukti Kas Keluar (BKK) Saja</option>
              <option value="BKM">Bukti Kas Masuk (BKM) Saja</option>
              <option value="MUTASI">Mutasi &amp; Memo Saja</option>
            </select>
          </div>

          {/* Copy Mode */}
          <div>
            <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-emerald-400" />
              Rangkap Lembar Cetak:
            </label>
            <select
              value={copyMode}
              onChange={(e) => setCopyMode(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-bold focus:outline-none focus:border-emerald-500"
            >
              <option value="both">2 Rangkap (Arsip + Umum)</option>
              <option value="arsip">1 Rangkap (Arsip Sekolah)</option>
              <option value="umum">1 Rangkap (Pembayar / Umum)</option>
            </select>
          </div>

          {/* Layout Mode */}
          <div>
            <label className="block text-slate-300 font-bold mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-emerald-400" />
              Format Layout A4:
            </label>
            <select
              value={layoutMode}
              onChange={(e) => setLayoutMode(e.target.value as any)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-bold focus:outline-none focus:border-emerald-500"
            >
              <option value="auto">⚡ Otomatis (2/Hal jika ada Lampiran, 3/Hal jika Tanpa Lampiran)</option>
              <option value="3-per-page">3 Bukti Per Halaman A4</option>
              <option value="2-per-page">2 Bukti Per Halaman A4</option>
              <option value="1-per-page">1 Bukti Per Halaman A4</option>
            </select>
          </div>

        </div>

        {/* Checkbox options & info bar */}
        <div className="bg-slate-900 px-6 py-2 border-b border-slate-800 flex items-center justify-between text-xs no-print">
          <label className="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
            <input
              type="checkbox"
              checked={includeReceipt}
              onChange={(e) => setIncludeReceipt(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded border-slate-700 focus:ring-emerald-500 cursor-pointer"
            />
            <span className="font-semibold">Sertakan Gambar Nota / Bukti Fisik jika Terlampir</span>
          </label>

          <span className="text-slate-400 font-mono text-[11px]">
            Periode: <strong className="text-emerald-400">{selectedMonthLabel}</strong> ({targetTransactions.length} transaksi)
          </span>
        </div>

        {/* Preview Printable Area */}
        <div className="p-6 bg-slate-950 max-h-[65vh] overflow-y-auto space-y-4 text-slate-900 print:p-0 print:bg-white print:max-h-none print:overflow-visible" id="printable-batch">
          {renderPrintPages()}
        </div>

        {/* Modal Bottom Action Footer */}
        <div className="bg-slate-900 px-6 py-4 border-t border-slate-800 flex items-center justify-between no-print">
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer border border-slate-700"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Tutup</span>
          </button>

          <button
            id="btn-print-batch-bottom"
            onClick={handlePrintBatch}
            disabled={targetTransactions.length === 0}
            className="bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold px-6 py-2.5 rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-lg transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak {targetTransactions.length} Transaksi ({selectedMonthLabel})</span>
          </button>
        </div>

      </div>
    </div>
  );
};
