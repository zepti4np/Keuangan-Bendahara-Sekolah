import React, { useState, useEffect } from 'react';
import { X, Printer, FileText, Check, ChevronLeft, ChevronRight, School, Landmark } from 'lucide-react';
import { Student, SppPayment, AnnualFeePayment, SchoolProfile } from '../types';
import { formatRupiah, formatDateIndonesian } from '../utils/formatters';
import { ACADEMIC_MONTHS } from './SppManagerView';

interface StudentSuratModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  initialStudentId?: string | null;
  sppPayments: SppPayment[];
  annualPayments: AnnualFeePayment[];
  schoolProfile: SchoolProfile;
  selectedAcademicYear: string; // e.g. "2026/2027"
}

export const StudentSuratModal: React.FC<StudentSuratModalProps> = ({
  isOpen,
  onClose,
  students,
  initialStudentId,
  sppPayments,
  annualPayments,
  schoolProfile,
  selectedAcademicYear
}) => {
  if (!isOpen) return null;

  // Selected Mode: 'single' or 'all'
  const [printMode, setPrintMode] = useState<'single' | 'all'>('single');
  const [paperSize, setPaperSize] = useState<'f4' | 'a4'>('f4');
  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    initialStudentId || (students[0] ? students[0].id : '')
  );

  // Options for Letter Header & Bank Info
  const [nomorSuratPrefix, setNomorSuratPrefix] = useState('04.70/SPb/SMKYMB/VII');
  const [namaBank, setNamaBank] = useState('BNI');
  const [noRekening, setNoRekening] = useState('546054603');
  const [atasNamaBank, setAtasNamaBank] = useState('SMK YAMABA PURWAKARTA');
  const [tanggalSurat, setTanggalSurat] = useState(() => {
    const today = new Date();
    return `${today.getDate()} ${
      ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'][today.getMonth()]
    } ${today.getFullYear()}`;
  });

  // Calculate Academic Years
  const [startYearStr, endYearStr] = selectedAcademicYear.split('/');
  const startYear = parseInt(startYearStr, 10) || 2026;
  const endYear = parseInt(endYearStr, 10) || 2027;

  // Sync initial student if changed
  useEffect(() => {
    if (initialStudentId) {
      setSelectedStudentId(initialStudentId);
    } else if (students.length > 0 && !selectedStudentId) {
      setSelectedStudentId(students[0].id);
    }
  }, [initialStudentId, students]);

  // Target students to render
  const targetStudents = printMode === 'all'
    ? students
    : students.filter(s => s.id === selectedStudentId);

  // Navigation for single mode
  const currentIndex = students.findIndex(s => s.id === selectedStudentId);
  const handlePrevStudent = () => {
    if (currentIndex > 0) {
      setSelectedStudentId(students[currentIndex - 1].id);
    }
  };
  const handleNextStudent = () => {
    if (currentIndex < students.length - 1) {
      setSelectedStudentId(students[currentIndex + 1].id);
    }
  };

  const handlePrint = () => {
    document.body.classList.add('has-surat-open');
    if (paperSize === 'f4') {
      document.body.classList.add('has-f4-print');
      document.body.classList.remove('has-a4-print');
    } else {
      document.body.classList.add('has-a4-print');
      document.body.classList.remove('has-f4-print');
    }

    const originalTitle = document.title;
    document.title = `Surat_Pemberitahuan_Ortu_${targetStudents.length === 1 ? targetStudents[0].nama.replace(/\s+/g, '_') : 'Semua_Siswa'}`;
    window.print();
    setTimeout(() => {
      document.body.classList.remove('has-surat-open', 'has-f4-print', 'has-a4-print');
      document.title = originalTitle;
    }, 1000);
  };

  // Helper for formatting clean number without Rp symbol for table rows
  const formatNumberOnly = (val: number) => {
    if (!val || val <= 0) return '-';
    return new Intl.NumberFormat('id-ID').format(val);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/70 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white print:static print:inset-auto">
      {/* Modal Container */}
      <div className="bg-slate-100 rounded-2xl shadow-2xl border border-slate-300 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden print:border-none print:shadow-none print:max-w-none print:max-h-none print:bg-white print:rounded-none">
        
        {/* Modal Header (Non-Printable) */}
        <div className="p-4 bg-white border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0 print:hidden">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-100 rounded-xl text-emerald-800">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 text-base">
                Cetak Surat Pemberitahuan Biaya Pendidikan
              </h3>
              <p className="text-xs text-slate-500">
                Surat pemberitahuan rincian SPP &amp; tagihan tahunan untuk orang tua/wali murid
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              Cetak PDF / Print Surat
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Settings Bar (Non-Printable) */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0 print:hidden">
          {/* Print Mode & Paper Size Selectors */}
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-slate-700">Mode Cetak:</span>
              <div className="flex bg-slate-200 p-0.5 rounded-lg">
                <button
                  type="button"
                  onClick={() => setPrintMode('single')}
                  className={`px-2.5 py-1 font-bold rounded-md transition-all cursor-pointer ${
                    printMode === 'single' ? 'bg-white text-emerald-900 shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  1 Siswa Selected
                </button>
                <button
                  type="button"
                  onClick={() => setPrintMode('all')}
                  className={`px-2.5 py-1 font-bold rounded-md transition-all cursor-pointer ${
                    printMode === 'all' ? 'bg-white text-emerald-900 shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  Semua Siswa ({students.length})
                </button>
              </div>
            </div>

            <div className="flex items-center gap-1.5 border-l border-slate-300 pl-3">
              <span className="font-bold text-slate-700">Ukuran Kertas:</span>
              <div className="flex bg-slate-200 p-0.5 rounded-lg">
                <button
                  type="button"
                  onClick={() => setPaperSize('f4')}
                  className={`px-2.5 py-1 font-bold rounded-md transition-all cursor-pointer ${
                    paperSize === 'f4' ? 'bg-emerald-700 text-white shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  F4 / Folio (215×330 mm)
                </button>
                <button
                  type="button"
                  onClick={() => setPaperSize('a4')}
                  className={`px-2.5 py-1 font-bold rounded-md transition-all cursor-pointer ${
                    paperSize === 'a4' ? 'bg-emerald-700 text-white shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  A4 (210×297 mm)
                </button>
              </div>
            </div>

            {printMode === 'single' && (
              <div className="flex items-center gap-1.5 ml-1">
                <select
                  value={selectedStudentId}
                  onChange={(e) => setSelectedStudentId(e.target.value)}
                  className="bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-800 focus:outline-none focus:border-emerald-500 cursor-pointer max-w-[200px] truncate"
                >
                  {students.map((s, idx) => (
                    <option key={s.id} value={s.id}>
                      {idx + 1}. {s.nama} ({s.kelas})
                    </option>
                  ))}
                </select>

                <button
                  onClick={handlePrevStudent}
                  disabled={currentIndex <= 0}
                  className="p-1 border border-slate-300 rounded-lg bg-white disabled:opacity-40 cursor-pointer hover:bg-slate-100"
                  title="Siswa Sebelumnya"
                >
                  <ChevronLeft className="w-4 h-4 text-slate-600" />
                </button>
                <button
                  onClick={handleNextStudent}
                  disabled={currentIndex >= students.length - 1}
                  className="p-1 border border-slate-300 rounded-lg bg-white disabled:opacity-40 cursor-pointer hover:bg-slate-100"
                  title="Siswa Selanjutnya"
                >
                  <ChevronRight className="w-4 h-4 text-slate-600" />
                </button>
              </div>
            )}
          </div>

          {/* Quick Bank & Date Options */}
          <div className="flex flex-wrap items-center gap-2">
            <div>
              <span className="text-slate-500 mr-1">No. Surat:</span>
              <input
                type="text"
                value={nomorSuratPrefix}
                onChange={(e) => setNomorSuratPrefix(e.target.value)}
                className="bg-white border border-slate-300 rounded px-2 py-0.5 text-xs font-mono font-bold text-slate-800 w-36"
              />
            </div>
            <div>
              <span className="text-slate-500 mr-1">Bank:</span>
              <input
                type="text"
                value={namaBank}
                onChange={(e) => setNamaBank(e.target.value)}
                className="bg-white border border-slate-300 rounded px-2 py-0.5 text-xs font-bold text-slate-800 w-16"
              />
            </div>
            <div>
              <span className="text-slate-500 mr-1">No. Rek:</span>
              <input
                type="text"
                value={noRekening}
                onChange={(e) => setNoRekening(e.target.value)}
                className="bg-white border border-slate-300 rounded px-2 py-0.5 text-xs font-mono text-slate-800 w-28"
              />
            </div>
            <div>
              <span className="text-slate-500 mr-1">A.N:</span>
              <input
                type="text"
                value={atasNamaBank}
                onChange={(e) => setAtasNamaBank(e.target.value)}
                className="bg-white border border-slate-300 rounded px-2 py-0.5 text-xs font-bold text-slate-800 w-36"
              />
            </div>
            <div>
              <span className="text-slate-500 mr-1">Tanggal:</span>
              <input
                type="text"
                value={tanggalSurat}
                onChange={(e) => setTanggalSurat(e.target.value)}
                className="bg-white border border-slate-300 rounded px-2 py-0.5 text-xs text-slate-800 w-28"
              />
            </div>
          </div>
        </div>

        {/* Printable View Container */}
        <div className="p-4 sm:p-8 overflow-y-auto flex-1 bg-slate-200/60 print:p-0 print:bg-white print:overflow-visible">
          {targetStudents.length === 0 ? (
            <div className="text-center py-12 text-slate-500 font-semibold bg-white rounded-xl">
              Tidak ada siswa yang dipilih.
            </div>
          ) : (
            <div className="space-y-8 print:space-y-0">
              {targetStudents.map((s, studentIdx) => {
                // Calculate SPP per month for this student
                let totalSppPaid = 0;
                const monthlyPayments: { [key: string]: number } = {};

                ACADEMIC_MONTHS.forEach(m => {
                  const calYear = startYear + m.yearOffset;
                  const payment = sppPayments.find(
                    p => p.studentId === s.id && p.month === m.month && p.year === calYear
                  );
                  const paid = payment ? payment.nominalDibayar || 0 : 0;
                  monthlyPayments[m.name] = paid;
                  totalSppPaid += paid;
                });

                // Calculate Annual Fees
                const studentAnnualPayments = annualPayments.filter(
                  p => p.studentId === s.id && (p.year === startYear || p.year === endYear)
                );
                const totalAnnPaid = studentAnnualPayments.reduce((acc, p) => acc + (p.nominalDibayar || 0), 0);

                const targetSppYear = (s.nominalSppBulanan || 0) * 12;
                const tunggakanSpp = Math.max(0, targetSppYear - totalSppPaid);
                
                const targetTahunan = s.nominalTagihanTahunan || 0;
                const tunggakanTahunan = Math.max(0, targetTahunan - totalAnnPaid);
                const totalTunggakan = tunggakanSpp + tunggakanTahunan;

                const annPelunasanPct = targetTahunan > 0
                  ? Math.min(100, Math.round((totalAnnPaid / targetTahunan) * 100))
                  : 0;

                const letterNumber = `${nomorSuratPrefix.split('/')[0]}.${(studentIdx + 1).toString().padStart(2, '0')}/${nomorSuratPrefix.split('/').slice(1).join('/') || 'SPb/SMKYMB/VII/' + startYear}`;

                return (
                  <div
                    key={s.id}
                    className={`bg-white mx-auto shadow-md border border-slate-300 p-5 sm:p-8 print:p-2 font-serif text-slate-900 w-full ${
                      paperSize === 'f4' ? 'max-w-[215mm] min-h-[330mm]' : 'max-w-[210mm] min-h-[297mm]'
                    } print:min-h-0 print:h-auto print:shadow-none print:border-none print:max-w-none print:m-0 print:w-full surat-page-item`}
                  >
                    {/* KOP SURAT HEADER */}
                    <div className="flex items-center justify-between gap-3 border-b-4 border-double border-slate-900 pb-2 mb-2 print:pb-1 print:mb-1.5">
                      {/* Left Logo - Yayasan */}
                      <div className="w-14 h-14 sm:w-18 sm:h-18 print:w-12 print:h-12 shrink-0 flex items-center justify-center">
                        {schoolProfile.logoYayasanUrl ? (
                          <img 
                            src={schoolProfile.logoYayasanUrl} 
                            alt="Logo Yayasan" 
                            className="max-h-full max-w-full object-contain"
                          />
                        ) : (
                          <div className="w-12 h-12 border border-slate-900 flex flex-col items-center justify-center p-0.5 text-center bg-slate-50">
                            <School className="w-5 h-5 text-slate-800 mb-0.5" />
                            <span className="text-[6.5px] font-sans font-bold uppercase leading-none">Yayasan</span>
                          </div>
                        )}
                      </div>

                      {/* Header Center Text */}
                      <div className="text-center flex-1 font-sans">
                        <p className="text-xs sm:text-sm print:text-[11px] font-bold uppercase tracking-wider text-slate-900 m-0 leading-tight">
                          YAYASAN MAHABAKTI ANAK BANGSA
                        </p>
                        <h1 className="text-sm sm:text-lg print:text-base font-black uppercase text-slate-900 m-0 leading-tight tracking-wide">
                          {schoolProfile.namaSekolah || 'SMKS YAMABA PURWAKARTA'}
                        </h1>
                        <p className="text-[8.5px] sm:text-[9.5px] print:text-[8px] text-slate-800 m-0 leading-tight mt-0.5">
                          {schoolProfile.alamat || 'Jln. Raya Bungursari Kp. Tirtaraya RT 02 RW 01 Telp. (0264)8302348'}
                        </p>
                        <p className="text-[8.5px] sm:text-[9.5px] print:text-[8px] text-slate-800 m-0 leading-tight">
                          Purwakarta Kode Pos 41181, Email : {schoolProfile.email || 'smkyamabapwk@gmail.com'}
                        </p>
                        <p className="text-[8px] sm:text-[9px] print:text-[7.5px] font-bold text-slate-900 m-0 leading-tight mt-0.5 uppercase tracking-tight">
                          TEKNOLOGI, REKAYASA DAN BISNIS MANAJEMEN
                        </p>
                        <p className="text-[7px] sm:text-[8px] print:text-[6.5px] text-slate-700 m-0 leading-tight italic">
                          Teknik Kendaraan Ringan – Teknik Pemeliharaan Mekanik Industri – Teknik Sepeda Motor – Teknik Komputer Jaringan – Akuntansi – Keperawatan - Farmasi
                        </p>
                      </div>

                      {/* Right Logo - School */}
                      <div className="w-14 h-14 sm:w-18 sm:h-18 print:w-12 print:h-12 shrink-0 flex items-center justify-center">
                        {schoolProfile.logoUrl ? (
                          <img src={schoolProfile.logoUrl} alt="Logo Sekolah" className="max-h-full max-w-full object-contain" />
                        ) : (
                          <div className="w-12 h-12 border-2 border-slate-900 rounded-full flex flex-col items-center justify-center p-0.5 text-center bg-slate-50">
                            <Landmark className="w-5 h-5 text-slate-900" />
                            <span className="text-[6px] font-sans font-bold uppercase leading-none mt-0.5">SMK YAMABA</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* JUDUL SURAT & NOMOR */}
                    <div className="text-center font-sans mb-2 print:mb-1.5">
                      <h2 className="text-xs sm:text-sm print:text-xs font-bold uppercase underline tracking-wider text-slate-900 m-0">
                        SURAT PEMBERITAHUAN
                      </h2>
                      <p className="text-[9.5px] sm:text-[10.5px] print:text-[9px] font-mono text-slate-800 m-0 mt-0.5">
                        Nomor: {letterNumber}
                      </p>
                    </div>

                    {/* META INFORMASI SURAT */}
                    <div className="font-sans text-[9.5px] sm:text-[10.5px] print:text-[9px] leading-tight mb-2 print:mb-1.5">
                      <div className="grid grid-cols-12 gap-1 mb-1 print:mb-0.5">
                        <div className="col-span-2 font-semibold text-slate-800">Perihal</div>
                        <div className="col-span-10 font-bold text-slate-900">: Pemberitahuan Biaya Pendidikan dan Kewajiban Pembayaran</div>
                      </div>
                      <p className="m-0 font-semibold text-slate-800">Kepada Yth.</p>
                      <p className="m-0 font-bold uppercase text-slate-900">
                        Bapak/Ibu Orang Tua/Wali Murid {s.nama}
                      </p>
                      <p className="m-0 text-slate-800">di Tempat</p>
                    </div>

                    {/* ISI SURAT & DATA SISWA */}
                    <div className="font-sans text-[9.5px] sm:text-[10.5px] print:text-[9px] leading-tight mb-2 print:mb-1.5 text-justify">
                      <p className="m-0 mb-1 print:mb-0.5">Dengan hormat,</p>
                      <p className="m-0 mb-1.5 print:mb-1 text-slate-800">
                        Dalam rangka tertib administrasi dan kelancaran kegiatan operasional sekolah, kami sampaikan bahwa berdasarkan data administrasi keuangan sekolah diantaranya pembayaran SPP dan biaya tahunan, dengan rincian sebagai berikut :
                      </p>

                      <div className="bg-slate-50 border border-slate-300 p-2 rounded-lg mb-1.5 print:bg-white print:border-none print:p-0 print:mb-1">
                        <table className="text-[9.5px] sm:text-[10.5px] print:text-[9px] font-sans">
                          <tbody>
                            <tr>
                              <td className="pr-1.5 py-0.25 font-semibold text-slate-700 whitespace-nowrap">Nama Siswa</td>
                              <td className="pr-2 py-0.25 font-bold">:</td>
                              <td className="py-0.25 font-bold uppercase text-slate-900">{s.nama}</td>
                            </tr>
                            <tr>
                              <td className="pr-1.5 py-0.25 font-semibold text-slate-700 whitespace-nowrap">NISN</td>
                              <td className="pr-2 py-0.25 font-bold">:</td>
                              <td className="py-0.25 font-bold font-mono text-slate-900">{s.nisn || '-'}</td>
                            </tr>
                            <tr>
                              <td className="pr-1.5 py-0.25 font-semibold text-slate-700 whitespace-nowrap">Kelas</td>
                              <td className="pr-2 py-0.25 font-bold">:</td>
                              <td className="py-0.25 font-bold uppercase text-slate-900">{s.kelas}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* TABEL RINCIAN SPP BULANAN (JULI - JUNI) SESUAI APLIKASI */}
                    <div className="font-sans mb-2 print:mb-1.5">
                      <div className="relative overflow-hidden border border-slate-900">
                        <table className="w-full text-left text-[9.5px] sm:text-[10.5px] print:text-[8.5px] border-collapse">
                          <thead>
                            <tr className="bg-slate-100 border-b border-slate-900 font-bold text-slate-900 text-[9px] print:text-[8px]">
                              <th className="px-2 py-1 print:py-0.5 uppercase border-r border-slate-900 w-36">
                                Bulan &amp; Tahun
                              </th>
                              <th className="px-2 py-1 print:py-0.5 uppercase border-r border-slate-900 text-right w-28">
                                Tarif SPP
                              </th>
                              <th className="px-2 py-1 print:py-0.5 uppercase border-r border-slate-900 text-center w-28">
                                Status
                              </th>
                              <th className="px-2 py-1 print:py-0.5 uppercase text-right border-r border-slate-900">
                                Nominal Dibayar
                              </th>
                              <th className="w-10 px-1 py-1 print:py-0.5 text-center font-bold border-slate-900">
                                Tahun
                              </th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-300">
                            {ACADEMIC_MONTHS.map((m, idx) => {
                              const calYear = startYear + m.yearOffset;
                              const amount = monthlyPayments[m.name] || 0;
                              const tarif = s.nominalSppBulanan || 0;
                              const isPaid = amount >= tarif && tarif > 0;
                              const isPartial = amount > 0 && amount < tarif;
                              const statusText = isPaid ? 'LUNAS' : isPartial ? 'CICILAN' : 'BELUM BAYAR';

                              return (
                                <tr key={m.name} className="hover:bg-slate-50">
                                  <td className="px-2 py-0.5 print:py-0.25 font-semibold text-slate-800 border-r border-slate-300">
                                    {m.name} {calYear}
                                  </td>
                                  <td className="px-2 py-0.5 print:py-0.25 font-mono text-right text-slate-700 border-r border-slate-300">
                                    Rp {formatNumberOnly(tarif)}
                                  </td>
                                  <td className="px-2 py-0.5 print:py-0.25 text-center font-bold text-[8.5px] print:text-[8px] border-r border-slate-300">
                                    <span className={isPaid ? 'text-emerald-800 font-bold' : isPartial ? 'text-amber-800 font-bold' : 'text-slate-500 font-normal'}>
                                      {statusText}
                                    </span>
                                  </td>
                                  <td className="px-2 py-0.5 print:py-0.25 font-mono font-bold text-right text-slate-900 border-r border-slate-900">
                                    Rp {formatNumberOnly(amount)}
                                  </td>

                                  {/* Right side Year Indicator Bracket */}
                                  {idx === 0 && (
                                    <td rowSpan={6} className="text-center font-bold text-xs font-mono border-b border-slate-900 bg-slate-50/50 align-middle">
                                      <div className="transform -rotate-90 whitespace-nowrap text-slate-800 font-extrabold tracking-widest text-[10px] print:text-[9px]">
                                        {startYear}
                                      </div>
                                    </td>
                                  )}
                                  {idx === 6 && (
                                    <td rowSpan={6} className="text-center font-bold text-xs font-mono bg-slate-50/50 align-middle">
                                      <div className="transform -rotate-90 whitespace-nowrap text-slate-800 font-extrabold tracking-widest text-[10px] print:text-[9px]">
                                        {endYear}
                                      </div>
                                    </td>
                                  )}
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* RINGKASAN REKAPITULASI TAGIHAN & PEMBAYARAN SESUAI APLIKASI */}
                    <div className="font-sans text-[9.5px] sm:text-[10.5px] print:text-[8.5px] mb-2 print:mb-1.5 border border-slate-900">
                      <div className="bg-slate-100 px-2.5 py-1 print:py-0.5 font-bold uppercase tracking-wide text-slate-900 border-b border-slate-900 text-[10px] print:text-[8.5px]">
                        Rekapitulasi Tagihan &amp; Pembayaran (Tapel {selectedAcademicYear})
                      </div>
                      <table className="w-full border-collapse">
                        <tbody>
                          {/* 1. RINCIAN SPP BULANAN */}
                          <tr className="bg-slate-50 font-bold border-b border-slate-300">
                            <td colSpan={4} className="py-0.5 print:py-0.25 px-2.5 text-slate-900 uppercase">
                              1. SPP Bulanan (Juli {startYear} - Juni {endYear})
                            </td>
                          </tr>
                          <tr className="border-b border-slate-200">
                            <td className="py-0.5 print:py-0.25 pl-5 font-semibold text-slate-800 w-64">Tarif SPP / Bulan</td>
                            <td className="py-0.5 print:py-0.25 font-bold w-4 text-center">:</td>
                            <td className="py-0.5 print:py-0.25 font-mono font-semibold text-slate-900 w-8 text-left">Rp</td>
                            <td className="py-0.5 print:py-0.25 pr-2.5 font-mono font-bold text-right text-slate-900">
                              {formatNumberOnly(s.nominalSppBulanan)}
                            </td>
                          </tr>
                          <tr className="border-b border-slate-200">
                            <td className="py-0.5 print:py-0.25 pl-5 font-semibold text-slate-800">Total Target SPP 1 Tahun (12 Bulan)</td>
                            <td className="py-0.5 print:py-0.25 font-bold text-center">:</td>
                            <td className="py-0.5 print:py-0.25 font-mono font-semibold text-slate-900 text-left">Rp</td>
                            <td className="py-0.5 print:py-0.25 pr-2.5 font-mono font-bold text-right text-slate-900">
                              {formatNumberOnly(targetSppYear)}
                            </td>
                          </tr>
                          <tr className="border-b border-slate-200">
                            <td className="py-0.5 print:py-0.25 pl-5 font-semibold text-slate-800">Total SPP Sudah Dibayar</td>
                            <td className="py-0.5 print:py-0.25 font-bold text-center">:</td>
                            <td className="py-0.5 print:py-0.25 font-mono font-semibold text-slate-900 text-left">Rp</td>
                            <td className="py-0.5 print:py-0.25 pr-2.5 font-mono font-bold text-right text-slate-900">
                              {formatNumberOnly(totalSppPaid)}
                            </td>
                          </tr>
                          <tr className="border-b-2 border-slate-900 bg-slate-50/80">
                            <td className="py-0.5 print:py-0.25 pl-5 font-bold text-slate-900">Sisa Tunggakan SPP</td>
                            <td className="py-0.5 print:py-0.25 font-bold text-center">:</td>
                            <td className="py-0.5 print:py-0.25 font-mono font-bold text-slate-900 text-left">Rp</td>
                            <td className="py-0.5 print:py-0.25 pr-2.5 font-mono font-black text-right text-slate-900">
                              {formatNumberOnly(tunggakanSpp)}
                            </td>
                          </tr>

                          {/* 2. RINCIAN TAGIHAN TAHUNAN */}
                          <tr className="bg-slate-50 font-bold border-b border-slate-300">
                            <td colSpan={4} className="py-0.5 print:py-0.25 px-2.5 text-slate-900 uppercase">
                              2. Tagihan Tahunan (Tapel {selectedAcademicYear})
                            </td>
                          </tr>
                          <tr className="border-b border-slate-200">
                            <td className="py-0.5 print:py-0.25 pl-5 font-semibold text-slate-800">Total Kewajiban Tagihan Tahunan</td>
                            <td className="py-0.5 print:py-0.25 font-bold text-center">:</td>
                            <td className="py-0.5 print:py-0.25 font-mono font-semibold text-slate-900 text-left">Rp</td>
                            <td className="py-0.5 print:py-0.25 pr-2.5 font-mono font-bold text-right text-slate-900">
                              {formatNumberOnly(targetTahunan)}
                            </td>
                          </tr>
                          <tr className="border-b border-slate-200">
                            <td className="py-0.5 print:py-0.25 pl-5 font-semibold text-slate-800">Total Tagihan Tahunan Sudah Dibayar</td>
                            <td className="py-0.5 print:py-0.25 font-bold text-center">:</td>
                            <td className="py-0.5 print:py-0.25 font-mono font-semibold text-slate-900 text-left">Rp</td>
                            <td className="py-0.5 print:py-0.25 pr-2.5 font-mono font-bold text-right text-slate-900">
                              {formatNumberOnly(totalAnnPaid)}
                            </td>
                          </tr>
                          <tr className="border-b-2 border-slate-900 bg-slate-50/80">
                            <td className="py-0.5 print:py-0.25 pl-5 font-bold text-slate-900">
                              Sisa Tunggakan Tagihan Tahunan
                            </td>
                            <td className="py-0.5 print:py-0.25 font-bold text-center">:</td>
                            <td className="py-0.5 print:py-0.25 font-mono font-bold text-slate-900 text-left">Rp</td>
                            <td className="py-0.5 print:py-0.25 pr-2.5 font-mono font-black text-right text-slate-900">
                              {formatNumberOnly(tunggakanTahunan)}
                            </td>
                          </tr>

                          {/* 3. TOTAL TUNGGAKAN ALL */}
                          <tr className="border-t-2 border-b-2 border-slate-900 bg-slate-100 font-bold">
                            <td className="py-1 print:py-0.5 px-2.5 uppercase tracking-wide text-slate-900">
                              TOTAL BELUM DIBAYAR (TUNGGAKAN SPP + TAHUNAN)
                            </td>
                            <td className="py-1 print:py-0.5 text-center">:</td>
                            <td className="py-1 print:py-0.5 font-mono text-slate-900 text-left">Rp</td>
                            <td className="py-1 print:py-0.5 pr-2.5 font-mono font-black text-right text-slate-900 text-xs print:text-[10px]">
                              {formatNumberOnly(totalTunggakan)}
                            </td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    {/* PETUNJUK TRANSFER REKENING BANK */}
                    <div className="font-sans text-[9px] sm:text-[10px] print:text-[8.5px] leading-tight mb-2 print:mb-1.5 text-justify">
                      <p className="m-0 mb-1 print:mb-0.5 text-slate-800">
                        Kami berharap pembayaran dapat dilakukan tepat waktu. Jika terdapat kendala, silakan menghubungi pihak sekolah untuk mendapatkan arahan lebih lanjut. Untuk pembayaran melalui transfer dapat ke rekening sekolah di bawah ini:
                      </p>

                      <table className="text-[9px] sm:text-[10px] print:text-[8.5px] font-sans font-semibold">
                        <tbody>
                          <tr>
                            <td className="pr-1.5 py-0.25 text-slate-700 whitespace-nowrap">Nama Bank</td>
                            <td className="pr-2 py-0.25">:</td>
                            <td className="py-0.25 font-bold text-slate-900">{namaBank}</td>
                          </tr>
                          <tr>
                            <td className="pr-1.5 py-0.25 text-slate-700 whitespace-nowrap">No. Rekening</td>
                            <td className="pr-2 py-0.25">:</td>
                            <td className="py-0.25 font-mono font-bold text-slate-900">{noRekening}</td>
                          </tr>
                          <tr>
                            <td className="pr-1.5 py-0.25 text-slate-700 whitespace-nowrap">Atas Nama</td>
                            <td className="pr-2 py-0.25">:</td>
                            <td className="py-0.25 font-bold uppercase text-slate-900">{atasNamaBank}</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    {/* PENUTUP SURAT & TANDA TANGAN */}
                    <div className="font-sans text-[9px] sm:text-[10px] print:text-[8.5px] leading-tight">
                      <p className="m-0 mb-3 print:mb-1.5 text-slate-800 text-justify">
                        Apabila Bapak/Ibu telah melakukan pembayaran, mohon mengkonfirmasi kepada bagian administrasi keuangan dengan membawa bukti pembayaran agar data dapat segera diperbarui. Demikian surat pemberitahuan ini kami sampaikan. Atas perhatian dan kerja sama Bapak/Ibu, kami ucapkan terima kasih.
                      </p>

                      <div className="flex justify-end mt-2 print:mt-1">
                        <div className="text-left w-56 sm:w-60">
                          <p className="m-0 text-slate-800">
                            {schoolProfile.kota || 'Purwakarta'}, {tanggalSurat}
                          </p>
                          <p className="m-0 font-bold text-slate-900 mb-16 print:mb-14">
                            Bendahara Sekolah
                          </p>
                          <p className="m-0 font-bold underline text-slate-900">
                            {schoolProfile.bendahara || 'Zeptian Pratama, S.Pd'}
                          </p>
                          <p className="m-0 font-mono text-slate-800">
                            NIP: {schoolProfile.nipBendahara || '-'}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
