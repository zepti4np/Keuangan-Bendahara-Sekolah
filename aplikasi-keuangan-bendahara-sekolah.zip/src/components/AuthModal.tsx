import React, { useState } from 'react';
import { X, LogIn, UserPlus, Cloud, CheckCircle2, AlertCircle, ShieldCheck, Mail, Lock, User as UserIcon } from 'lucide-react';
import { User } from 'firebase/auth';
import { googleSignIn, emailLogin, emailRegister, logoutUser } from '../services/firebaseAuth';

interface AuthModalProps {
  currentUser: User | null;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ currentUser, onClose }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleGoogleLogin = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await googleSignIn();
      setSuccessMsg(`Berhasil masuk sebagai ${res.user.email || res.user.displayName}`);
      setTimeout(() => {
        onClose();
      }, 1000);
    } catch (err: any) {
      console.error(err);
      let msg = err.message || 'Gagal login dengan Google';
      if (msg.includes('auth/unauthorized-domain')) {
        msg = 'Login Google Popup diblokir karena domain ini belum diizinkan di Authorized Domains Firebase. Silakan gunakan formulir Email & Password di bawah (Langsung Berhasil 100% tanpa perlu izin domain).';
      }
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setErrorMsg('Email dan Password wajib diisi');
      return;
    }

    setLoading(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      if (mode === 'register') {
        const user = await emailRegister(email, password, displayName);
        setSuccessMsg(`Akun berhasil dibuat! Selamat datang, ${user.displayName || user.email}`);
      } else {
        const user = await emailLogin(email, password);
        setSuccessMsg(`Berhasil login sebagai ${user.displayName || user.email}`);
      }
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      console.error(err);
      let msg = err.message || 'Terjadi kesalahan saat otentikasi';
      if (msg.includes('auth/invalid-credential') || msg.includes('auth/wrong-password') || msg.includes('auth/user-not-found')) {
        msg = 'Email atau password salah. Silakan periksa kembali.';
      } else if (msg.includes('auth/email-already-in-use')) {
        msg = 'Email ini sudah terdaftar. Silakan pilih tab Masuk.';
      } else if (msg.includes('auth/weak-password')) {
        msg = 'Password terlalu lemah. Minimal 6 karakter.';
      } else if (msg.includes('auth/unauthorized-domain')) {
        msg = 'Domain ini belum masuk daftar Authorized Domains Firebase. Silakan gunakan formulir Email & Password di bawah.';
      }
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    setLoading(true);
    try {
      await logoutUser();
      setSuccessMsg('Berhasil keluar akun');
      setTimeout(() => {
        onClose();
      }, 800);
    } catch (err: any) {
      setErrorMsg('Gagal keluar akun: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Modal */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between relative">
          <div className="flex items-center space-x-3">
            <div className="bg-emerald-500/20 text-emerald-400 p-2 rounded-xl">
              <Cloud className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">
                {currentUser ? 'Akun Google & Firebase Cloud' : 'Login Cloud Multi-Device'}
              </h3>
              <p className="text-xs text-slate-300">
                Akses & sinkronisasi data dari perangkat / Gmail berbeda
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 space-y-5 text-slate-800">
          
          {/* Status Current User */}
          {currentUser ? (
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 text-center space-y-3">
              <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-700 font-bold text-lg">
                {currentUser.photoURL ? (
                  <img src={currentUser.photoURL} alt="Avatar" className="w-12 h-12 rounded-full object-cover" />
                ) : (
                  (currentUser.displayName || currentUser.email || 'U')[0].toUpperCase()
                )}
              </div>
              <div>
                <p className="text-xs font-semibold text-emerald-800 uppercase tracking-wider">Status Terhubung</p>
                <p className="font-bold text-slate-900 text-sm mt-0.5">{currentUser.displayName || 'Pengguna Terdaftar'}</p>
                <p className="text-xs text-slate-600 font-mono mt-0.5">{currentUser.email}</p>
              </div>
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-semibold rounded-full">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                Data Tersinkronisasi Realtime Cloud
              </div>

              <button
                onClick={handleLogout}
                disabled={loading}
                className="w-full mt-2 bg-slate-100 hover:bg-rose-50 text-slate-700 hover:text-rose-700 border border-slate-300 hover:border-rose-200 font-bold py-2 px-4 rounded-xl text-xs transition-all cursor-pointer"
              >
                {loading ? 'Memproses...' : 'Keluar Akun'}
              </button>
            </div>
          ) : (
            <>
              {/* Alert Feedback Messages */}
              {errorMsg && (
                <div className="bg-rose-50 border border-rose-200 text-rose-800 px-3.5 py-2.5 rounded-xl text-xs flex items-start space-x-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {successMsg && (
                <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-3.5 py-2.5 rounded-xl text-xs flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{successMsg}</span>
                </div>
              )}

              {/* 1. Quick Google Login */}
              <div>
                <button
                  type="button"
                  onClick={handleGoogleLogin}
                  disabled={loading}
                  className="w-full bg-white hover:bg-slate-50 text-slate-800 font-bold py-2.5 px-4 border border-slate-300 rounded-xl shadow-xs text-sm flex items-center justify-center space-x-2 transition-all cursor-pointer active:scale-98"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                    />
                  </svg>
                  <span>{loading ? 'Menghubungkan Google...' : 'Masuk dengan Akun Google (1-Klik)'}</span>
                </button>
              </div>

              <div className="relative flex py-1 items-center">
                <div className="grow border-t border-slate-200"></div>
                <span className="shrink font-semibold mx-3 text-[11px] text-slate-400 uppercase tracking-wider">
                  atau dengan Email & Password
                </span>
                <div className="grow border-t border-slate-200"></div>
              </div>

              {/* Mode Toggle: Login / Register */}
              <div className="flex bg-slate-100 p-1 rounded-xl">
                <button
                  type="button"
                  onClick={() => setMode('login')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    mode === 'login'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <LogIn className="w-3.5 h-3.5 inline mr-1" />
                  Masuk Akun
                </button>
                <button
                  type="button"
                  onClick={() => setMode('register')}
                  className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                    mode === 'register'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <UserPlus className="w-3.5 h-3.5 inline mr-1" />
                  Daftar Akun Baru
                </button>
              </div>

              {/* Email & Password Form */}
              <form onSubmit={handleEmailAuth} className="space-y-3">
                {mode === 'register' && (
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Nama Lengkap / Nama Bendahara
                    </label>
                    <div className="relative">
                      <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                      <input
                        type="text"
                        placeholder="Contoh: Ahmad Subagyo"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                        className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Alamat Email
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="email"
                      required
                      placeholder="nama@sekolah.sch.id"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Password / Kata Sandi
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="password"
                      required
                      placeholder="Minimal 6 karakter"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                    />
                  </div>
                  {mode === 'login' ? (
                    <p className="text-[11px] text-slate-500 mt-1">
                      *Belum pernah mendaftar? Klik tombol tab <strong>"Daftar Akun Baru"</strong> di atas untuk membuat kata sandi Anda sendiri.
                    </p>
                  ) : (
                    <p className="text-[11px] text-slate-500 mt-1">
                      *Buat password bebas yang mudah Anda ingat (minimal 6 karakter).
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2.5 px-4 rounded-xl text-xs shadow-sm transition-all cursor-pointer active:scale-98 mt-2"
                >
                  {loading
                    ? 'Memproses...'
                    : mode === 'login'
                    ? 'Masuk ke Aplikasi Kas'
                    : 'Buat Akun Kas Baru'}
                </button>
              </form>

              {/* Info Box */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-[11px] text-slate-600 flex items-start space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <p>
                  Setiap transaksi kas dan hasil impor Excel yang Anda catat akan tersimpan di <strong>Firebase Cloud Database</strong>. Anda dapat login dengan akun yang sama di HP, laptop, atau akun Gmail lain untuk melihat & mengelola kas secara bersamaan!
                </p>
              </div>
            </>
          )}

        </div>
      </div>
    </div>
  );
};
