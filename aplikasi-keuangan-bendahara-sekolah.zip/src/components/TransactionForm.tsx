import React, { useState, useEffect } from 'react';
import { PlusCircle, Save, X, Calculator, CreditCard, Calendar, Tag, FileText, User } from 'lucide-react';
import { CategoryData, Transaction, TransactionType } from '../types';
import { generateNomorBukti, formatRupiah } from '../utils/formatters';

interface TransactionFormProps {
  categoryData: CategoryData;
  onSave: (transaction: Omit<Transaction, 'id' | 'createdAt'>) => void;
  onClose?: () => void;
  totalTransactionCount: number;
  transactions?: Transaction[];
}

export const TransactionForm: React.FC<TransactionFormProps> = ({
  categoryData,
  onSave,
  onClose,
  totalTransactionCount,
  transactions = []
}) => {
  const todayStr = new Date().toISOString().slice(0, 10);
  
  const [tanggal, setTanggal] = useState<string>(todayStr);
  const [jenis, setJenis] = useState<TransactionType>('Pemasukan');
  const [kategori, setKategori] = useState<string>('');
  const [uraian, setUraian] = useState<string>('');
  const [nominal, setNominal] = useState<string>('');
  const [pihak, setPihak] = useState<string>('');
  const [metodePembayaran, setMetodePembayaran] = useState<'Tunai / Kas' | 'Transfer Bank' | 'Cek / Giro'>('Tunai / Kas');
  const [isRealDaily, setIsRealDaily] = useState<boolean>(true);

  // Update categories when jenis changes
  useEffect(() => {
    const categoriesForJenis = categoryData[jenis] || [];
    if (categoriesForJenis.length > 0) {
      setKategori(categoriesForJenis[0]);
    } else {
      setKategori('');
    }
  }, [jenis, categoryData]);

  const nomorBuktiPreview = generateNomorBukti(jenis, transactions, tanggal);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(nominal);

    if (isNaN(amount)) {
      alert('Silakan masukkan nominal transaksi yang valid');
      return;
    }

    if (amount === 0) {
      alert('Silakan masukkan nominal transaksi yang valid (tidak boleh 0)');
      return;
    }

    if (jenis !== 'Saldo Awal' && amount < 0) {
      alert('Silakan masukkan nominal transaksi yang lebih besar dari 0');
      return;
    }

    if (!uraian.trim()) {
      alert('Silakan isi Uraian / Keterangan transaksi');
      return;
    }

    const isMasuk = jenis === 'Pemasukan' || jenis === 'Saldo Awal';

    onSave({
      tanggal,
      jenis,
      kategori: kategori || 'Lain-lain',
      uraian: uraian.trim(),
      pemasukan: isMasuk ? amount : 0,
      pengeluaran: !isMasuk ? amount : 0,
      pihak: pihak.trim() || (isMasuk ? 'Penyetor' : 'Penerima'),
      nomorBukti: nomorBuktiPreview,
      metodePembayaran,
      isRealDaily
    });

    // Reset Form
    setUraian('');
    setNominal('');
    setPihak('');
    if (onClose) onClose();
  };

  const handleQuickNominal = (val: number) => {
    setNominal(val.toString());
  };

  // Close on ESC key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && onClose) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-xs overflow-y-auto no-print">
      <div className="bg-white rounded-2xl border border-slate-200 w-full max-w-2xl text-slate-900 shadow-2xl relative my-8 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <PlusCircle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg text-white">Catat Transaksi Keuangan</h3>
              <p className="text-xs text-slate-300">Pencatatan Pemasukan, Pengeluaran, Saldo Awal &amp; Mutasi Kas</p>
            </div>
          </div>
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
              title="Tutup (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-6 max-h-[80vh] overflow-y-auto space-y-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Nomor Bukti Preview Badge */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between">
              <span className="text-xs text-slate-600 font-medium flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-emerald-600" />
                {jenis === 'Saldo Awal' ? 'Nomor Memo Auto:' : 'Nomor Bukti Auto:'}
              </span>
              <span className="font-mono text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 px-3 py-1 rounded-lg">
                {nomorBuktiPreview}
              </span>
            </div>

        {/* Row 1: Tanggal & Jenis */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
              Tanggal Transaksi
            </label>
            <input
              id="input-tanggal"
              type="date"
              value={tanggal}
              onChange={(e) => setTanggal(e.target.value)}
              required
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
              <Tag className="w-3.5 h-3.5 text-emerald-600" />
              Jenis Transaksi
            </label>
            <select
              id="select-jenis"
              value={jenis}
              onChange={(e) => setJenis(e.target.value as TransactionType)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
            >
              <option value="Pemasukan">Pemasukan (Kas Masuk)</option>
              <option value="Pengeluaran">Pengeluaran (Kas Keluar)</option>
              <option value="Saldo Awal">Saldo Awal</option>
              <option value="Mutasi Kas">Mutasi Kas</option>
            </select>
          </div>
        </div>

        {/* Row 2: Kategori & Metode */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Kategori Sub-Anggaran
            </label>
            <select
              id="select-kategori"
              value={kategori}
              onChange={(e) => setKategori(e.target.value)}
              required
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
            >
              {(categoryData[jenis] || []).map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
              <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
              Metode Pembayaran
            </label>
            <select
              id="select-metode"
              value={metodePembayaran}
              onChange={(e) => setMetodePembayaran(e.target.value as any)}
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
            >
              <option value="Tunai / Kas">Tunai / Kas Utama</option>
              <option value="Transfer Bank">Transfer Bank (Non-Tunai)</option>
              <option value="Cek / Giro">Cek / Giro Sekolah</option>
            </select>
          </div>
        </div>

        {/* Pihak Terkait (Penyetor / Penerima) */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1 flex items-center gap-1">
            <User className="w-3.5 h-3.5 text-emerald-600" />
            Pihak Pembayar / Penerima Uang (Kwitansi)
          </label>
          <input
            id="input-pihak"
            type="text"
            value={pihak}
            onChange={(e) => setPihak(e.target.value)}
            placeholder={
              jenis === 'Pemasukan' || jenis === 'Saldo Awal'
                ? 'Contoh: Wali Siswa Class X / Dinas Pendidikan'
                : 'Contoh: CV Utama Jaya Stationer / Nama Guru'
            }
            className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* Uraian */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Uraian / Keterangan Pembayaran
          </label>
          <textarea
            id="input-uraian"
            rows={2}
            value={uraian}
            onChange={(e) => setUraian(e.target.value)}
            placeholder="Ketik rincian uraian transaksi secara jelas..."
            required
            className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />
        </div>

        {/* Nominal (Rp) */}
        <div>
          <div className="flex justify-between items-center mb-1">
            <label className="text-xs font-semibold text-slate-700 flex items-center gap-1">
              <Calculator className="w-3.5 h-3.5 text-emerald-600" />
              Nominal Transaksi (Rp)
            </label>
            {nominal && !isNaN(parseFloat(nominal)) && (
              <span className="text-xs font-bold text-emerald-700 font-mono">
                {formatRupiah(parseFloat(nominal))}
              </span>
            )}
          </div>
          <input
            id="input-nominal"
            type="number"
            step="any"
            value={nominal}
            onChange={(e) => setNominal(e.target.value)}
            placeholder={jenis === 'Saldo Awal' ? 'Bebas input (Positif / Negatif)' : '0'}
            required
            className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2.5 text-base font-bold font-mono text-emerald-700 placeholder-slate-400 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />
          {jenis === 'Saldo Awal' && (
            <p className="text-[11px] text-blue-700 font-medium mt-1">
              💡 <strong>Bebas Nominal:</strong> Saldo awal dapat bernilai positif (surplus) atau negatif (defisit, contoh: <code className="bg-blue-100 px-1 rounded font-bold">-1500000</code>).
            </p>
          )}

          {/* Quick Nominal Buttons */}
          <div className="flex flex-wrap gap-1.5 mt-2">
            {[100000, 250000, 500000, 1000000, 2500000, 5000000, 10000000].map((val) => (
              <button
                key={val}
                type="button"
                onClick={() => handleQuickNominal(val)}
                className="text-[11px] font-mono bg-slate-100 hover:bg-slate-200 text-slate-700 px-2 py-1 rounded border border-slate-200 transition-colors cursor-pointer"
              >
                +{val >= 1000000 ? `${val / 1000000}Jt` : `${val / 1000}Rb`}
              </button>
            ))}
          </div>
        </div>

        {/* Pilihan Sinkronisasi dengan Kas Real */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <input
              id="checkbox-is-real-daily"
              type="checkbox"
              checked={isRealDaily}
              onChange={(e) => setIsRealDaily(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer"
            />
            <label htmlFor="checkbox-is-real-daily" className="text-xs font-bold text-slate-800 cursor-pointer select-none">
              Disinkronkan dengan Pantau Kas Real
            </label>
          </div>
          <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
            isRealDaily 
              ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
              : 'bg-amber-100 text-amber-800 border border-amber-300'
          }`}>
            {isRealDaily ? 'Tersinkron Kas Real' : 'Tidak Disinkron Kas Real'}
          </span>
        </div>

        {/* Notice for Saldo Awal & Operational Synchronization */}
        <div className={`p-3 rounded-xl text-xs flex items-center gap-2.5 border ${
          !isRealDaily
            ? 'bg-amber-50 border-amber-200 text-amber-900'
            : jenis === 'Saldo Awal' 
              ? 'bg-blue-50 border-blue-200 text-blue-900'
              : 'bg-emerald-50 border-emerald-200 text-emerald-900'
        }`}>
          <FileText className={`w-4 h-4 shrink-0 ${
            !isRealDaily ? 'text-amber-600' : jenis === 'Saldo Awal' ? 'text-blue-600' : 'text-emerald-600'
          }`} />
          <p className="text-[11px] leading-snug">
            {!isRealDaily ? (
              <span><strong>Transaksi Tidak Disinkron Kas Real:</strong> Transaksi ini tercatat pada Dashboard Utama &amp; Laporan Umum, tetapi <strong className="underline">TIDAK dimasukkan ke Rekap Harian Kas Real</strong>.</span>
            ) : jenis === 'Saldo Awal' ? (
              <span><strong>Saldo Kas Awal Tersinkronasi:</strong> Memo Saldo Kas Awal otomatis tersimpan dan tersinkronisasi penuh antara Dashboard Utama, Pantau Kas Real, dan Laporan Keuangan.</span>
            ) : (
              <span><strong>Transaksi Operasional Tersinkronasi:</strong> Transaksi otomatis tersimpan dan tersinkronisasi penuh antara Dashboard Utama, Pantau Kas Real, dan Laporan Keuangan.</span>
            )}
          </p>
        </div>

        {/* Form Action Submit */}
        <div className="pt-2">
          <button
            id="btn-submit-transaksi"
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center space-x-2 shadow-lg hover:shadow-emerald-500/20 transition-all active:scale-98 cursor-pointer min-h-[44px]"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Transaksi Keuangan</span>
          </button>
        </div>
      </form>
        </div>
      </div>
    </div>
  );
};
