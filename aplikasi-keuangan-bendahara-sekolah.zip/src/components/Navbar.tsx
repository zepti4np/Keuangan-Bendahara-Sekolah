import React, { useState } from 'react';
import { 
  Building2, 
  LayoutDashboard, 
  FileSpreadsheet, 
  BarChart3, 
  FolderTree, 
  Settings, 
  Plus, 
  Download, 
  Upload,
  RotateCcw,
  School,
  FileText,
  User as UserIcon,
  Cloud,
  GraduationCap,
  Database,
  Menu,
  X,
  RefreshCw,
  Clock
} from 'lucide-react';
import { User } from 'firebase/auth';
import { SchoolProfile } from '../types';

interface NavbarProps {
  activeTab: 'dashboard' | 'spp' | 'real-daily' | 'laporan' | 'analytics' | 'categories';
  setActiveTab: (tab: 'dashboard' | 'spp' | 'real-daily' | 'laporan' | 'analytics' | 'categories') => void;
  schoolProfile: SchoolProfile;
  currentUser: User | null;
  onOpenAuth: () => void;
  onOpenSettings: () => void;
  onOpenBackupRestore: () => void;
  onOpenNewTransaction: () => void;
  onOpenExcelImport: () => void;
  onOpenGoogleSheetsSync: () => void;
  onExportCSV: () => void;
  onExportExcel: () => void;
  onResetData: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  schoolProfile,
  currentUser,
  onOpenAuth,
  onOpenSettings,
  onOpenBackupRestore,
  onOpenNewTransaction,
  onOpenExcelImport,
  onOpenGoogleSheetsSync,
  onExportCSV,
  onExportExcel,
  onResetData
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white shadow-xl sticky top-0 z-30 no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & School Info */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            <div className="h-11 w-11 sm:h-12 sm:w-12 rounded-xl bg-white border border-white/20 flex items-center justify-center shadow-inner shrink-0 overflow-hidden p-1">
              {schoolProfile.logoUrl ? (
                <img src={schoolProfile.logoUrl} alt="Logo Sekolah" className="h-full w-full object-contain" />
              ) : (
                <School className="w-6 h-6 sm:w-7 sm:h-7 text-emerald-700" />
              )}
            </div>
            <div className="overflow-hidden">
              <div className="flex items-center space-x-2">
                <span className="bg-emerald-500/30 text-emerald-200 text-[10px] sm:text-xs px-2 py-0.5 rounded font-mono font-medium border border-emerald-400/30">
                  SI-KAS BENDAHARA
                </span>
                {currentUser && (
                  <span className="hidden sm:inline-flex items-center gap-1 bg-amber-400/20 text-amber-300 text-[10px] px-2 py-0.5 rounded font-bold border border-amber-400/30">
                    <Cloud className="w-3 h-3" /> Cloud Active
                  </span>
                )}
              </div>
              <h1 className="text-base sm:text-xl font-bold tracking-tight text-white leading-snug truncate">
                {schoolProfile.namaSekolah || 'Aplikasi Keuangan Sekolah'}
              </h1>
              <p className="text-[11px] sm:text-xs text-emerald-200/80 truncate max-w-[200px] sm:max-w-md">
                {schoolProfile.alamat || 'Sistem Informasi Manajemen Kas & Laporan Keuangan'}
              </p>
            </div>
          </div>

          {/* Action Buttons Desktop */}
          <div className="hidden md:flex items-center space-x-2">
            <button
              id="btn-login-cloud"
              onClick={onOpenAuth}
              title="Akun & Cloud Multi-Device Sync"
              className={`font-bold px-3 py-2 rounded-lg text-xs lg:text-sm flex items-center space-x-1.5 shadow-md transition-all cursor-pointer border ${
                currentUser
                  ? 'bg-emerald-800/80 hover:bg-emerald-700 text-emerald-100 border-emerald-500/50'
                  : 'bg-amber-500 hover:bg-amber-400 text-amber-950 border-amber-300'
              }`}
            >
              <Cloud className="w-4 h-4 shrink-0" />
              <span className="truncate max-w-[120px]">
                {currentUser ? (currentUser.displayName || currentUser.email?.split('@')[0] || 'Akun Cloud') : 'Login Cloud'}
              </span>
            </button>

            {/* Dropdown for Actions (Hidden by default to keep header clean) */}
            <div className="relative">
              <button
                id="btn-toggle-data-actions"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="bg-emerald-800/80 hover:bg-emerald-700 text-emerald-100 border border-emerald-600/50 font-bold px-3 py-2 rounded-lg text-xs lg:text-sm flex items-center space-x-1.5 shadow-md transition-all cursor-pointer"
              >
                <Database className="w-4 h-4 text-emerald-300" />
                <span>Menu Aksi Data</span>
              </button>

              {isMobileMenuOpen && (
                <div 
                  className="absolute right-0 mt-2 w-56 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-2 z-50 text-xs font-semibold animate-in fade-in zoom-in-95 duration-150"
                  onClick={(e) => e.stopPropagation()}
                >
                  <div className="px-3 py-1.5 text-[10px] text-slate-400 font-bold uppercase tracking-wider border-b border-slate-800">
                    Alat & Manajemen Data
                  </div>
                  
                  <button
                    id="btn-catat-transaksi"
                    onClick={() => { onOpenNewTransaction(); setIsMobileMenuOpen(false); }}
                    className="w-full text-left px-3.5 py-2.5 text-emerald-300 hover:bg-emerald-950/60 flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <Plus className="w-4 h-4 stroke-[2.5]" />
                    <span>Catat Transaksi Baru</span>
                  </button>

                  <button
                    id="btn-backup-restore"
                    onClick={() => { onOpenBackupRestore(); setIsMobileMenuOpen(false); }}
                    className="w-full text-left px-3.5 py-2.5 text-purple-300 hover:bg-purple-950/60 flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <Database className="w-4 h-4 text-purple-300" />
                    <span>Backup & Restore Data</span>
                  </button>

                  <button
                    id="btn-impor-excel"
                    onClick={() => { onOpenExcelImport(); setIsMobileMenuOpen(false); }}
                    className="w-full text-left px-3.5 py-2.5 text-teal-300 hover:bg-teal-950/60 flex items-center gap-2 transition-colors cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-teal-300" />
                    <span>Impor Data Excel</span>
                  </button>

                  <button
                    id="btn-export-excel"
                    onClick={() => { onExportExcel(); setIsMobileMenuOpen(false); }}
                    className="w-full text-left px-3.5 py-2.5 text-emerald-300 hover:bg-emerald-950/60 flex items-center gap-2 transition-colors cursor-pointer border-t border-slate-800/80"
                  >
                    <FileSpreadsheet className="w-4 h-4 text-emerald-300" />
                    <span>Export Laporan Excel</span>
                  </button>
                </div>
              )}
            </div>

            <button
              id="btn-settings-sekolah"
              onClick={onOpenSettings}
              title="Pengaturan Profil Sekolah"
              className="bg-emerald-800/60 hover:bg-emerald-700/80 text-white border border-emerald-600/40 p-2 rounded-lg text-sm transition-colors cursor-pointer"
            >
              <Settings className="w-4 h-4 text-emerald-200" />
            </button>

            <button
              id="btn-reset-sample"
              onClick={onResetData}
              title="Reset ke Data Sample"
              className="bg-red-950/40 hover:bg-red-900/60 text-red-200 border border-red-800/40 p-2 rounded-lg text-sm transition-colors cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-red-300" />
            </button>
          </div>

          {/* Mobile Action Controls (Mobile/HP) */}
          <div className="flex md:hidden items-center space-x-1.5">
            {/* Quick Backup button for Mobile */}
            <button
              id="btn-mobile-backup"
              onClick={onOpenBackupRestore}
              title="Backup & Restore Data"
              className="bg-purple-600 hover:bg-purple-500 text-white font-bold px-2.5 py-2 rounded-xl text-xs flex items-center space-x-1 min-h-[44px] cursor-pointer shadow-sm"
            >
              <Database className="w-4 h-4" />
              <span className="text-[11px]">Backup</span>
            </button>

            {/* Quick Auth button for Mobile */}
            <button
              id="btn-mobile-auth"
              onClick={onOpenAuth}
              title="Login Cloud Multi-Device"
              className={`font-bold px-2.5 py-2 rounded-xl text-xs flex items-center space-x-1 min-h-[44px] cursor-pointer shadow-sm ${
                currentUser
                  ? 'bg-emerald-700 text-emerald-100 border border-emerald-500'
                  : 'bg-amber-400 text-amber-950 font-extrabold'
              }`}
            >
              <Cloud className="w-4 h-4" />
              <span className="text-[11px] max-w-[70px] truncate">
                {currentUser ? 'Cloud' : 'Login'}
              </span>
            </button>

            {/* Hamburger Mobile Menu Button */}
            <button
              id="btn-mobile-menu-toggle"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="bg-emerald-800/80 hover:bg-emerald-700 text-white p-2.5 rounded-xl border border-emerald-600/50 min-h-[44px] min-w-[44px] flex items-center justify-center cursor-pointer"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>

        {/* Mobile Dropdown Menu Drawer */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-emerald-950/95 backdrop-blur-md border-t border-emerald-700/60 px-4 py-3 space-y-2 rounded-b-2xl shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="grid grid-cols-2 gap-2 text-xs font-bold pt-1">
              <button
                onClick={() => { onOpenNewTransaction(); setIsMobileMenuOpen(false); }}
                className="col-span-2 bg-emerald-500 text-emerald-950 font-extrabold p-3 rounded-xl flex items-center justify-center gap-2 min-h-[44px] cursor-pointer shadow-md"
              >
                <Plus className="w-5 h-5 stroke-[3]" />
                <span>+ Catat Transaksi Baru</span>
              </button>

              <button
                onClick={() => { onOpenAuth(); setIsMobileMenuOpen(false); }}
                className="bg-emerald-800/80 border border-emerald-600 text-emerald-100 p-2.5 rounded-xl flex items-center gap-2 min-h-[44px] cursor-pointer"
              >
                <Cloud className="w-4 h-4 text-amber-300" />
                <span className="truncate">{currentUser ? 'Akun Cloud' : 'Login Cloud'}</span>
              </button>

              <button
                onClick={() => { onOpenBackupRestore(); setIsMobileMenuOpen(false); }}
                className="bg-purple-800/80 border border-purple-500/50 text-purple-100 p-2.5 rounded-xl flex items-center gap-2 min-h-[44px] cursor-pointer"
              >
                <Database className="w-4 h-4 text-purple-200" />
                <span>Backup & Restore</span>
              </button>

              <button
                onClick={() => { onOpenExcelImport(); setIsMobileMenuOpen(false); }}
                className="bg-teal-800/80 border border-teal-600 text-teal-100 p-2.5 rounded-xl flex items-center gap-2 min-h-[44px] cursor-pointer"
              >
                <Upload className="w-4 h-4 text-teal-200" />
                <span>Impor Excel</span>
              </button>

              <button
                onClick={() => { onExportExcel(); setIsMobileMenuOpen(false); }}
                className="bg-emerald-900/80 border border-emerald-700 text-emerald-100 p-2.5 rounded-xl flex items-center gap-2 min-h-[44px] cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
                <span>Export Excel</span>
              </button>

              <button
                onClick={() => { onOpenSettings(); setIsMobileMenuOpen(false); }}
                className="bg-emerald-900/80 border border-emerald-700 text-emerald-100 p-2.5 rounded-xl flex items-center gap-2 min-h-[44px] cursor-pointer"
              >
                <Settings className="w-4 h-4 text-emerald-200" />
                <span>Profil Sekolah</span>
              </button>

              <button
                onClick={() => { onResetData(); setIsMobileMenuOpen(false); }}
                className="bg-red-950/80 border border-red-800 text-red-200 p-2.5 rounded-xl flex items-center gap-2 min-h-[44px] cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 text-red-300" />
                <span>Reset Sample</span>
              </button>
            </div>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex space-x-1 border-t border-emerald-600/40 pt-1 overflow-x-auto scrollbar-none">
          <button
            id="tab-dashboard"
            onClick={() => setActiveTab('dashboard')}
            className={`px-4 py-2.5 rounded-t-lg font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all cursor-pointer whitespace-nowrap min-h-[44px] ${
              activeTab === 'dashboard'
                ? 'bg-slate-50 text-emerald-800 border-t-2 border-emerald-500 shadow-sm'
                : 'text-emerald-100 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Dashboard & Transaksi</span>
          </button>

          <button
            id="tab-real-daily"
            onClick={() => setActiveTab('real-daily')}
            className={`px-4 py-2.5 rounded-t-lg font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all cursor-pointer whitespace-nowrap min-h-[44px] ${
              activeTab === 'real-daily'
                ? 'bg-slate-50 text-emerald-800 border-t-2 border-emerald-500 shadow-sm'
                : 'text-emerald-100 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <Clock className="w-4 h-4 text-emerald-300" />
            <span>Transaksi Harian Real</span>
          </button>

          <button
            id="tab-spp"
            onClick={() => setActiveTab('spp')}
            className={`px-4 py-2.5 rounded-t-lg font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all cursor-pointer whitespace-nowrap min-h-[44px] ${
              activeTab === 'spp'
                ? 'bg-slate-50 text-emerald-800 border-t-2 border-emerald-500 shadow-sm'
                : 'text-emerald-100 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <GraduationCap className="w-4 h-4 text-emerald-300" />
            <span>SPP & Tagihan Siswa</span>
          </button>

          <button
            id="tab-laporan"
            onClick={() => setActiveTab('laporan')}
            className={`px-4 py-2.5 rounded-t-lg font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all cursor-pointer whitespace-nowrap min-h-[44px] ${
              activeTab === 'laporan'
                ? 'bg-slate-50 text-emerald-800 border-t-2 border-emerald-500 shadow-sm'
                : 'text-emerald-100 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Laporan Rekap Bulanan</span>
          </button>

          <button
            id="tab-analytics"
            onClick={() => setActiveTab('analytics')}
            className={`px-4 py-2.5 rounded-t-lg font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all cursor-pointer whitespace-nowrap min-h-[44px] ${
              activeTab === 'analytics'
                ? 'bg-slate-50 text-emerald-800 border-t-2 border-emerald-500 shadow-sm'
                : 'text-emerald-100 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>Grafik & Analisis</span>
          </button>

          <button
            id="tab-categories"
            onClick={() => setActiveTab('categories')}
            className={`px-4 py-2.5 rounded-t-lg font-bold text-xs sm:text-sm flex items-center space-x-2 transition-all cursor-pointer whitespace-nowrap min-h-[44px] ${
              activeTab === 'categories'
                ? 'bg-slate-50 text-emerald-800 border-t-2 border-emerald-500 shadow-sm'
                : 'text-emerald-100 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <FolderTree className="w-4 h-4" />
            <span>Kelola Kategori</span>
          </button>
        </div>
      </div>
    </header>
  );
};

