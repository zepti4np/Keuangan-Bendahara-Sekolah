import React, { useState, useRef } from 'react';
import { 
  Users, 
  Upload, 
  Download, 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  FileSpreadsheet,
  Trash2,
  ArrowRight,
  RefreshCw
} from 'lucide-react';
import { Student } from '../types';
import { 
  parseStudentExcelFile, 
  downloadStudentExcelTemplate, 
  StudentImportResult 
} from '../utils/excelUtils';
import { formatRupiah } from '../utils/formatters';

interface StudentImportModalProps {
  existingCount: number;
  onImportSuccess: (importedStudents: Student[], mode: 'append' | 'overwrite') => void;
  onClose: () => void;
}

export const StudentImportModal: React.FC<StudentImportModalProps> = ({
  existingCount,
  onImportSuccess,
  onClose
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [importResult, setImportResult] = useState<StudentImportResult | null>(null);
  const [importMode, setImportMode] = useState<'append' | 'overwrite'>('append');
  const [isDragOver, setIsDragOver] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (selectedFile: File) => {
    if (!selectedFile) return;

    const validExts = ['.xlsx', '.xls', '.csv'];
    const fileName = selectedFile.name.toLowerCase();
    const isValidExt = validExts.some(ext => fileName.endsWith(ext));

    if (!isValidExt) {
      setErrorMsg('Format file tidak didukung. Harap pilih file berformat .xlsx, .xls, atau .csv');
      return;
    }

    setFile(selectedFile);
    setErrorMsg(null);
    setLoading(true);

    try {
      const result = await parseStudentExcelFile(selectedFile);
      setImportResult(result);
      if (result.validRows.length === 0) {
        setErrorMsg('Tidak ditemukan data siswa yang valid di dalam file ini.');
      }
    } catch (err) {
      setErrorMsg((err as Error).message || 'Gagal membaca file Excel/CSV.');
      setImportResult(null);
    } finally {
      setLoading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleConfirmImport = () => {
    if (!importResult || importResult.validRows.length === 0) return;

    const convertedStudents: Student[] = importResult.validRows.map((row, idx) => ({
      id: `STU-${Date.now()}-${idx}-${Math.floor(Math.random() * 1000)}`,
      nisn: row.nisn,
      nama: row.nama,
      kelas: row.kelas,
      nominalSppBulanan: row.nominalSppBulanan,
      nominalTagihanTahunan: row.nominalTagihanTahunan,
      keterangan: row.keterangan
    }));

    onImportSuccess(convertedStudents, importMode);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150 my-auto">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold">Impor Data Siswa Dari Excel / CSV</h2>
              <p className="text-xs text-slate-300">
                Unggah berkas Excel (.xlsx) untuk menambahkan data siswa secara cepat
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-5 max-h-[78vh] overflow-y-auto">
          
          {/* Download Template Banner */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg shrink-0">
                <Info className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <div className="font-bold text-emerald-900">Gunakan Format Template Resmi</div>
                <div className="text-emerald-700">Format kolom: NISN, Nama Lengkap Siswa, Kelas, SPP Bulanan, Tagihan Tahunan.</div>
              </div>
            </div>
            <button
              onClick={downloadStudentExcelTemplate}
              className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs px-3.5 py-2 rounded-lg flex items-center gap-1.5 transition-all shadow-2xs shrink-0 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Unduh Template Excel</span>
            </button>
          </div>

          {/* File Upload Dropzone */}
          {!importResult && (
            <div
              onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition-all ${
                isDragOver 
                  ? 'border-emerald-500 bg-emerald-50/50 scale-[0.99]' 
                  : 'border-slate-300 hover:border-emerald-400 hover:bg-slate-50'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx, .xls, .csv"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileSelect(e.target.files[0]);
                  }
                }}
              />
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <Upload className="w-6 h-6" />
              </div>
              <h3 className="font-bold text-slate-800 text-sm">
                Klik atau Seret Berkas Excel / CSV ke Sini
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Format yang didukung: .xlsx, .xls, .csv (Maksimal 10MB)
              </p>
            </div>
          )}

          {/* Loading state */}
          {loading && (
            <div className="py-8 text-center space-y-2">
              <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto" />
              <p className="text-xs font-bold text-slate-700">Membaca dan memvalidasi berkas siswa...</p>
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 p-3 rounded-xl flex items-start space-x-2 text-rose-800 text-xs">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Parsed Result Preview */}
          {importResult && (
            <div className="space-y-4">
              
              {/* File Info Bar */}
              <div className="bg-slate-100 p-3 rounded-xl flex items-center justify-between text-xs border border-slate-200">
                <div className="flex items-center space-x-2 truncate">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="font-bold text-slate-800 truncate">{file?.name}</span>
                  <span className="text-slate-500 font-mono">({importResult.validRows.length} siswa valid)</span>
                </div>
                <button
                  onClick={() => {
                    setImportResult(null);
                    setFile(null);
                    setErrorMsg(null);
                  }}
                  className="text-rose-600 hover:text-rose-800 font-bold flex items-center gap-1 hover:underline cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Ganti File</span>
                </button>
              </div>

              {/* Import Mode Selection */}
              <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl space-y-2">
                <label className="text-xs font-bold text-slate-800 block">
                  Pilih Mode Impor Data Siswa:
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <label className={`p-2.5 rounded-lg border text-xs cursor-pointer flex items-center space-x-2.5 transition-all ${
                    importMode === 'append'
                      ? 'bg-emerald-50 border-emerald-400 font-bold text-emerald-900 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}>
                    <input
                      type="radio"
                      name="studentImportMode"
                      checked={importMode === 'append'}
                      onChange={() => setImportMode('append')}
                      className="text-emerald-600 focus:ring-emerald-500"
                    />
                    <div>
                      <div>Tambahkan / Perbarui Data (Append)</div>
                      <div className="text-[10px] font-normal text-slate-500">
                        Siswa baru ditambahkan, siswa lama ({existingCount}) tetap ada
                      </div>
                    </div>
                  </label>

                  <label className={`p-2.5 rounded-lg border text-xs cursor-pointer flex items-center space-x-2.5 transition-all ${
                    importMode === 'overwrite'
                      ? 'bg-amber-50 border-amber-400 font-bold text-amber-900 shadow-2xs'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}>
                    <input
                      type="radio"
                      name="studentImportMode"
                      checked={importMode === 'overwrite'}
                      onChange={() => setImportMode('overwrite')}
                      className="text-amber-600 focus:ring-amber-500"
                    />
                    <div>
                      <div>Timpa Seluruh Data Siswa (Overwrite)</div>
                      <div className="text-[10px] font-normal text-amber-700 font-semibold">
                        Hapus {existingCount} siswa lama & ganti dengan {importResult.validRows.length} siswa ini
                      </div>
                    </div>
                  </label>
                </div>
              </div>

              {/* Table Preview */}
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-3 py-2 text-xs font-bold text-slate-700 flex justify-between items-center border-b border-slate-200">
                  <span>Pratinjau Data Siswa Terbaca</span>
                  <span className="text-[10px] font-normal text-slate-500">*Siswa akan otomatis diurutkan sesuai abjad (A-Z)</span>
                </div>
                <div className="max-h-56 overflow-y-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-50 text-slate-600 font-bold text-[10px] uppercase border-b border-slate-200 sticky top-0">
                      <tr>
                        <th className="p-2 text-center w-8">No</th>
                        <th className="p-2">NISN</th>
                        <th className="p-2">Nama Lengkap Siswa</th>
                        <th className="p-2">Kelas</th>
                        <th className="p-2 text-right">SPP / Bulan</th>
                        <th className="p-2 text-right">Tagihan Tahunan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {importResult.validRows.slice(0, 50).map((r, i) => (
                        <tr key={i} className="hover:bg-slate-50">
                          <td className="p-2 text-center font-mono text-slate-400">{i + 1}</td>
                          <td className="p-2 font-mono text-slate-600">{r.nisn}</td>
                          <td className="p-2 font-bold text-slate-800">{r.nama}</td>
                          <td className="p-2 font-semibold text-slate-600">{r.kelas}</td>
                          <td className="p-2 text-right font-mono text-emerald-700 font-semibold">{formatRupiah(r.nominalSppBulanan)}</td>
                          <td className="p-2 text-right font-mono text-blue-700 font-semibold">{formatRupiah(r.nominalTagihanTahunan)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {importResult.validRows.length > 50 && (
                  <div className="bg-slate-50 p-2 text-center text-[10px] text-slate-500 border-t border-slate-200">
                    Menampilkan 50 dari total {importResult.validRows.length} siswa
                  </div>
                )}
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 p-4 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 border border-slate-300 rounded-xl hover:bg-slate-100 transition-all cursor-pointer"
          >
            Batal
          </button>

          {importResult && importResult.validRows.length > 0 && (
            <button
              onClick={handleConfirmImport}
              className="bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 shadow-sm transition-all cursor-pointer"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Proses Impor ({importResult.validRows.length} Siswa)</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
