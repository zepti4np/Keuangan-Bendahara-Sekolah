import React, { useMemo } from 'react';
import { BarChart3, PieChart as PieIcon, TrendingUp, DollarSign, Wallet } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';
import { Transaction } from '../types';
import { formatRupiah } from '../utils/formatters';

interface AnalyticsViewProps {
  transactions: Transaction[];
}

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({ transactions }) => {
  
  // Expenses grouped by Category
  const expenseByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    transactions.forEach(t => {
      if (t.jenis === 'Pengeluaran') {
        map[t.kategori] = (map[t.kategori] || 0) + t.pengeluaran;
      }
    });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [transactions]);

  // Income grouped by Category
  const incomeByCategory = useMemo(() => {
    const map: Record<string, number> = {};
    transactions.forEach(t => {
      if (t.jenis === 'Pemasukan' || t.jenis === 'Saldo Awal') {
        map[t.kategori] = (map[t.kategori] || 0) + t.pemasukan;
      }
    });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [transactions]);

  // Monthly breakdown
  const monthlyData = useMemo(() => {
    const map: Record<string, { pemasukan: number; pengeluaran: number }> = {};
    transactions.forEach(t => {
      const monthStr = t.tanggal.slice(0, 7); // YYYY-MM
      if (!map[monthStr]) {
        map[monthStr] = { pemasukan: 0, pengeluaran: 0 };
      }
      if (t.jenis === 'Pemasukan' || t.jenis === 'Saldo Awal') {
        map[monthStr].pemasukan += t.pemasukan;
      } else if (t.jenis === 'Pengeluaran') {
        map[monthStr].pengeluaran += t.pengeluaran;
      }
    });

    return Object.entries(map)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([month, data]) => ({
        month,
        Pemasukan: data.pemasukan,
        Pengeluaran: data.pengeluaran
      }));
  }, [transactions]);

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#64748b'];

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border border-slate-200 p-3 rounded-lg shadow-xl text-xs text-slate-900 font-sans">
          <p className="font-bold text-slate-700 mb-1">{label}</p>
          {payload.map((entry: any, index: number) => (
            <p key={`item-${index}`} style={{ color: entry.color }} className="font-mono font-semibold">
              {entry.name}: {formatRupiah(entry.value)}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 text-slate-900 shadow-sm flex items-center justify-between">
        <div>
          <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-600" />
            Grafik & Analisis Keuangan Bendahara
          </h3>
          <p className="text-xs text-slate-500">
            Visualisasi pemasukan, pengeluaran, dan alokasi anggaran sekolah
          </p>
        </div>
      </div>

      {/* Bar Chart: Income vs Expense per Month */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 text-slate-900 shadow-sm">
        <h4 className="font-bold text-sm text-slate-800 mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-600" />
          Perbandingan Pemasukan vs Pengeluaran Bulanan
        </h4>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlyData} margin={{ top: 10, right: 30, left: 20, bottom: 5 }}>
              <XAxis dataKey="month" stroke="#64748b" fontSize={12} />
              <YAxis stroke="#64748b" fontSize={10} tickFormatter={(val) => `Rp ${(val / 1000000).toFixed(0)}Jt`} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="Pemasukan" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Pengeluaran" fill="#ef4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Pie Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Expenses Pie */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 text-slate-900 shadow-sm">
          <h4 className="font-bold text-sm text-slate-800 mb-4 flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-red-600" />
            Distribusi Pengeluaran Berdasarkan Kategori
          </h4>
          {expenseByCategory.length === 0 ? (
            <p className="text-slate-500 text-xs text-center py-10">Belum ada pengeluaran tercatat.</p>
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={expenseByCategory}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {expenseByCategory.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(val: number) => formatRupiah(val)} />
                </PieChart>
              </ResponsiveContainer>
              
              {/* Category Legend List */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {expenseByCategory.slice(0, 6).map((item, idx) => (
                  <div key={item.name} className="flex items-center space-x-2">
                    <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                    <span className="text-slate-700 truncate">{item.name}</span>
                    <span className="font-mono font-bold text-slate-900 ml-auto">{formatRupiah(item.value)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Income Pie */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 text-slate-900 shadow-sm">
          <h4 className="font-bold text-sm text-slate-800 mb-4 flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-emerald-600" />
            Sumber Pemasukan Berdasarkan Kategori
          </h4>
          {incomeByCategory.length === 0 ? (
            <p className="text-slate-500 text-xs text-center py-10">Belum ada pemasukan tercatat.</p>
          ) : (
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={incomeByCategory}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {incomeByCategory.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(val: number) => formatRupiah(val)} />
                </PieChart>
              </ResponsiveContainer>

              {/* Category Legend List */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {incomeByCategory.slice(0, 6).map((item, idx) => (
                  <div key={item.name} className="flex items-center space-x-2">
                    <span className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: COLORS[idx % COLORS.length] }} />
                    <span className="text-slate-700 truncate">{item.name}</span>
                    <span className="font-mono font-bold text-slate-900 ml-auto">{formatRupiah(item.value)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
