import React, { useState } from 'react';
import { FolderTree, Plus, Trash2, Tag, CheckCircle } from 'lucide-react';
import { CategoryData, TransactionType } from '../types';

interface CategoryManagerProps {
  categoryData: CategoryData;
  onAddCategory: (jenis: TransactionType, newCat: string) => void;
  onDeleteCategory: (jenis: TransactionType, catToDelete: string) => void;
}

export const CategoryManager: React.FC<CategoryManagerProps> = ({
  categoryData,
  onAddCategory,
  onDeleteCategory
}) => {
  const [selectedJenis, setSelectedJenis] = useState<TransactionType>('Pemasukan');
  const [newCatInput, setNewCatInput] = useState<string>('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatInput.trim()) return;
    onAddCategory(selectedJenis, newCatInput.trim());
    setNewCatInput('');
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-6 text-slate-900 shadow-sm space-y-6">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-100">
        <div>
          <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
            <FolderTree className="w-5 h-5 text-emerald-600" />
            Kelola Kategori & Sub-Anggaran Keuangan
          </h3>
          <p className="text-xs text-slate-500">
            Kustomisasi jenis sub-kategori transaksi untuk Pemasukan, Pengeluaran, Saldo Awal, & Mutasi Kas
          </p>
        </div>
      </div>

      {/* Jenis Selector Tabs */}
      <div className="flex space-x-2 border-b border-slate-200 pb-3">
        {(['Pemasukan', 'Pengeluaran', 'Saldo Awal', 'Mutasi Kas'] as TransactionType[]).map((j) => (
          <button
            key={j}
            onClick={() => setSelectedJenis(j)}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              selectedJenis === j
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            {j}
          </button>
        ))}
      </div>

      {/* Add Category Form */}
      <form onSubmit={handleAdd} className="flex items-center gap-2">
        <input
          id="input-new-category"
          type="text"
          value={newCatInput}
          onChange={(e) => setNewCatInput(e.target.value)}
          placeholder={`Tambah kategori baru untuk [${selectedJenis}]...`}
          className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-2 text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-500"
        />
        <button
          id="btn-add-category"
          type="submit"
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-lg text-xs flex items-center gap-1 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4 stroke-[3]" />
          <span>Tambah</span>
        </button>
      </form>

      {/* Category List */}
      <div className="bg-slate-50 rounded-xl border border-slate-200 p-4">
        <h4 className="text-xs font-semibold text-slate-600 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Tag className="w-3.5 h-3.5 text-emerald-600" />
          Daftar Kategori [{selectedJenis}] ({categoryData[selectedJenis]?.length || 0})
        </h4>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {(categoryData[selectedJenis] || []).map((cat) => (
            <div
              key={cat}
              className="flex items-center justify-between bg-white border border-slate-200 rounded-lg p-2.5 text-xs text-slate-800 group hover:border-slate-300 shadow-sm"
            >
              <span className="font-medium">{cat}</span>
              <button
                onClick={() => {
                  if (window.confirm(`Hapus kategori "${cat}"?`)) {
                    onDeleteCategory(selectedJenis, cat);
                  }
                }}
                className="text-slate-400 hover:text-red-600 p-1 rounded hover:bg-slate-100 transition-colors cursor-pointer opacity-80 group-hover:opacity-100"
                title="Hapus Kategori"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
