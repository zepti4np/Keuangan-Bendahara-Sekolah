import React, { useState, useMemo } from 'react';
import { Search, Filter, Printer, Trash2, ArrowDownLeft, ArrowUpRight, Wallet, ArrowRightLeft, FileSpreadsheet, Eye, Upload, Pencil, Calendar, Paperclip, Image as ImageIcon } from 'lucide-react';
import { CategoryData, Transaction, TransactionType } from '../types';
import { formatRupiah, formatDateIndonesian } from '../utils/formatters';
import { EditTransactionModal } from './EditTransactionModal';

interface TransactionListProps {
  transactions: Transaction[];
  onDeleteTransaction: (id: string) => void;
  onSelectKwitansi: (transaction: Transaction) => void;
  onOpenExcelImport?: () => void;
  categoryData?: CategoryData;
  onUpdateTransaction?: (updatedTx: Transaction) => void;
  onOpenBatchPrint?: (month?: string) => void;
  onPreviewReceipt?: (transaction: Transaction) => void;
}

export const TransactionList: React.FC<TransactionListProps> = ({
  transactions,
  onDeleteTransaction,
  onSelectKwitansi,
  onOpenExcelImport,
  categoryData = {},
  onUpdateTransaction,
  onOpenBatchPrint,
  onPreviewReceipt
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMonth, setSelectedMonth] = useState<string>('ALL');
  const [selectedJenis, setSelectedJenis] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'date-desc' | 'date-asc' | 'nominal-desc'>('date-desc');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  // Available unique categories
  const categoriesList = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach(t => {
      if (t.kategori) set.add(t.kategori);
    });
    return Array.from(set).sort();
  }, [transactions]);

  // Available unique months (YYYY-MM) formatted nicely
  const monthOptions = useMemo(() => {
    const set = new Set<string>();
    transactions.forEach(t => {
      if (t.tanggal && t.tanggal.length >= 7) {
        set.add(t.tanggal.substring(0, 7)); // YYYY-MM
      }
    });
    const sorted = Array.from(set).sort().reverse();
    const MONTH_NAMES = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];

    return sorted.map(ym => {
      const [year, monthStr] = ym.split('-');
      const monthIdx = parseInt(monthStr, 10) - 1;
      const name = MONTH_NAMES[monthIdx] || monthStr;
      return {
        value: ym,
        label: `${name} ${year}`
      };
    });
  }, [transactions]);

  // Filtered and sorted transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      const matchSearch =
        t.uraian.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.kategori.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (t.pihak && t.pihak.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (t.nomorBukti && t.nomorBukti.toLowerCase().includes(searchTerm.toLowerCase())) ||
        t.tanggal.includes(searchTerm);

      const matchMonth = selectedMonth === 'ALL' || (t.tanggal && t.tanggal.startsWith(selectedMonth));
      const matchJenis = selectedJenis === 'ALL' || t.jenis === selectedJenis;
      const matchCategory = selectedCategory === 'ALL' || t.kategori === selectedCategory;

      return matchSearch && matchMonth && matchJenis && matchCategory;
    }).sort((a, b) => {
      if (sortBy === 'date-desc') {
        return new Date(b.tanggal).getTime() - new Date(a.tanggal).getTime() || b.id.localeCompare(a.id);
      } else if (sortBy === 'date-asc') {
        return new Date(a.tanggal).getTime() - new Date(b.tanggal).getTime() || a.id.localeCompare(b.id);
      } else {
        const nominalA = Math.max(a.pemasukan, a.pengeluaran);
        const nominalB = Math.max(b.pemasukan, b.pengeluaran);
        return nominalB - nominalA;
      }
    });
  }, [transactions, searchTerm, selectedMonth, selectedJenis, selectedCategory, sortBy]);

  const getJenisBadge = (jenis: TransactionType) => {
    switch (jenis) {
      case 'Pemasukan':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200 gap-1">
            <ArrowDownLeft className="w-3 h-3 text-emerald-600" />
            Pemasukan
          </span>
        );
      case 'Pengeluaran':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-800 border border-red-200 gap-1">
            <ArrowUpRight className="w-3 h-3 text-red-600" />
            Pengeluaran
          </span>
        );
      case 'Saldo Awal':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-200 gap-1">
            <Wallet className="w-3 h-3 text-blue-600" />
            Saldo Awal
          </span>
        );
      case 'Mutasi Kas':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-200 gap-1">
            <ArrowRightLeft className="w-3 h-3 text-amber-600" />
            Mutasi Kas
          </span>
        );
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-5 text-slate-900 shadow-sm">
      
      {/* Header & Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 mb-4">
        <div>
          <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
            Riwayat Transaksi Bendahara
          </h3>
          <p className="text-xs text-slate-500">
            Total {filteredTransactions.length} dari {transactions.length} transaksi tercatat
          </p>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {onOpenExcelImport && (
            <button
              onClick={onOpenExcelImport}
              className="bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 shadow-sm transition-all cursor-pointer border border-teal-500/30"
              title="Impor transaksi dari berkas Excel"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Impor Excel</span>
            </button>
          )}

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="input-search-transaksi"
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Cari uraian, no. bukti, pihak..."
              className="bg-white border border-slate-300 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-emerald-500 w-48 sm:w-60"
            />
          </div>

          {/* Filter Bulan */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs">
            <Calendar className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <select
              id="filter-bulan"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-transparent text-slate-900 focus:outline-none cursor-pointer text-xs font-semibold"
            >
              <option value="ALL">Semua Bulan</option>
              {monthOptions.map(m => (
                <option key={m.value} value={m.value}>{m.label}</option>
              ))}
            </select>
          </div>

          {/* Tombol Batch Print 1 Bulan */}
          {onOpenBatchPrint && (
            <button
              id="btn-open-batch-print"
              onClick={() => onOpenBatchPrint(selectedMonth !== 'ALL' ? selectedMonth : undefined)}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1.5 cursor-pointer shadow-sm transition-all"
              title="Cetak Seluruh Bukti Transaksi BKK / BKM 1 Bulan sekaligus"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Batch 1 Bulan</span>
            </button>
          )}

          {/* Filter Jenis */}
          <select
            id="filter-jenis"
            value={selectedJenis}
            onChange={(e) => setSelectedJenis(e.target.value)}
            className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
          >
            <option value="ALL">Semua Jenis</option>
            <option value="Pemasukan">Pemasukan</option>
            <option value="Pengeluaran">Pengeluaran</option>
            <option value="Saldo Awal">Saldo Awal</option>
            <option value="Mutasi Kas">Mutasi Kas</option>
          </select>

          {/* Filter Category */}
          <select
            id="filter-kategori"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500 max-w-[150px] truncate"
          >
            <option value="ALL">Semua Kategori</option>
            {categoriesList.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>

          {/* Sort By */}
          <select
            id="select-sort"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
          >
            <option value="date-desc">Terbaru</option>
            <option value="date-asc">Terlama</option>
            <option value="nominal-desc">Nominal Terbesar</option>
          </select>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="overflow-x-auto border border-slate-200 rounded-xl">
        <table className="w-full min-w-[780px] text-left border-collapse">
          <thead>
            <tr className="bg-slate-100 text-slate-700 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
              <th className="py-3 px-3">Tanggal / No. Bukti</th>
              <th className="py-3 px-3">Jenis & Kategori</th>
              <th className="py-3 px-3">Uraian & Pihak Terkait</th>
              <th className="py-3 px-3 text-right">Pemasukan (Rp)</th>
              <th className="py-3 px-3 text-right">Pengeluaran (Rp)</th>
              <th className="py-3 px-3 text-center min-w-[140px]">Aksi / Tindakan</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-sm">
            {filteredTransactions.length === 0 ? (
              <tr>
                <td colSpan={6} className="text-center py-10 text-slate-500">
                  Tidak ada transaksi yang cocok dengan pencarian atau filter.
                </td>
              </tr>
            ) : (
              filteredTransactions.map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-50 transition-colors group">
                  
                  {/* Tanggal & No Bukti */}
                  <td className="py-3 px-3 whitespace-nowrap">
                    <div className="font-semibold text-slate-900 text-xs">
                      {formatDateIndonesian(tx.tanggal)}
                    </div>
                    <div className="font-mono text-[11px] text-slate-500 mt-0.5">
                      {tx.nomorBukti || tx.id}
                    </div>
                  </td>

                  {/* Jenis & Kategori */}
                  <td className="py-3 px-3">
                    <div>{getJenisBadge(tx.jenis)}</div>
                    <div className="text-xs text-slate-700 font-medium mt-1 truncate max-w-[180px]">
                      {tx.kategori}
                    </div>
                  </td>

                  {/* Uraian & Pihak */}
                  <td className="py-3 px-3 max-w-xs">
                    <div className="text-xs text-slate-800 font-medium leading-relaxed line-clamp-2">
                      {tx.uraian}
                    </div>
                    <div className="flex flex-wrap items-center gap-2 mt-0.5">
                      {tx.pihak && (
                        <span className="text-[11px] text-slate-500 italic">
                          Pihak: {tx.pihak}
                        </span>
                      )}
                      {tx.buktiNotaUrl && (
                        <button
                          type="button"
                          onClick={() => onPreviewReceipt && onPreviewReceipt(tx)}
                          className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-1.5 py-0.5 rounded cursor-pointer transition-colors"
                          title="Lihat Berkas Bukti Physical Nota / Kwitansi"
                        >
                          <Paperclip className="w-3 h-3 text-emerald-600" />
                          <span>Bukti Terlampir</span>
                        </button>
                      )}
                    </div>
                  </td>

                  {/* Pemasukan */}
                  <td className="py-3 px-3 text-right font-mono font-bold text-xs text-emerald-600 whitespace-nowrap">
                    {tx.pemasukan > 0 ? formatRupiah(tx.pemasukan) : '-'}
                  </td>

                  {/* Pengeluaran */}
                  <td className="py-3 px-3 text-right font-mono font-bold text-xs text-red-600 whitespace-nowrap">
                    {tx.pengeluaran > 0 ? formatRupiah(tx.pengeluaran) : '-'}
                  </td>

                  {/* Actions */}
                  <td className="py-3 px-3 text-center whitespace-nowrap">
                    <div className="flex items-center justify-center space-x-1.5">
                      {/* Print Kwitansi / Memo Button */}
                      <button
                        id={`btn-kwitansi-${tx.id}`}
                        onClick={() => onSelectKwitansi(tx)}
                        title={tx.jenis === 'Saldo Awal' || tx.nomorBukti?.startsWith('MEMO') ? "Cetak Memo Saldo Awal" : "Cetak Bukti BKM / BKK"}
                        className="bg-slate-100 hover:bg-emerald-50 text-emerald-800 border border-slate-200 hover:border-emerald-300 px-2 py-1.5 rounded-lg text-xs flex items-center gap-1 transition-all cursor-pointer font-medium"
                      >
                        <Printer className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-[11px]">{tx.jenis === 'Saldo Awal' || tx.nomorBukti?.startsWith('MEMO') ? "Memo" : "Kwitansi"}</span>
                      </button>

                      {/* Edit Button */}
                      {onUpdateTransaction && (
                        <button
                          id={`btn-edit-${tx.id}`}
                          onClick={() => setEditingTransaction(tx)}
                          title="Edit Transaksi Keuangan"
                          className="bg-amber-50 hover:bg-amber-100 text-amber-700 hover:text-amber-900 border border-amber-200 hover:border-amber-300 px-2 py-1.5 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer font-medium"
                        >
                          <Pencil className="w-3.5 h-3.5 text-amber-600" />
                          <span className="text-[11px]">Edit</span>
                        </button>
                      )}

                      {/* Delete Button */}
                      <button
                        id={`btn-delete-${tx.id}`}
                        onClick={() => {
                          if (window.confirm(`Hapus transaksi "${tx.uraian}"?`)) {
                            onDeleteTransaction(tx.id);
                          }
                        }}
                        title="Hapus Transaksi"
                        className="bg-red-50 hover:bg-red-100 text-red-600 hover:text-red-800 border border-red-200 px-2 py-1.5 rounded-lg text-xs flex items-center gap-1 transition-colors cursor-pointer font-medium"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span className="text-[11px]">Hapus</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal Edit Transaksi */}
      {editingTransaction && (
        <EditTransactionModal
          isOpen={!!editingTransaction}
          transaction={editingTransaction}
          categoryData={categoryData}
          onClose={() => setEditingTransaction(null)}
          onSave={(updatedTx) => {
            if (onUpdateTransaction) {
              onUpdateTransaction(updatedTx);
            }
          }}
        />
      )}
    </div>
  );
};
