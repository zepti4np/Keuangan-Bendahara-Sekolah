import React, { useState, useRef } from 'react';
import { Download, Upload, Database, CheckCircle2, AlertTriangle, FileJson, RefreshCw, X, Cloud, Smartphone, Laptop, ArrowRightLeft } from 'lucide-react';
import { User } from 'firebase/auth';
import { parseBackupJSON, BackupData } from '../utils/backupUtils';

interface BackupRestoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDownloadBackup: () => void;
  onRestoreBackup: (data: BackupData, mode: 'overwrite' | 'merge') => void;
  totalTransactions: number;
  totalStudents: number;
  totalSppPayments: number;
  currentUser?: User | null;
  onSyncLocalToCloud?: () => Promise<void>;
  onOpenAuth?: () => void;
}

export const BackupRestoreModal: React.FC<BackupRestoreModalProps> = ({
  isOpen,
  onClose,
  onDownloadBackup,
  onRestoreBackup,
  totalTransactions,
  totalStudents,
  totalSppPayments,
  currentUser,
  onSyncLocalToCloud,
  onOpenAuth
}) => {
  const [parsedData, setParsedData] = useState<BackupData | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [syncMsg, setSyncMsg] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [fileName, setFileName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setErrorMsg(null);

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const result = parseBackupJSON(content);
      if (result.success && result.data) {
        setParsedData(result.data);
      } else {
        setErrorMsg(result.error || 'Gagal membaca file backup');
        setParsedData(null);
      }
    };
    reader.onerror = () => {
      setErrorMsg('Gagal membaca file dari penyimpanan lokal');
      setParsedData(null);
    };
    reader.readAsText(file);
  };

  const handleConfirmRestore = (mode: 'overwrite' | 'merge') => {
    if (!parsedData) return;
    onRestoreBackup(parsedData, mode);
    setParsedData(null);
    setFileName('');
    setSyncMsg('Data berhasil dipulihkan dari file backup!');
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  const handleManualCloudPush = async () => {
    if (!onSyncLocalToCloud) return;
    setIsSyncing(true);
    setSyncMsg(null);
    setErrorMsg(null);
    try {
      await onSyncLocalToCloud();
      setSyncMsg('Seluruh data di perangkat ini berhasil diunggah ke Cloud Firestore!');
    } catch (err: any) {
      setErrorMsg('Gagal mengunggah data ke Cloud: ' + (err.message || err));
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto no-print">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-2xl overflow-hidden text-slate-900 my-6 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-slate-900 px-6 py-4 flex items-center justify-between border-b border-slate-800 text-white">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-purple-500/20 text-purple-300 rounded-lg border border-purple-500/30">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Cadangan Data & Sinkronisasi Perangkat</h3>
              <p className="text-xs text-slate-400">Backup, Restore & Transfer Data antara Laptop dan HP</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5 text-xs text-slate-700 max-h-[80vh] overflow-y-auto">
          
          {/* Messages */}
          {syncMsg && (
            <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-xl flex items-center space-x-2 text-xs">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{syncMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="bg-rose-50 border border-rose-200 text-rose-800 p-3 rounded-xl flex items-center space-x-2 text-xs">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Guide Card: Laptop <-> HP */}
          <div className="bg-gradient-to-r from-emerald-900 to-teal-900 text-white rounded-xl p-4 shadow-sm space-y-3">
            <div className="flex items-center justify-between border-b border-white/20 pb-2">
              <div className="flex items-center space-x-2">
                <ArrowRightLeft className="w-4 h-4 text-amber-300" />
                <h4 className="font-bold text-sm text-white">Cara Pindahkan Data dari Laptop ke HP:</h4>
              </div>
              <span className="bg-amber-400/20 text-amber-300 text-[10px] px-2 py-0.5 rounded font-mono font-bold border border-amber-300/30">
                Multi-Device Guide
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[11px] leading-relaxed text-emerald-100">
              <div className="bg-white/10 p-3 rounded-lg border border-white/10 space-y-1">
                <p className="font-bold text-amber-300 flex items-center gap-1">
                  <Cloud className="w-3.5 h-3.5" /> Cara 1: Sinkronisasi Cloud (Otomatis)
                </p>
                <p>1. Login akun Google yang sama di Laptop & HP.</p>
                <p>2. Tekan tombol <strong>"Unggah ke Cloud"</strong> di Laptop.</p>
                <p>3. Saat membuka HP, data otomatis tertarik dari Cloud!</p>
              </div>

              <div className="bg-white/10 p-3 rounded-lg border border-white/10 space-y-1">
                <p className="font-bold text-amber-300 flex items-center gap-1">
                  <FileJson className="w-3.5 h-3.5" /> Cara 2: File Backup JSON (Manual)
                </p>
                <p>1. Tekan <strong>"Unduh File Backup (.json)"</strong> di Laptop.</p>
                <p>2. Kirim file `.json` ke HP (via WhatsApp / Email / Drive).</p>
                <p>3. Di HP, tekan <strong>"Unggah File Backup"</strong> lalu pilih file tersebut.</p>
              </div>
            </div>
          </div>

          {/* Cloud Push Sync Status Section */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-4 space-y-2.5">
            <div className="flex items-start justify-between">
              <div>
                <h4 className="font-bold text-emerald-950 text-sm flex items-center gap-1.5">
                  <Cloud className="w-4 h-4 text-emerald-600" />
                  <span>Status Cloud Database (Multi-Device)</span>
                </h4>
                <p className="text-slate-600 mt-0.5">
                  {currentUser ? (
                    <>Terhubung sebagai: <strong>{currentUser.email || currentUser.displayName}</strong></>
                  ) : (
                    <>Belum Login Akun Cloud. Silakan login agar data tersimpan di Server Firebase.</>
                  )}
                </p>
              </div>

              {currentUser ? (
                <button
                  type="button"
                  onClick={handleManualCloudPush}
                  disabled={isSyncing}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow-sm transition-all cursor-pointer shrink-0"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                  <span>{isSyncing ? 'Mengunggah...' : 'Unggah Data Lokal ke Cloud'}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onOpenAuth}
                  className="bg-amber-500 hover:bg-amber-400 text-amber-950 font-extrabold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1 shadow-sm transition-all cursor-pointer shrink-0"
                >
                  <Cloud className="w-3.5 h-3.5" />
                  <span>Login Cloud Sekarang</span>
                </button>
              )}
            </div>

            <div className="pt-1 flex flex-wrap gap-2 font-mono text-[11px] text-emerald-900">
              <span className="bg-white px-2 py-0.5 rounded border border-emerald-300 font-bold">
                {totalTransactions} Transaksi
              </span>
              <span className="bg-white px-2 py-0.5 rounded border border-emerald-300 font-bold">
                {totalStudents} Siswa
              </span>
              <span className="bg-white px-2 py-0.5 rounded border border-emerald-300 font-bold">
                {totalSppPayments} Pembayaran SPP
              </span>
            </div>
          </div>

          {/* Section 1: Unduh Backup JSON */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-2.5">
            <div>
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Download className="w-4 h-4 text-blue-600" />
                <span>1. Unduh File Cadangan (Download Backup .json)</span>
              </h4>
              <p className="text-slate-500 mt-0.5">
                Simpan salinan seluruh data aplikasi (Profil Sekolah, Transaksi, SPP, Kategori) ke komputer atau HP dalam format JSON.
              </p>
            </div>
            <button
              onClick={onDownloadBackup}
              className="bg-blue-600 hover:bg-blue-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-2xs transition-all cursor-pointer min-h-[44px]"
            >
              <FileJson className="w-4.5 h-4.5" />
              <span>Unduh File Backup (.json) Sekarang</span>
            </button>
          </div>

          {/* Section 2: Upload / Restore Backup JSON */}
          <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3">
            <div>
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                <Upload className="w-4 h-4 text-purple-600" />
                <span>2. Pulihkan / Unggah File Cadangan (Restore Backup .json)</span>
              </h4>
              <p className="text-slate-500 mt-0.5">
                Pilih file backup `.json` dari laptop/HP lain untuk mengembalikan seluruh data kas & SPP.
              </p>
            </div>

            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              onChange={handleFileChange}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-300 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-2 shadow-2xs transition-all cursor-pointer min-h-[44px]"
            >
              <Upload className="w-4.5 h-4.5 text-purple-700" />
              <span>{fileName ? `Pilih File Lain: ${fileName}` : 'Pilih File Backup (.json)'}</span>
            </button>

            {/* Preview Parsed Backup Data */}
            {parsedData && (
              <div className="bg-purple-50/70 border border-purple-200 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between border-b border-purple-200 pb-2">
                  <span className="font-bold text-purple-900 text-xs">Rincian File Backup yang Dibaca:</span>
                  <span className="text-[10px] text-purple-700 font-mono">
                    {new Date(parsedData.exportedAt).toLocaleString('id-ID')}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-slate-800 font-medium">
                  <div>• Nama Sekolah: <strong>{parsedData.schoolProfile?.namaSekolah || '-'}</strong></div>
                  <div>• Total Transaksi: <strong>{parsedData.transactions?.length || 0} Record</strong></div>
                  <div>• Total Siswa: <strong>{parsedData.students?.length || 0} Siswa</strong></div>
                  <div>• Pembayaran SPP: <strong>{parsedData.sppPayments?.length || 0} Record</strong></div>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleConfirmRestore('overwrite')}
                    className="w-full sm:w-auto bg-purple-700 hover:bg-purple-800 text-white font-bold px-3.5 py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer min-h-[44px]"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Ganti / Timpa Seluruh Data Existing</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleConfirmRestore('merge')}
                    className="w-full sm:w-auto bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 font-bold px-3.5 py-2.5 rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer min-h-[44px]"
                  >
                    <span>Gabungkan dengan Data yang Ada</span>
                  </button>
                </div>
              </div>
            )}

          </div>

        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 bg-white border border-slate-300 transition-colors cursor-pointer min-h-[44px]"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};

