import React from 'react';
import { X, Download, FileText, ExternalLink, Image as ImageIcon, Paperclip } from 'lucide-react';
import { Transaction } from '../types';

interface ReceiptPreviewModalProps {
  transaction: Transaction | null;
  onClose: () => void;
}

export const ReceiptPreviewModal: React.FC<ReceiptPreviewModalProps> = ({
  transaction,
  onClose
}) => {
  if (!transaction || !transaction.buktiNotaUrl) return null;

  const dataUrl = transaction.buktiNotaUrl;
  const fileName = transaction.buktiNotaName || `Bukti_${transaction.nomorBukti || transaction.id}`;
  const isPdf = dataUrl.startsWith('data:application/pdf');

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto no-print">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Header */}
        <div className="bg-slate-900 px-6 py-4 flex items-center justify-between text-white border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl border border-emerald-500/30">
              <Paperclip className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Bukti Fisik Transaksi (Nota / Kwitansi)</h3>
              <p className="text-xs text-slate-300 font-mono">
                {transaction.nomorBukti || transaction.id} • {transaction.uraian}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleDownload}
              className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
              title="Unduh Berkas Bukti"
            >
              <Download className="w-4 h-4" />
              <span>Unduh Berkas</span>
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
              title="Tutup"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Preview */}
        <div className="p-6 bg-slate-100 flex flex-col items-center justify-center min-h-[350px] max-h-[75vh] overflow-auto">
          {isPdf ? (
            <div className="w-full h-[500px] flex flex-col items-center justify-center bg-white rounded-xl border border-slate-300 p-4 shadow-sm">
              <iframe
                src={dataUrl}
                title="PDF Bukti Transaksi"
                className="w-full h-full rounded-lg border border-slate-200"
              />
              <div className="mt-3 flex items-center gap-2 text-xs font-medium text-slate-600">
                <FileText className="w-4 h-4 text-rose-600" />
                <span>Dokumen PDF: {fileName}</span>
                <a
                  href={dataUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-emerald-700 font-bold hover:underline ml-2 flex items-center gap-0.5"
                >
                  Buka di Tab Baru <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center space-y-3">
              <div className="max-w-full max-h-[550px] bg-white rounded-xl p-2 border border-slate-300 shadow-md overflow-hidden flex items-center justify-center">
                <img
                  src={dataUrl}
                  alt="Bukti Nota/Kwitansi Transaksi"
                  className="max-w-full max-h-[500px] object-contain rounded-lg"
                />
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-600 font-medium">
                <ImageIcon className="w-4 h-4 text-emerald-600" />
                <span>{fileName}</span>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-3.5 border-t border-slate-200 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Pihak: <span className="font-bold text-slate-800">{transaction.pihak || '-'}</span> | Nominal: <span className="font-bold font-mono text-emerald-700">Rp {(transaction.pemasukan || transaction.pengeluaran).toLocaleString('id-ID')}</span>
          </div>
          <button
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
