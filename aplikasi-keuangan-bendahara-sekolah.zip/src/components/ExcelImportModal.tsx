import React, { useState, useRef } from 'react';
import { 
  FileSpreadsheet, 
  Upload, 
  Download, 
  X, 
  CheckCircle2, 
  AlertTriangle, 
  Info, 
  ArrowRight, 
  FileCheck, 
  HelpCircle,
  RefreshCw,
  Trash2
} from 'lucide-react';
import { Transaction, TransactionType } from '../types';
import { 
  parseExcelFile, 
  downloadExcelTemplate, 
  ImportResult, 
  ParsedImportRow 
} from '../utils/excelUtils';
import { formatRupiah, formatDateIndonesian, generateNomorBukti } from '../utils/formatters';

interface ExcelImportModalProps {
  existingCount: number;
  onImportSuccess: (newTransactions: Transaction[], mode: 'append' | 'overwrite') => void;
  onClose: () => void;
}

export const ExcelImportModal: React.FC<ExcelImportModalProps> = ({
  existingCount,
  onImportSuccess,
  onClose
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [importMode, setImportMode] = useState<'append' | 'overwrite'>('append');
  const [includeWarnings, setIncludeWarnings] = useState<boolean>(true);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const [filterTab, setFilterTab] = useState<'all' | 'valid' | 'invalid'>('all');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (selectedFile: File) => {
    if (!selectedFile) return;

    const validExts = ['.xlsx', '.xls', '.csv'];
    const fileName = selectedFile.name.toLowerCase();
    const isValidExt = validExts.some(ext => fileName.endsWith(ext));

    if (!isValidExt) {
      setErrorMsg('Format file tidak didukung. Harap pilih file berformat .xlsx, .xls, atau .csv');
      return;
    }

    setFile(selectedFile);
    setErrorMsg(null);
    setLoading(true);

    try {
      const result = await parseExcelFile(selectedFile);
      setImportResult(result);
    } catch (err: any) {
      setErrorMsg(err?.message || 'Gagal memproses file Excel.');
      setImportResult(null);
    } finally {
      setLoading(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleConfirmImport = () => {
    if (!importResult) return;

    const rowsToImport = includeWarnings 
      ? [...importResult.validRows, ...importResult.invalidRows]
      : importResult.validRows;

    if (rowsToImport.length === 0) {
      alert('Tidak ada data transaksi valid untuk diimpor.');
      return;
    }

    const timestamp = Date.now();
    const newTxList: Transaction[] = rowsToImport.map((row, idx) => {
      const generatedNoBukti = row.nomorBukti || generateNomorBukti(row.jenis, idx, row.tanggal);
      return {
        id: `TX-IMP-${timestamp}-${idx + 1}`,
        tanggal: row.tanggal,
        jenis: row.jenis,
        kategori: row.kategori,
        uraian: row.uraian,
        pemasukan: row.pemasukan,
        pengeluaran: row.pengeluaran,
        pihak: row.pihak || '-',
        nomorBukti: generatedNoBukti,
        metodePembayaran: row.metodePembayaran,
        catatan: row.catatan ? `[Impor Excel] ${row.catatan}` : '[Impor Excel]',
        createdAt: new Date().toISOString()
      };
    });

    onImportSuccess(newTxList, importMode);
    onClose();
  };

  const handleResetFile = () => {
    setFile(null);
    setImportResult(null);
    setErrorMsg(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 overflow-y-auto font-sans no-print">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-slate-900">
        
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded-xl bg-emerald-100 border border-emerald-200 text-emerald-700">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                Impor Data Transaksi dari Excel
                <span className="text-xs bg-emerald-100 text-emerald-800 font-normal px-2 py-0.5 rounded border border-emerald-200">
                  .XLSX / .XLS / .CSV
                </span>
              </h2>
              <p className="text-xs text-slate-500">
                Impor rekapan buku kas sekolah secara massal dari lembar kerja Microsoft Excel
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={downloadExcelTemplate}
              className="bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold px-3 py-1.5 rounded-lg border border-slate-300 flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
              title="Unduh Format Excel Baku"
            >
              <Download className="w-3.5 h-3.5 text-emerald-600" />
              <span>Unduh Template Excel</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">

          {/* Step 1: File Upload / Drag & Drop */}
          {!file && (
            <div className="space-y-4">
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
                onDragLeave={() => setIsDragOver(false)}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer ${
                  isDragOver
                    ? 'border-emerald-500 bg-emerald-50 scale-[1.01]'
                    : 'border-slate-300 hover:border-emerald-500/60 bg-slate-50/70 hover:bg-white'
                }`}
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={(e) => e.target.files?.[0] && handleFileSelect(e.target.files[0])}
                  accept=".xlsx, .xls, .csv"
                  className="hidden"
                />

                <div className="w-16 h-16 rounded-full bg-emerald-100 border border-emerald-200 flex items-center justify-center mx-auto mb-4 text-emerald-700">
                  <Upload className="w-8 h-8" />
                </div>

                <h3 className="text-base font-bold text-slate-900 mb-1">
                  Tarik & Taruh file Excel di sini
                </h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
                  atau <span className="text-emerald-700 font-semibold underline underline-offset-2">Klik untuk menjelajah file</span> dari komputer/perangkat Anda.
                </p>

                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-slate-200 text-[11px] text-slate-600 shadow-sm">
                  <FileCheck className="w-3.5 h-3.5 text-emerald-600" />
                  Mendukung .XLSX, .XLS, & .CSV (Maksimal 5.000 Transaksi)
                </div>
              </div>

              {/* Instructions Guide */}
              <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                  <Info className="w-4 h-4 text-emerald-600" />
                  <span>Petunjuk Kolom Excel yang Dikenali Otomatis:</span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-slate-600">
                  <div className="bg-white p-2 rounded border border-slate-200 shadow-sm">
                    <span className="text-emerald-800 font-semibold block">Tanggal</span>
                    YYYY-MM-DD / DD/MM/YYYY
                  </div>
                  <div className="bg-white p-2 rounded border border-slate-200 shadow-sm">
                    <span className="text-emerald-800 font-semibold block">Jenis</span>
                    Pemasukan / Pengeluaran
                  </div>
                  <div className="bg-white p-2 rounded border border-slate-200 shadow-sm">
                    <span className="text-emerald-800 font-semibold block">Nominal</span>
                    Kolom Pemasukan & Pengeluaran
                  </div>
                  <div className="bg-white p-2 rounded border border-slate-200 shadow-sm">
                    <span className="text-emerald-800 font-semibold block">Uraian & Kategori</span>
                    Deskripsi & Jenis Anggaran
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Loading Indicator */}
          {loading && (
            <div className="py-12 text-center space-y-3">
              <RefreshCw className="w-8 h-8 text-emerald-600 animate-spin mx-auto" />
              <p className="text-sm text-slate-700 font-medium">Membaca dan memverifikasi data Excel...</p>
            </div>
          )}

          {/* Error Message */}
          {errorMsg && (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-red-800 text-xs flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
              <div className="flex-1">
                <span className="font-bold block text-sm text-red-900">Gagal Memproses File</span>
                <p className="mt-0.5 text-slate-700">{errorMsg}</p>
                <button
                  onClick={handleResetFile}
                  className="mt-2 text-xs font-semibold text-red-700 hover:text-red-900 underline cursor-pointer"
                >
                  Coba Upload File Lain
                </button>
              </div>
            </div>
          )}

          {/* Step 2: Parsed Result Preview & Settings */}
          {importResult && !loading && (
            <div className="space-y-6">
              
              {/* File Info Bar */}
              <div className="flex items-center justify-between bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-emerald-100 text-emerald-700 border border-emerald-200">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 block truncate max-w-xs sm:max-w-md">{file?.name}</span>
                    <span className="text-slate-500 text-[11px]">
                      {(file?.size ? (file.size / 1024).toFixed(1) : 0)} KB • Terbaca {importResult.totalRows} baris
                    </span>
                  </div>
                </div>

                <button
                  onClick={handleResetFile}
                  className="bg-white hover:bg-slate-100 text-slate-700 px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-medium flex items-center gap-1 transition-colors cursor-pointer shadow-sm"
                >
                  <Trash2 className="w-3.5 h-3.5 text-red-600" />
                  <span>Ganti File</span>
                </button>
              </div>

              {/* Summary Badges */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 flex items-center space-x-3">
                  <div className="p-2.5 rounded-lg bg-blue-100 text-blue-700 border border-blue-200">
                    <FileCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-500 uppercase tracking-wider block font-medium">Total Baris Terbaca</span>
                    <span className="text-lg font-bold text-slate-900">{importResult.totalRows} Transaksi</span>
                  </div>
                </div>

                <div className="bg-emerald-50/60 p-3.5 rounded-xl border border-emerald-200 flex items-center space-x-3">
                  <div className="p-2.5 rounded-lg bg-emerald-100 text-emerald-700 border border-emerald-200">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-emerald-800 uppercase tracking-wider block font-medium">Valid (Siap Impor)</span>
                    <span className="text-lg font-bold text-emerald-900">{importResult.validRows.length} Baris</span>
                  </div>
                </div>

                <div className="bg-amber-50/60 p-3.5 rounded-xl border border-amber-200 flex items-center space-x-3">
                  <div className="p-2.5 rounded-lg bg-amber-100 text-amber-700 border border-amber-200">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-[11px] text-amber-800 uppercase tracking-wider block font-medium">Perlu Penyesuaian</span>
                    <span className="text-lg font-bold text-amber-900">{importResult.invalidRows.length} Baris</span>
                  </div>
                </div>
              </div>

              {/* Import Options */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <Info className="w-3.5 h-3.5 text-emerald-600" />
                  Opsi Penggabungan Data:
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <label 
                    className={`flex items-start p-3 rounded-lg border cursor-pointer transition-all ${
                      importMode === 'append'
                        ? 'bg-emerald-50 border-emerald-400 text-slate-900'
                        : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="importMode"
                      checked={importMode === 'append'}
                      onChange={() => setImportMode('append')}
                      className="mt-0.5 mr-2.5 accent-emerald-600"
                    />
                    <div>
                      <span className="font-bold block text-slate-900">Tambahkan ke Data Terdaftar</span>
                      <span className="text-[11px] text-slate-500 block mt-0.5">
                        Menambahkan {importResult.validRows.length} transaksi baru ke {existingCount} data kas saat ini.
                      </span>
                    </div>
                  </label>

                  <label 
                    className={`flex items-start p-3 rounded-lg border cursor-pointer transition-all ${
                      importMode === 'overwrite'
                        ? 'bg-red-50 border-red-400 text-slate-900'
                        : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="importMode"
                      checked={importMode === 'overwrite'}
                      onChange={() => setImportMode('overwrite')}
                      className="mt-0.5 mr-2.5 accent-red-600"
                    />
                    <div>
                      <span className="font-bold block text-slate-900">Gantikan Seluruh Data Kas</span>
                      <span className="text-[11px] text-slate-500 block mt-0.5">
                        Hapus {existingCount} transaksi lama & timpa sepenuhnya dengan hasil impor ini.
                      </span>
                    </div>
                  </label>
                </div>

                {importResult.invalidRows.length > 0 && (
                  <div className="pt-2">
                    <label className="flex items-center text-xs text-slate-700 gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={includeWarnings}
                        onChange={(e) => setIncludeWarnings(e.target.checked)}
                        className="rounded accent-emerald-600"
                      />
                      <span>
                        Tetap impor {importResult.invalidRows.length} baris dengan penyesuaian otomatis (Gunakan default tanggal/uraian/kategori)
                      </span>
                    </label>
                  </div>
                )}
              </div>

              {/* Data Preview Table */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-slate-700">Pratinjau Data Transaksi Excel</span>
                    <span className="text-slate-400">•</span>
                    <span className="text-slate-500">Menampilkan maksimal 50 baris</span>
                  </div>

                  {/* Filter Tabs */}
                  <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200 self-start sm:self-auto">
                    <button
                      type="button"
                      onClick={() => setFilterTab('all')}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                        filterTab === 'all'
                          ? 'bg-white text-slate-900 shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Semua ({importResult.totalRows})
                    </button>
                    <button
                      type="button"
                      onClick={() => setFilterTab('valid')}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                        filterTab === 'valid'
                          ? 'bg-white text-emerald-800 shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Valid ({importResult.validRows.length})
                    </button>
                    <button
                      type="button"
                      onClick={() => setFilterTab('invalid')}
                      className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all cursor-pointer ${
                        filterTab === 'invalid'
                          ? 'bg-white text-amber-800 shadow-sm'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Perlu Penyesuaian ({importResult.invalidRows.length})
                    </button>
                  </div>
                </div>

                {importResult.invalidRows.length > 0 && filterTab !== 'valid' && (
                  <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex items-start gap-2.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div className="space-y-0.5">
                      <span className="font-bold block text-amber-950">
                        Keterangan Penyesuaian Otomatis ({importResult.invalidRows.length} Baris):
                      </span>
                      <p className="text-slate-700 text-[11px] leading-relaxed">
                        Data dengan tanda <span className="font-semibold text-amber-800">Disesuaikan</span> memiliki format yang tidak standar pada Excel (misalnya tanggal kosong, uraian belum ditulis, atau nominal 0). Sistem tetap memprosesnya dengan memberikan nilai default agar data transaksi sekolah Anda dapat diimpor tanpa kendala. Rincian keterangannya tercantum di kolom paling kanan.
                      </p>
                    </div>
                  </div>
                )}

                <div className="overflow-x-auto border border-slate-200 rounded-xl max-h-72 overflow-y-auto">
                  <table className="w-full text-left text-xs text-slate-800">
                    <thead className="bg-slate-100 text-slate-700 font-semibold uppercase tracking-wider sticky top-0 border-b border-slate-200 z-10">
                      <tr>
                        <th className="px-3 py-2">Baris</th>
                        <th className="px-3 py-2">Tanggal</th>
                        <th className="px-3 py-2">Jenis</th>
                        <th className="px-3 py-2">Kategori</th>
                        <th className="px-3 py-2">Uraian</th>
                        <th className="px-3 py-2 text-right">Pemasukan</th>
                        <th className="px-3 py-2 text-right">Pengeluaran</th>
                        <th className="px-3 py-2 text-center">Status</th>
                        <th className="px-3 py-2 min-w-[200px]">Keterangan Penyesuaian</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                      {[...importResult.validRows, ...importResult.invalidRows]
                        .filter(row => {
                          if (filterTab === 'valid') return row.isValid;
                          if (filterTab === 'invalid') return !row.isValid;
                          return true;
                        })
                        .sort((a, b) => a.rowNumber - b.rowNumber)
                        .slice(0, 50)
                        .map((row) => (
                          <tr key={row.rowNumber} className={row.isValid ? 'hover:bg-slate-50' : 'bg-amber-50/40 hover:bg-amber-100/40'}>
                            <td className="px-3 py-2 text-slate-500 font-mono text-[11px]">{row.rowNumber}</td>
                            <td className="px-3 py-2 whitespace-nowrap">{formatDateIndonesian(row.tanggal)}</td>
                            <td className="px-3 py-2 whitespace-nowrap">
                              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                row.jenis === 'Pemasukan' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
                                row.jenis === 'Pengeluaran' ? 'bg-red-100 text-red-800 border border-red-200' :
                                'bg-blue-100 text-blue-800 border border-blue-200'
                              }`}>
                                {row.jenis}
                              </span>
                            </td>
                            <td className="px-3 py-2 text-slate-700 font-medium truncate max-w-[120px]">{row.kategori}</td>
                            <td className="px-3 py-2 text-slate-900 truncate max-w-[180px]">{row.uraian}</td>
                            <td className="px-3 py-2 text-right font-mono text-emerald-700 font-semibold">
                              {row.pemasukan > 0 ? formatRupiah(row.pemasukan) : '-'}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-red-700 font-semibold">
                              {row.pengeluaran > 0 ? formatRupiah(row.pengeluaran) : '-'}
                            </td>
                            <td className="px-3 py-2 text-center whitespace-nowrap">
                              {row.isValid ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-[10px] text-emerald-700 font-semibold border border-emerald-200">
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Sesuai
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-amber-100 text-[10px] text-amber-800 font-bold border border-amber-300">
                                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" /> Perlu Penyesuaian
                                </span>
                              )}
                            </td>
                            <td className="px-3 py-2 text-[11px]">
                              {row.isValid ? (
                                <span className="text-slate-400 italic">Data sudah lengkap & valid</span>
                              ) : (
                                <div className="space-y-0.5">
                                  {row.errors.map((err, errIdx) => (
                                    <div key={errIdx} className="flex items-start gap-1 text-amber-900">
                                      <span className="text-amber-600 font-bold">•</span>
                                      <span>{err}</span>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            Batal
          </button>

          {importResult && (
            <button
              onClick={handleConfirmImport}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-2.5 rounded-xl text-xs flex items-center space-x-2 shadow-md transition-all cursor-pointer"
            >
              <span>
                Proses Impor {includeWarnings 
                  ? (importResult.validRows.length + importResult.invalidRows.length) 
                  : importResult.validRows.length} Transaksi
              </span>
              <ArrowRight className="w-4 h-4 stroke-[3]" />
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
