import React, { useState, useEffect } from 'react';
import { Pencil, Save, X, Calendar, Tag, FileText, User, CreditCard } from 'lucide-react';
import { CategoryData, Transaction, TransactionType } from '../types';

interface EditTransactionModalProps {
  isOpen: boolean;
  transaction: Transaction | null;
  categoryData: CategoryData;
  onClose: () => void;
  onSave: (updatedTx: Transaction) => void;
}

export const EditTransactionModal: React.FC<EditTransactionModalProps> = ({
  isOpen,
  transaction,
  categoryData,
  onClose,
  onSave
}) => {
  if (!isOpen || !transaction) return null;

  const [tanggal, setTanggal] = useState<string>(transaction.tanggal || '');
  const [jenis, setJenis] = useState<TransactionType>(transaction.jenis || 'Pemasukan');
  const [kategori, setKategori] = useState<string>(transaction.kategori || '');
  const [uraian, setUraian] = useState<string>(transaction.uraian || '');
  const [nominal, setNominal] = useState<string>(
    (transaction.pemasukan || transaction.pengeluaran || 0).toString()
  );
  const [pihak, setPihak] = useState<string>(transaction.pihak || '');
  const [nomorBukti, setNomorBukti] = useState<string>(transaction.nomorBukti || transaction.id);
  const [metodePembayaran, setMetodePembayaran] = useState<'Tunai / Kas' | 'Transfer Bank' | 'Cek / Giro'>(
    transaction.metodePembayaran || 'Tunai / Kas'
  );
  const [isRealDaily, setIsRealDaily] = useState<boolean>(transaction.isRealDaily !== false);
  const [syncedToDashboard, setSyncedToDashboard] = useState<boolean>(transaction.syncedToDashboard !== false);

  // Sync state when transaction prop changes
  useEffect(() => {
    if (transaction) {
      setTanggal(transaction.tanggal || '');
      setJenis(transaction.jenis || 'Pemasukan');
      setKategori(transaction.kategori || '');
      setUraian(transaction.uraian || '');
      setNominal((transaction.pemasukan || transaction.pengeluaran || 0).toString());
      setPihak(transaction.pihak || '');
      setNomorBukti(transaction.nomorBukti || transaction.id);
      setMetodePembayaran(transaction.metodePembayaran || 'Tunai / Kas');
      setIsRealDaily(transaction.isRealDaily !== false);
      setSyncedToDashboard(transaction.syncedToDashboard !== false);
    }
  }, [transaction]);

  const availableCategories = categoryData[jenis] || [];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(nominal);

    if (isNaN(amount)) {
      alert('Silakan masukkan nominal transaksi yang valid');
      return;
    }

    if (amount === 0) {
      alert('Silakan masukkan nominal transaksi yang valid (tidak boleh 0)');
      return;
    }

    if (jenis !== 'Saldo Awal' && amount < 0) {
      alert('Silakan masukkan nominal transaksi yang lebih besar dari 0');
      return;
    }

    if (!uraian.trim()) {
      alert('Silakan isi Uraian / Keterangan transaksi');
      return;
    }

    const isMasuk = jenis === 'Pemasukan' || jenis === 'Saldo Awal';

    const updatedTx: Transaction = {
      ...transaction,
      tanggal,
      jenis,
      kategori: kategori || 'Lain-lain',
      uraian: uraian.trim(),
      pemasukan: isMasuk ? amount : 0,
      pengeluaran: !isMasuk ? amount : 0,
      pihak: pihak.trim() || (isMasuk ? 'Penyetor' : 'Penerima'),
      nomorBukti: nomorBukti.trim() || transaction.id,
      metodePembayaran,
      isRealDaily,
      syncedToDashboard
    };

    onSave(updatedTx);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto no-print">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="bg-slate-900 px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-lg border border-emerald-500/30">
              <Pencil className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white">Edit Transaksi Keuangan</h3>
              <p className="text-xs text-slate-400 font-mono">ID: {transaction.id}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-sm text-slate-800">
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Tanggal */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                Tanggal Transaksi
              </label>
              <input
                type="date"
                required
                value={tanggal}
                onChange={(e) => setTanggal(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white font-medium"
              />
            </div>

            {/* Jenis Transaksi */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Jenis Transaksi
              </label>
              <select
                value={jenis}
                onChange={(e) => {
                  const newJenis = e.target.value as TransactionType;
                  setJenis(newJenis);
                  const newCats = categoryData[newJenis] || [];
                  if (newCats.length > 0 && !newCats.includes(kategori)) {
                    setKategori(newCats[0]);
                  }
                }}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white font-bold"
              >
                <option value="Pemasukan">Pemasukan (+)</option>
                <option value="Pengeluaran">Pengeluaran (-)</option>
                <option value="Saldo Awal">Saldo Awal</option>
                <option value="Mutasi Kas">Mutasi Kas</option>
              </select>
            </div>

            {/* Kategori */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-slate-500" />
                Kategori Transaksi
              </label>
              <select
                value={kategori}
                onChange={(e) => setKategori(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white font-medium"
              >
                {availableCategories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
                {!availableCategories.includes(kategori) && kategori && (
                  <option value={kategori}>{kategori}</option>
                )}
              </select>
            </div>

            {/* Nomor Bukti */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {jenis === 'Saldo Awal' ? 'Nomor Bukti Memo (MEMO)' : 'Nomor Bukti (BKM / BKK)'}
              </label>
              <input
                type="text"
                value={nomorBukti}
                onChange={(e) => setNomorBukti(e.target.value)}
                placeholder={jenis === 'Saldo Awal' ? 'Contoh: MEMO/07/2026/01' : 'Contoh: BKM/07/2026/01'}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 font-mono text-xs focus:outline-none focus:border-emerald-500 focus:bg-white"
              />
            </div>

            {/* Nominal */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Nominal Transaksi (Rp)
              </label>
              <input
                type="number"
                required
                step="any"
                value={nominal}
                onChange={(e) => setNominal(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 font-mono font-bold focus:outline-none focus:border-emerald-500 focus:bg-white"
              />
              {jenis === 'Saldo Awal' && (
                <p className="text-[11px] text-blue-700 font-medium mt-1">
                  💡 Saldo Awal dapat bernilai positif (surplus) atau negatif (defisit, contoh: <code className="bg-blue-100 px-1 rounded font-bold">-1500000</code>).
                </p>
              )}
            </div>

            {/* Metode Pembayaran */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <CreditCard className="w-3.5 h-3.5 text-slate-500" />
                Metode Pembayaran
              </label>
              <select
                value={metodePembayaran}
                onChange={(e) => setMetodePembayaran(e.target.value as any)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white font-medium"
              >
                <option value="Tunai / Kas">Tunai / Kas</option>
                <option value="Transfer Bank">Transfer Bank</option>
                <option value="Cek / Giro">Cek / Giro</option>
              </select>
            </div>

          </div>

          {/* Pihak Terkait */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
              <User className="w-3.5 h-3.5 text-slate-500" />
              Pihak Terkait (Penyetor / Penerima / Siswa)
            </label>
            <input
              type="text"
              value={pihak}
              onChange={(e) => setPihak(e.target.value)}
              placeholder="Nama penyetor atau penerima dana..."
              className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
            />
          </div>

          {/* Uraian */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-slate-500" />
              Uraian / Keterangan Transaksi
            </label>
            <textarea
              required
              rows={3}
              value={uraian}
              onChange={(e) => setUraian(e.target.value)}
              placeholder="Rincian lengkap transaksi..."
              className="w-full bg-slate-50 border border-slate-300 rounded-lg p-3 text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white resize-none"
            />
          </div>

          {/* Pilihan Sinkronisasi */}
          <div className="space-y-2">
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <input
                  id="edit-checkbox-synced-dashboard"
                  type="checkbox"
                  checked={syncedToDashboard}
                  onChange={(e) => setSyncedToDashboard(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer"
                />
                <label htmlFor="edit-checkbox-synced-dashboard" className="text-xs font-bold text-slate-800 cursor-pointer select-none">
                  Disinkronkan dengan Dashboard &amp; Transaksi Utama
                </label>
              </div>
              <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                syncedToDashboard 
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}>
                {syncedToDashboard ? 'Tersinkron Dashboard' : 'Tidak Sync Dashboard'}
              </span>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <input
                  id="edit-checkbox-is-real-daily"
                  type="checkbox"
                  checked={isRealDaily}
                  onChange={(e) => setIsRealDaily(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer"
                />
                <label htmlFor="edit-checkbox-is-real-daily" className="text-xs font-bold text-slate-800 cursor-pointer select-none">
                  Disinkronkan dengan Pantau Kas Real
                </label>
              </div>
              <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                isRealDaily 
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}>
                {isRealDaily ? 'Tersinkron Kas Real' : 'Tidak Sync Kas Real'}
              </span>
            </div>
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md shadow-emerald-600/20 transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Perubahan</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
