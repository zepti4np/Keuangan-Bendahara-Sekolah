import React, { useState, useMemo } from 'react';
import { 
  Users, 
  CreditCard, 
  Calendar, 
  Search, 
  Plus, 
  Edit3, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Printer, 
  Download, 
  Upload,
  Filter, 
  Check, 
  X, 
  DollarSign, 
  FileText, 
  BookOpen, 
  Layers, 
  Save, 
  ShieldCheck, 
  Building2,
  School,
  FileSpreadsheet
} from 'lucide-react';
import { Student, SppPayment, AnnualFeePayment, SchoolProfile, Transaction } from '../types';
import { formatRupiah, formatDateIndonesian, formatRupiahNumberOnly as formatNumberOnly } from '../utils/formatters';
import { exportStudentsToExcel } from '../utils/excelUtils';
import { StudentImportModal } from './StudentImportModal';
import { StudentSuratModal } from './StudentSuratModal';

interface SppManagerViewProps {
  students: Student[];
  sppPayments: SppPayment[];
  annualPayments: AnnualFeePayment[];
  schoolProfile: SchoolProfile;
  onSaveStudent: (student: Student) => void;
  onImportStudents: (importedStudents: Student[], mode: 'append' | 'overwrite') => void;
  onDeleteStudent: (id: string) => void;
  onAddSppPayment: (payment: Omit<SppPayment, 'id'> | Omit<SppPayment, 'id'>[], syncToCash: boolean) => void;
  onDeleteSppPayment: (id: string) => void;
  onAddAnnualPayment: (payment: Omit<AnnualFeePayment, 'id'>, syncToCash: boolean) => void;
  onDeleteAnnualPayment: (id: string) => void;
  onSyncAllSppToTransactions?: () => void;
}

const MONTH_NAMES = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
];

export const ACADEMIC_MONTHS = [
  { name: 'Juli', shortName: 'Jul', month: 7, yearOffset: 0 },
  { name: 'Agustus', shortName: 'Agt', month: 8, yearOffset: 0 },
  { name: 'September', shortName: 'Sep', month: 9, yearOffset: 0 },
  { name: 'Oktober', shortName: 'Okt', month: 10, yearOffset: 0 },
  { name: 'November', shortName: 'Nov', month: 11, yearOffset: 0 },
  { name: 'Desember', shortName: 'Des', month: 12, yearOffset: 0 },
  { name: 'Januari', shortName: 'Jan', month: 1, yearOffset: 1 },
  { name: 'Februari', shortName: 'Feb', month: 2, yearOffset: 1 },
  { name: 'Maret', shortName: 'Mar', month: 3, yearOffset: 1 },
  { name: 'April', shortName: 'Apr', month: 4, yearOffset: 1 },
  { name: 'Mei', shortName: 'Mei', month: 5, yearOffset: 1 },
  { name: 'Juni', shortName: 'Jun', month: 6, yearOffset: 1 },
];

export const SppManagerView: React.FC<SppManagerViewProps> = ({
  students,
  sppPayments,
  annualPayments,
  schoolProfile,
  onSaveStudent,
  onImportStudents,
  onDeleteStudent,
  onAddSppPayment,
  onDeleteSppPayment,
  onAddAnnualPayment,
  onDeleteAnnualPayment,
  onSyncAllSppToTransactions
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'spp_matriks' | 'tagihan_tahunan' | 'kelola_siswa' | 'laporan_spp'>('spp_matriks');
  
  // Filters (Tahun Pelajaran / TAPEL)
  const [selectedAcademicYear, setSelectedAcademicYear] = useState<string>('2026/2027');
  const [filterKelas, setFilterKelas] = useState<string>('semua');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const [startYearStr, endYearStr] = selectedAcademicYear.split('/');
  const startYear = parseInt(startYearStr, 10) || 2026;
  const endYear = parseInt(endYearStr, 10) || 2027;

  // Helper: Is payment in selected Academic Year
  const isPaymentInAcademicYear = (pMonth: number, pYear: number) => {
    if (pMonth >= 7) {
      return pYear === startYear;
    } else {
      return pYear === startYear + 1;
    }
  };

  // Modals
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [isStudentModalOpen, setIsStudentModalOpen] = useState<boolean>(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState<boolean>(false);
  const [suratModalData, setSuratModalData] = useState<{ isOpen: boolean; studentId?: string | null }>({ isOpen: false });

  // Modal Input SPP
  const [sppModalData, setSppModalData] = useState<{
    isOpen: boolean;
    student?: Student;
    month?: number;
    year?: number;
    selectedMonths?: number[];
    nominal?: number;
    tanggal?: string;
    catatan?: string;
    syncToCash?: boolean;
  }>({ isOpen: false, syncToCash: true });

  // Modal Input Tagihan Tahunan
  const [annualModalData, setAnnualModalData] = useState<{
    isOpen: boolean;
    student?: Student;
    year?: number;
    namaTagihan?: string;
    nominal?: number;
    tanggal?: string;
    catatan?: string;
    syncToCash?: boolean;
  }>({ isOpen: false, syncToCash: true });

  // List of unique classes
  const availableClasses = useMemo(() => {
    const setK = new Set<string>();
    students.forEach(s => {
      if (s.kelas) setK.add(s.kelas);
    });
    return Array.from(setK).sort();
  }, [students]);

  // Filtered & Sorted Students (By Class, then Alphabetically A-Z by Name)
  const filteredStudents = useMemo(() => {
    return students
      .filter(s => {
        const matchKelas = filterKelas === 'semua' || s.kelas === filterKelas;
        const q = searchTerm.toLowerCase();
        const matchSearch = !searchTerm || 
          s.nama.toLowerCase().includes(q) || 
          s.nisn.toLowerCase().includes(q) || 
          s.kelas.toLowerCase().includes(q);
        return matchKelas && matchSearch;
      })
      .sort((a, b) => {
        const classComp = (a.kelas || '').localeCompare(b.kelas || '', 'id', { numeric: true, sensitivity: 'base' });
        if (classComp !== 0) return classComp;
        return (a.nama || '').localeCompare(b.nama || '', 'id', { sensitivity: 'base' });
      });
  }, [students, filterKelas, searchTerm]);

  // Overall Statistics for Academic Year
  const sppStats = useMemo(() => {
    let totalTargetSppSetahun = 0;
    let totalSppTerkumpul = 0;

    filteredStudents.forEach(s => {
      totalTargetSppSetahun += (s.nominalSppBulanan || 0) * 12;
    });

    sppPayments.forEach(p => {
      if (isPaymentInAcademicYear(p.month, p.year)) {
        const isTargetStudent = filteredStudents.some(s => s.id === p.studentId);
        if (isTargetStudent) {
          totalSppTerkumpul += p.nominalDibayar || 0;
        }
      }
    });

    let totalTargetTahunan = 0;
    let totalTahunanTerkumpul = 0;

    filteredStudents.forEach(s => {
      totalTargetTahunan += s.nominalTagihanTahunan || 0;
    });

    annualPayments.forEach(p => {
      if (p.year === startYear || p.year === endYear) {
        const isTargetStudent = filteredStudents.some(s => s.id === p.studentId);
        if (isTargetStudent) {
          totalTahunanTerkumpul += p.nominalDibayar || 0;
        }
      }
    });

    return {
      totalTargetSppSetahun,
      totalSppTerkumpul,
      sisaTunggakanSpp: Math.max(0, totalTargetSppSetahun - totalSppTerkumpul),
      totalTargetTahunan,
      totalTahunanTerkumpul,
      sisaTunggakanTahunan: Math.max(0, totalTargetTahunan - totalTahunanTerkumpul)
    };
  }, [filteredStudents, sppPayments, annualPayments, startYear, endYear]);

  // Helper for Student SPP Status per month
  const getSppPaymentForStudent = (studentId: string, month: number, year: number) => {
    return sppPayments.find(p => p.studentId === studentId && p.month === month && p.year === year);
  };

  // State for Student History / Detail Modal
  const [historyStudent, setHistoryStudent] = useState<Student | null>(null);

  // Helper for Student SPP Payments
  const getSppPaymentsForStudent = (studentId: string) => {
    return sppPayments.filter(p => p.studentId === studentId);
  };

  // Helper for Student Annual Payments Total
  const getAnnualPaymentsForStudent = (studentId: string) => {
    return annualPayments.filter(p => p.studentId === studentId && (p.year === startYear || p.year === endYear));
  };

  // Handle Save Student
  const handleOpenAddStudent = () => {
    setEditingStudent({
      id: `STU-${Date.now().toString().slice(-6)}`,
      nisn: '',
      nama: '',
      kelas: availableClasses[0] || 'X IPA 1',
      nominalSppBulanan: 200000,
      nominalTagihanTahunan: 1500000,
      keterangan: 'Regular'
    });
    setIsStudentModalOpen(true);
  };

  const handleOpenEditStudent = (student: Student) => {
    setEditingStudent({ ...student });
    setIsStudentModalOpen(true);
  };

  const handleSaveStudentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudent) return;
    if (!editingStudent.nama.trim() || !editingStudent.nisn.trim()) {
      alert('Nama dan NISN wajib diisi');
      return;
    }
    onSaveStudent(editingStudent);
    setIsStudentModalOpen(false);
    setEditingStudent(null);
  };

  // Handle Open Quick SPP Payment Modal
  const handleOpenSppModal = (student: Student, month: number, targetYear: number) => {
    const existing = getSppPaymentForStudent(student.id, month, targetYear);
    const monthName = MONTH_NAMES[month - 1];
    setSppModalData({
      isOpen: true,
      student,
      month,
      year: targetYear,
      selectedMonths: [month],
      nominal: existing ? existing.nominalDibayar : student.nominalSppBulanan,
      tanggal: existing ? existing.tanggalBayar : new Date().toISOString().slice(0, 10),
      catatan: existing ? existing.catatan : `Lunas SPP Bulan ${monthName} ${targetYear} (Tapel ${selectedAcademicYear})`,
      syncToCash: true
    });
  };

  const handleSaveSppSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sppModalData.student || !sppModalData.month || !sppModalData.year) return;
    
    const amount = Number(sppModalData.nominal);
    if (isNaN(amount) || amount <= 0) {
      alert('Nominal pembayaran harus lebih dari 0');
      return;
    }

    const selMonths = sppModalData.selectedMonths && sppModalData.selectedMonths.length > 0
      ? sppModalData.selectedMonths
      : [sppModalData.month];

    if (selMonths.length === 1) {
      const m = selMonths[0];
      const calYear = m >= 7 ? startYear : endYear;
      onAddSppPayment({
        studentId: sppModalData.student.id,
        month: m,
        year: calYear,
        nominalDibayar: amount,
        tanggalBayar: sppModalData.tanggal || new Date().toISOString().slice(0, 10),
        metodePembayaran: 'Tunai / Kas',
        catatan: sppModalData.catatan || `SPP ${MONTH_NAMES[m - 1]} ${calYear} ${sppModalData.student.nama}`
      }, sppModalData.syncToCash ?? true);
    } else {
      const perMonthAmount = Math.round(amount / selMonths.length);
      const payments = selMonths.map(m => {
        const calYear = m >= 7 ? startYear : endYear;
        return {
          studentId: sppModalData.student!.id,
          month: m,
          year: calYear,
          nominalDibayar: perMonthAmount,
          tanggalBayar: sppModalData.tanggal || new Date().toISOString().slice(0, 10),
          metodePembayaran: 'Tunai / Kas',
          catatan: sppModalData.catatan || `SPP ${MONTH_NAMES[m - 1]} ${calYear} ${sppModalData.student!.nama}`
        };
      });
      onAddSppPayment(payments, sppModalData.syncToCash ?? true);
    }

    setSppModalData({ isOpen: false });
  };

  // Handle Open Annual Payment Modal
  const handleOpenAnnualModal = (student: Student) => {
    setAnnualModalData({
      isOpen: true,
      student,
      year: startYear,
      namaTagihan: `Tagihan Tahunan ${selectedAcademicYear}`,
      nominal: student.nominalTagihanTahunan,
      tanggal: new Date().toISOString().slice(0, 10),
      catatan: `Pembayaran Tagihan Tahunan ${student.nama} (${selectedAcademicYear})`,
      syncToCash: true
    });
  };

  const handleSaveAnnualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!annualModalData.student || !annualModalData.year) return;

    const amount = Number(annualModalData.nominal);
    if (isNaN(amount) || amount <= 0) {
      alert('Nominal pembayaran harus lebih dari 0');
      return;
    }

    onAddAnnualPayment({
      studentId: annualModalData.student.id,
      year: annualModalData.year,
      namaTagihan: annualModalData.namaTagihan || 'Tagihan Tahunan',
      nominalDibayar: amount,
      tanggalBayar: annualModalData.tanggal || new Date().toISOString().slice(0, 10),
      metodePembayaran: 'Tunai / Kas',
      catatan: annualModalData.catatan || `Tagihan Tahunan ${annualModalData.student.nama}`
    }, annualModalData.syncToCash ?? true);

    setAnnualModalData({ isOpen: false });
  };

  const handlePrintSpp = () => {
    document.body.classList.add('has-landscape-print');
    const originalTitle = document.title;
    document.title = `Laporan_SPP_Tapel_${selectedAcademicYear.replace('/', '-')}`;
    window.print();
    setTimeout(() => {
      document.body.classList.remove('has-landscape-print');
      document.title = originalTitle;
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <div className="space-y-6 spp-manager-dashboard-main">

      {/* Header & Controls Bar (No Print) */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-xs no-print space-y-4">
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center space-x-3">
            <div className="p-3 bg-emerald-100 border border-emerald-200 rounded-xl text-emerald-800">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">Pembayaran SPP & Tagihan Tahunan Siswa</h2>
              <p className="text-xs text-slate-500">
                Pencatatan rincian pembayaran SPP per bulan & tagihan tahunan khusus per siswa (dapat diisi manual oleh bendahara)
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {onSyncAllSppToTransactions && (
              <button
                onClick={onSyncAllSppToTransactions}
                title="Sinkronkan seluruh data pembayaran SPP & Tahunan yang belum tercatat ke Transaksi Utama Bendahara"
                className="bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs px-3 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
              >
                <DollarSign className="w-4 h-4 text-emerald-200" />
                <span>Sinkron SPP ke Kas Utama</span>
              </button>
            )}

            <button
              onClick={handleOpenAddStudent}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Tambah Siswa</span>
            </button>

            <button
              onClick={() => setIsImportModalOpen(true)}
              className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-2xs cursor-pointer"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
              <span>Impor Data Siswa</span>
            </button>

            <button
              onClick={handlePrintSpp}
              className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-bold text-xs px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-all shadow-2xs cursor-pointer"
            >
              <Printer className="w-4 h-4 text-emerald-600" />
              <span>Cetak Laporan PDF</span>
            </button>
          </div>
        </div>

        {/* Global Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="bg-emerald-50/70 border border-emerald-200 p-3.5 rounded-xl">
            <span className="text-[11px] font-bold text-emerald-800 uppercase block">SPP Terkumpul (Tapel {selectedAcademicYear})</span>
            <div className="text-lg font-extrabold text-emerald-900 mt-0.5 font-mono">
              {formatRupiah(sppStats.totalSppTerkumpul)}
            </div>
            <p className="text-[10px] text-emerald-700 mt-0.5">
              Target Setahun: {formatRupiah(sppStats.totalTargetSppSetahun)}
            </p>
          </div>

          <div className="bg-amber-50/70 border border-amber-200 p-3.5 rounded-xl">
            <span className="text-[11px] font-bold text-amber-800 uppercase block">Tunggakan SPP (Tapel {selectedAcademicYear})</span>
            <div className="text-lg font-extrabold text-amber-900 mt-0.5 font-mono">
              {formatRupiah(sppStats.sisaTunggakanSpp)}
            </div>
            <p className="text-[10px] text-amber-700 mt-0.5">
              {filteredStudents.length} Siswa Terdaftar
            </p>
          </div>

          <div className="bg-blue-50/70 border border-blue-200 p-3.5 rounded-xl">
            <span className="text-[11px] font-bold text-blue-800 uppercase block">Tagihan Tahunan Terkumpul</span>
            <div className="text-lg font-extrabold text-blue-900 mt-0.5 font-mono">
              {formatRupiah(sppStats.totalTahunanTerkumpul)}
            </div>
            <p className="text-[10px] text-blue-700 mt-0.5">
              Target: {formatRupiah(sppStats.totalTargetTahunan)}
            </p>
          </div>

          <div className="bg-purple-50/70 border border-purple-200 p-3.5 rounded-xl">
            <span className="text-[11px] font-bold text-purple-800 uppercase block">Tunggakan Tagihan Tahunan</span>
            <div className="text-lg font-extrabold text-purple-900 mt-0.5 font-mono">
              {formatRupiah(sppStats.sisaTunggakanTahunan)}
            </div>
            <p className="text-[10px] text-purple-700 mt-0.5">
              Kewajiban Tagihan Tahunan
            </p>
          </div>
        </div>

        {/* Navigation Sub-Tabs & Filters */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 pt-2">
          
          {/* Sub-Tabs */}
          <div className="inline-flex bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setActiveSubTab('spp_matriks')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeSubTab === 'spp_matriks'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Matriks SPP Bulanan
            </button>
            <button
              onClick={() => setActiveSubTab('tagihan_tahunan')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeSubTab === 'tagihan_tahunan'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Rincian Tagihan Tahunan
            </button>
            <button
              onClick={() => setActiveSubTab('kelola_siswa')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeSubTab === 'kelola_siswa'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Data Siswa & Nominal
            </button>
            <button
              onClick={() => setActiveSubTab('laporan_spp')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeSubTab === 'laporan_spp'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Laporan Rekapitulasi
            </button>
          </div>

          {/* Filters Bar */}
          <div className="flex flex-wrap items-center gap-2">
            
            {/* Search Input */}
            <div className="relative flex-1 min-w-[160px]">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Cari nama / NISN..."
                className="w-full bg-white border border-slate-300 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Filter Kelas */}
            <select
              value={filterKelas}
              onChange={(e) => setFilterKelas(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-semibold text-slate-800 focus:outline-none focus:border-emerald-500 cursor-pointer"
            >
              <option value="semua">Semua Kelas</option>
              {availableClasses.map(k => (
                <option key={k} value={k}>{k}</option>
              ))}
            </select>

            {/* Filter Tahun Pelajaran (TAPEL) */}
            <select
              value={selectedAcademicYear}
              onChange={(e) => setSelectedAcademicYear(e.target.value)}
              className="bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-bold text-emerald-900 bg-emerald-50/50 border-emerald-300 focus:outline-none focus:border-emerald-500 cursor-pointer font-mono"
            >
              {['2026/2027', '2027/2028', '2028/2029', '2029/2030', '2030/2031'].map(tapel => (
                <option key={tapel} value={tapel}>Tapel {tapel}</option>
              ))}
            </select>

            {/* Tombol Cetak Surat Pemberitahuan Orang Tua */}
            <button
              type="button"
              onClick={() => setSuratModalData({ isOpen: true, studentId: null })}
              className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white text-xs font-bold rounded-lg shadow-xs transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
              title="Cetak Surat Pemberitahuan Rincian Pembayaran ke Orang Tua Siswa"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Cetak Surat Ortuba</span>
            </button>

          </div>

        </div>

      </div>

      {/* ========================================================= */}
      {/* SUB-TAB 1: MATRIKS SPP PER BULAN (JULI - JUNI)             */}
      {/* ========================================================= */}
      {activeSubTab === 'spp_matriks' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-600" />
                Matriks Pembayaran SPP Bulanan Periode Juli - Juni (Tapel {selectedAcademicYear})
              </h3>
              <p className="text-xs text-slate-500">
                Klik tombol status pada bulan untuk mencatat atau merubah pembayaran SPP siswa
              </p>
            </div>

            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1 font-semibold text-emerald-700">
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full inline-block" /> Lunas
              </span>
              <span className="flex items-center gap-1 font-semibold text-amber-700">
                <span className="w-2.5 h-2.5 bg-amber-400 rounded-full inline-block" /> Belum Bayar
              </span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200 sticky top-0">
                <tr>
                  <th className="px-3 py-2.5 w-10 text-center border-r border-slate-200">No</th>
                  <th className="px-3 py-2.5 min-w-[160px] border-r border-slate-200">Nama Siswa / NISN</th>
                  <th className="px-3 py-2.5 w-24 border-r border-slate-200">Kelas</th>
                  <th className="px-3 py-2.5 min-w-[110px] text-right border-r border-slate-200">SPP / Bln</th>
                  {ACADEMIC_MONTHS.map((m) => {
                    const calYear = startYear + m.yearOffset;
                    return (
                      <th key={m.name} className="px-2 py-2 text-center min-w-[85px] border-r border-slate-200">
                        <div>{m.shortName}</div>
                        <div className="text-[9px] font-mono text-slate-400 font-normal font-sans text-transform-none lowercase">'{calYear.toString().slice(-2)}</div>
                      </th>
                    );
                  })}
                  <th className="px-3 py-2.5 min-w-[120px] text-right">Total Paid</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {filteredStudents.length === 0 ? (
                  <tr>
                    <td colSpan={17} className="px-4 py-8 text-center text-slate-500 text-xs">
                      Tidak ada data siswa ditemukan. Silakan tambah data siswa baru di tab 'Data Siswa & Nominal'.
                    </td>
                  </tr>
                ) : (
                  filteredStudents.map((student, idx) => {
                    let totalPaidStudent = 0;

                    return (
                      <tr key={student.id} className="hover:bg-slate-50 transition-colors">
                        <td className="px-3 py-2 text-center font-mono text-slate-500 border-r border-slate-100">
                          {idx + 1}
                        </td>
                        <td className="px-3 py-2 border-r border-slate-100">
                          <div className="font-bold text-slate-900">{student.nama}</div>
                          <div className="flex items-center justify-between gap-1 text-[10px] text-slate-500">
                            <span className="font-mono">NISN: {student.nisn}</span>
                            <button
                              type="button"
                              onClick={() => setHistoryStudent(student)}
                              className="text-emerald-700 hover:text-emerald-900 hover:underline font-semibold cursor-pointer flex items-center gap-0.5"
                              title="Lihat rincian & hapus riwayat pembayaran siswa"
                            >
                              <FileText className="w-3 h-3" />
                              <span>Rincian</span>
                            </button>
                          </div>
                        </td>
                        <td className="px-3 py-2 border-r border-slate-100 font-semibold text-slate-700">
                          {student.kelas}
                        </td>
                        <td className="px-3 py-2 text-right font-mono font-semibold text-slate-800 border-r border-slate-100">
                          {formatRupiah(student.nominalSppBulanan)}
                        </td>

                        {/* 12 Months Columns starting from Juli to Juni */}
                        {ACADEMIC_MONTHS.map((m) => {
                          const calYear = startYear + m.yearOffset;
                          const p = getSppPaymentForStudent(student.id, m.month, calYear);
                          if (p) totalPaidStudent += p.nominalDibayar;

                          const isPaid = !!p && p.nominalDibayar >= student.nominalSppBulanan;
                          const isPartial = !!p && p.nominalDibayar > 0 && p.nominalDibayar < student.nominalSppBulanan;

                          return (
                            <td key={m.name} className="px-1.5 py-2 text-center border-r border-slate-100">
                              <button
                                type="button"
                                onClick={() => handleOpenSppModal(student, m.month, calYear)}
                                className={`w-full py-1 px-1 rounded text-[10px] font-bold transition-all cursor-pointer flex flex-col items-center justify-center border ${
                                  isPaid
                                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300 hover:bg-emerald-200'
                                    : isPartial
                                    ? 'bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200'
                                    : 'bg-slate-50 text-slate-400 border-slate-200 hover:border-emerald-400 hover:text-emerald-700 hover:bg-emerald-50/50'
                                }`}
                                title={p ? `Lunas pada ${formatDateIndonesian(p.tanggalBayar)} (${formatRupiah(p.nominalDibayar)})` : `Klik untuk bayar SPP ${m.name} ${calYear}`}
                              >
                                {p ? (
                                  <>
                                    <span className="flex items-center gap-0.5">
                                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                      <span>Lunas</span>
                                    </span>
                                    <span className="font-mono text-[9px] font-semibold opacity-90">{formatRupiah(p.nominalDibayar)}</span>
                                  </>
                                ) : (
                                  <>
                                    <span className="text-slate-400 font-normal">Belum</span>
                                    <span className="font-mono text-[9px] opacity-60">{formatRupiah(student.nominalSppBulanan)}</span>
                                  </>
                                )}
                              </button>
                            </td>
                          );
                        })}

                        <td className="px-3 py-2 text-right font-mono font-bold text-emerald-700">
                          {formatRupiah(totalPaidStudent)}
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 2: RINCIAN TAGIHAN TAHUNAN                        */}
      {/* ========================================================= */}
      {activeSubTab === 'tagihan_tahunan' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Building2 className="w-4 h-4 text-blue-600" />
                Rincian Tagihan Tahunan Siswa (Tapel {selectedAcademicYear})
              </h3>
              <p className="text-xs text-slate-500">
                Pencatatan cicilan & pelunasan kewajiban pembayaran tahunan per siswa
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2.5 w-10 text-center">No</th>
                  <th className="px-3 py-2.5">Nama Siswa / NISN</th>
                  <th className="px-3 py-2.5">Kelas</th>
                  <th className="px-3 py-2.5 text-right">Kewajiban Tahunan</th>
                  <th className="px-3 py-2.5 text-right">Total Dibayar</th>
                  <th className="px-3 py-2.5 text-right">Sisa Tunggakan</th>
                  <th className="px-3 py-2.5 text-center">Status</th>
                  <th className="px-3 py-2.5 text-center">Aksi / Input Bayar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {filteredStudents.map((student, idx) => {
                  const studentAnnualLogs = getAnnualPaymentsForStudent(student.id);
                  const totalPaid = studentAnnualLogs.reduce((sum, p) => sum + p.nominalDibayar, 0);
                  const sisa = Math.max(0, student.nominalTagihanTahunan - totalPaid);
                  const isLunas = totalPaid >= student.nominalTagihanTahunan;

                  return (
                    <tr key={student.id} className="hover:bg-slate-50">
                      <td className="px-3 py-3 text-center font-mono text-slate-500">{idx + 1}</td>
                      <td className="px-3 py-3">
                        <div className="font-bold text-slate-900">{student.nama}</div>
                        <div className="text-[10px] text-slate-500 font-mono">NISN: {student.nisn}</div>
                      </td>
                      <td className="px-3 py-3 font-semibold text-slate-700">{student.kelas}</td>
                      <td className="px-3 py-3 text-right font-mono font-semibold text-slate-900">
                        {formatRupiah(student.nominalTagihanTahunan)}
                      </td>
                      <td className="px-3 py-3 text-right font-mono font-bold text-emerald-700">
                        {formatRupiah(totalPaid)}
                      </td>
                      <td className="px-3 py-3 text-right font-mono font-bold text-amber-700">
                        {formatRupiah(sisa)}
                      </td>
                      <td className="px-3 py-3 text-center">
                        {isLunas ? (
                          <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" /> LUNAS
                          </span>
                        ) : totalPaid > 0 ? (
                          <span className="inline-flex items-center gap-1 bg-blue-100 text-blue-800 border border-blue-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                            <Clock className="w-3 h-3 text-blue-600" /> CICILAN
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-800 border border-amber-300 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                            <AlertCircle className="w-3 h-3 text-amber-600" /> BELUM BAYAR
                          </span>
                        )}
                      </td>
                      <td className="px-3 py-3 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => handleOpenAnnualModal(student)}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-2.5 py-1 rounded-lg transition-all shadow-2xs cursor-pointer inline-flex items-center gap-1"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Input Bayar</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setHistoryStudent(student)}
                            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-2.5 py-1 rounded-lg transition-all border border-slate-300 cursor-pointer inline-flex items-center gap-1"
                            title="Lihat rincian & hapus riwayat pembayaran"
                          >
                            <FileText className="w-3.5 h-3.5 text-slate-600" />
                            <span>Rincian</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 3: DATA SISWA & NOMINAL NOMINAL NOMINAL           */}
      {/* ========================================================= */}
      {activeSubTab === 'kelola_siswa' && (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
          <div className="p-4 border-b border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-600" />
                Manajemen Data Siswa & Penetapan Tarif SPP / Tagihan Tahunan
              </h3>
              <p className="text-xs text-slate-500">
                Data siswa otomatis diurutkan sesuai abjad (A-Z). Bendahara dapat mengatur tarif SPP dan tagihan per siswa.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={handleOpenAddStudent}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tambah Siswa</span>
              </button>

              <button
                onClick={() => setIsImportModalOpen(true)}
                className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
                <span>Impor Excel</span>
              </button>

              <button
                onClick={() => exportStudentsToExcel(students, schoolProfile.namaSekolah)}
                className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-bold text-xs px-3 py-1.5 rounded-xl flex items-center gap-1.5 shadow-2xs cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-slate-600" />
                <span>Ekspor Excel</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-3 py-2.5 w-10 text-center">No</th>
                  <th className="px-3 py-2.5">NISN</th>
                  <th className="px-3 py-2.5">Nama Lengkap Siswa</th>
                  <th className="px-3 py-2.5">Kelas</th>
                  <th className="px-3 py-2.5 text-right">Tarif SPP / Bulan</th>
                  <th className="px-3 py-2.5 text-right">Tarif Tagihan Tahunan</th>
                  <th className="px-3 py-2.5">Keterangan / Kategori</th>
                  <th className="px-3 py-2.5 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-slate-800">
                {filteredStudents.map((student, idx) => (
                  <tr key={student.id} className="hover:bg-slate-50">
                    <td className="px-3 py-2.5 text-center font-mono text-slate-500">{idx + 1}</td>
                    <td className="px-3 py-2.5 font-mono text-slate-700 font-semibold">{student.nisn}</td>
                    <td className="px-3 py-2.5 font-bold text-slate-900">{student.nama}</td>
                    <td className="px-3 py-2.5 font-semibold text-slate-700">{student.kelas}</td>
                    <td className="px-3 py-2.5 text-right font-mono font-bold text-emerald-700">
                      {formatRupiah(student.nominalSppBulanan)}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono font-bold text-blue-700">
                      {formatRupiah(student.nominalTagihanTahunan)}
                    </td>
                    <td className="px-3 py-2.5 text-slate-600">
                      <span className="bg-slate-100 text-slate-700 border border-slate-200 px-2 py-0.5 rounded text-[10px] font-semibold">
                        {student.keterangan || 'Regular'}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-center">
                      <div className="flex items-center justify-center space-x-1.5">
                        <button
                          type="button"
                          onClick={() => setSuratModalData({ isOpen: true, studentId: student.id })}
                          className="p-1 text-slate-600 hover:text-emerald-800 hover:bg-emerald-50 rounded transition-colors cursor-pointer"
                          title="Cetak Surat Pemberitahuan Ortuba"
                        >
                          <FileText className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleOpenEditStudent(student)}
                          className="p-1 text-slate-600 hover:text-emerald-700 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                          title="Edit Data Siswa"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Yakin ingin menghapus siswa ${student.nama}?`)) {
                              onDeleteStudent(student.id);
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-red-600 hover:bg-slate-100 rounded transition-colors cursor-pointer"
                          title="Hapus Siswa"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* SUB-TAB 4: LAPORAN REKAPITULASI SPP SIAP CETAK (PDF)       */}
      {/* ========================================================= */}
      {activeSubTab === 'laporan_spp' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-6 lg:p-8 shadow-sm space-y-6 print:p-0 print:border-none print:shadow-none print:space-y-4">
          
          {/* Action bar for Laporan Rekapitulasi */}
          <div className="flex flex-wrap items-center justify-between gap-3 no-print bg-slate-50 p-3.5 rounded-xl border border-slate-200">
            <div>
              <h4 className="font-bold text-slate-800 text-xs">Opsi Cetak Laporan</h4>
              <p className="text-[11px] text-slate-500">Cetak rekapitulasi tabel (Landscape) atau surat pemberitahuan individual untuk orang tua/wali murid (Portrait)</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handlePrintSpp}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak Laporan Rekapitulasi (Landscape)</span>
              </button>
              <button
                type="button"
                onClick={() => setSuratModalData({ isOpen: true, studentId: null })}
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs rounded-xl shadow-xs transition-all flex items-center gap-2 cursor-pointer"
              >
                <FileText className="w-4 h-4" />
                <span>Cetak Surat Per Siswa / Ortuba</span>
              </button>
            </div>
          </div>

          {/* Printable Kop Sekolah Header */}
          <div className="border-b-4 border-double border-slate-900 pb-3 mb-3 flex items-center justify-between gap-4">
            <div className="w-14 h-14 sm:w-16 sm:h-16 shrink-0 flex items-center justify-center">
              {schoolProfile.logoYayasanUrl ? (
                <img src={schoolProfile.logoYayasanUrl} alt="Logo Yayasan" className="max-h-full max-w-full object-contain" />
              ) : schoolProfile.logoUrl ? (
                <img src={schoolProfile.logoUrl} alt="Logo Sekolah" className="max-h-full max-w-full object-contain" />
              ) : (
                <School className="w-10 h-10 text-slate-900" />
              )}
            </div>
            <div className="flex-1 text-center font-sans">
              <p className="text-xs sm:text-sm font-bold uppercase tracking-wider text-slate-900 m-0 leading-tight">
                YAYASAN MAHABAKTI ANAK BANGSA
              </p>
              <h1 className="text-base sm:text-xl print:text-lg font-black uppercase tracking-wide text-slate-900 m-0 leading-tight">
                {schoolProfile.namaSekolah || 'SMKS YAMABA PURWAKARTA'}
              </h1>
              <p className="text-[10px] sm:text-xs text-slate-800 font-medium m-0 leading-tight mt-0.5">
                {schoolProfile.alamat || 'Jln. Raya Bungursari Kp. Tirtaraya RT 02 RW 01 Telp. (0264)8302348'}
              </p>
              <p className="text-[10px] sm:text-xs text-slate-800 font-medium m-0 leading-tight">
                {schoolProfile.kotaProvinsi || 'Purwakarta Kode Pos 41181'} • Email: {schoolProfile.email || 'smkyamabapwk@gmail.com'}
              </p>
            </div>
            <div className="w-14 h-14 sm:w-16 sm:h-16 shrink-0 flex items-center justify-center">
              {schoolProfile.logoUrl ? (
                <img src={schoolProfile.logoUrl} alt="Logo Sekolah" className="max-h-full max-w-full object-contain" />
              ) : (
                <School className="w-10 h-10 text-slate-900" />
              )}
            </div>
          </div>

          <div className="text-center mb-4">
            <div className="text-xs sm:text-sm print:text-xs font-extrabold uppercase tracking-widest text-slate-900">
              LAPORAN REKAPITULASI PEMBAYARAN SPP & TAGIHAN TAHUNAN SISWA
            </div>
            <div className="text-xs print:text-[10.5px] font-semibold text-slate-700 font-mono">
              TAHUN PELAJARAN / PERIODE: {selectedAcademicYear} (Juli {startYear} - Juni {endYear})
            </div>
          </div>

          {/* Table Laporan - Full width A4 Landscape */}
          <div className="w-full overflow-x-auto print:overflow-visible rounded-xl border-2 border-slate-900">
            <table className="w-full text-left text-[11px] sm:text-xs print:text-[10px] border-collapse text-slate-900 table-fixed">
              <colgroup>
                <col className="w-[3.5%]" />
                <col className="w-[9.5%]" />
                <col className="w-[19.5%]" />
                <col className="w-[6%]" />
                <col className="w-[9%]" />
                <col className="w-[10.5%]" />
                <col className="w-[10.5%]" />
                <col className="w-[10.5%]" />
                <col className="w-[10.5%]" />
                <col className="w-[10.5%]" />
              </colgroup>
              <thead className="bg-slate-100 font-bold uppercase text-[9.5px] sm:text-[10px] print:text-[9px] tracking-tight border-b-2 border-slate-900">
                <tr>
                  <th className="p-1.5 print:py-1.5 print:px-1 border-r border-slate-900 text-center whitespace-nowrap">NO</th>
                  <th className="p-1.5 print:py-1.5 print:px-1 border-r border-slate-900 text-center whitespace-nowrap">NISN</th>
                  <th className="p-1.5 print:py-1.5 print:px-1 border-r border-slate-900 whitespace-nowrap">NAMA SISWA</th>
                  <th className="p-1.5 print:py-1.5 print:px-1 border-r border-slate-900 text-center whitespace-nowrap">KELAS</th>
                  <th className="p-1.5 print:py-1.5 print:px-1 border-r border-slate-900 text-center whitespace-nowrap">TARIF SPP</th>
                  <th className="p-1.5 print:py-1.5 print:px-1 border-r border-slate-900 text-center whitespace-nowrap">SPP PAID</th>
                  <th className="p-1.5 print:py-1.5 print:px-1 border-r border-slate-900 text-center whitespace-nowrap">TGK SPP</th>
                  <th className="p-1.5 print:py-1.5 print:px-1 border-r border-slate-900 text-center whitespace-nowrap">TAHUNAN</th>
                  <th className="p-1.5 print:py-1.5 print:px-1 border-r border-slate-900 text-center whitespace-nowrap">TAHUNAN PAID</th>
                  <th className="p-1.5 print:py-1.5 print:px-1 text-center whitespace-nowrap">TGK TAHUNAN</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-300 bg-white">
                {filteredStudents.map((s, idx) => {
                  const sppPaidList = sppPayments.filter(p => p.studentId === s.id && isPaymentInAcademicYear(p.month, p.year));
                  const totalSppPaid = sppPaidList.reduce((sum, p) => sum + p.nominalDibayar, 0);
                  const targetSppYear = s.nominalSppBulanan * 12;
                  const tunggakanSpp = Math.max(0, targetSppYear - totalSppPaid);

                  const annPaidList = annualPayments.filter(p => p.studentId === s.id && (p.year === startYear || p.year === endYear));
                  const totalAnnPaid = annPaidList.reduce((sum, p) => sum + p.nominalDibayar, 0);
                  const tunggakanAnn = Math.max(0, s.nominalTagihanTahunan - totalAnnPaid);

                  return (
                    <tr key={s.id} className="hover:bg-slate-50 transition-colors">
                      <td className="p-1.5 print:py-1 print:px-1 text-center font-mono border-r border-slate-300">{idx + 1}</td>
                      <td className="p-1.5 print:py-1 print:px-1 font-mono border-r border-slate-300 text-center whitespace-nowrap">{s.nisn || '-'}</td>
                      <td className="p-1.5 print:py-1 print:px-1 font-bold border-r border-slate-300 break-words leading-tight">{s.nama}</td>
                      <td className="p-1.5 print:py-1 print:px-1 border-r border-slate-300 font-semibold text-center whitespace-nowrap">{s.kelas}</td>
                      <td className="p-1.5 print:py-1 print:px-1 text-right font-mono border-r border-slate-300 whitespace-nowrap">Rp {formatNumberOnly(s.nominalSppBulanan)}</td>
                      <td className="p-1.5 print:py-1 print:px-1 text-right font-mono font-bold text-emerald-800 border-r border-slate-300 whitespace-nowrap">Rp {formatNumberOnly(totalSppPaid)}</td>
                      <td className="p-1.5 print:py-1 print:px-1 text-right font-mono font-bold text-amber-800 border-r border-slate-300 whitespace-nowrap">Rp {formatNumberOnly(tunggakanSpp)}</td>
                      <td className="p-1.5 print:py-1 print:px-1 text-right font-mono border-r border-slate-300 whitespace-nowrap">Rp {formatNumberOnly(s.nominalTagihanTahunan)}</td>
                      <td className="p-1.5 print:py-1 print:px-1 text-right font-mono font-bold text-blue-800 border-r border-slate-300 whitespace-nowrap">Rp {formatNumberOnly(totalAnnPaid)}</td>
                      <td className="p-1.5 print:py-1 print:px-1 text-right font-mono font-bold text-purple-800 whitespace-nowrap">Rp {formatNumberOnly(tunggakanAnn)}</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-900 text-slate-900">
                <tr>
                  <td colSpan={4} className="p-1.5 print:py-1.5 print:px-1 text-right border-r border-slate-900 uppercase text-[9.5px] print:text-[9px] whitespace-nowrap">
                    TOTAL KESELURUHAN LAPORAN:
                  </td>
                  <td className="p-1.5 print:py-1.5 print:px-1 text-right font-mono text-slate-800 border-r border-slate-900 whitespace-nowrap">
                    Rp {formatNumberOnly(filteredStudents.reduce((acc, s) => acc + (s.nominalSppBulanan * 12), 0))}
                  </td>
                  <td className="p-1.5 print:py-1.5 print:px-1 text-right font-mono text-emerald-800 border-r border-slate-900 whitespace-nowrap">
                    Rp {formatNumberOnly(sppStats.totalSppTerkumpul)}
                  </td>
                  <td className="p-1.5 print:py-1.5 print:px-1 text-right font-mono text-amber-800 border-r border-slate-900 whitespace-nowrap">
                    Rp {formatNumberOnly(sppStats.sisaTunggakanSpp)}
                  </td>
                  <td className="p-1.5 print:py-1.5 print:px-1 text-right font-mono border-r border-slate-900 whitespace-nowrap">
                    Rp {formatNumberOnly(sppStats.totalTargetTahunan)}
                  </td>
                  <td className="p-1.5 print:py-1.5 print:px-1 text-right font-mono text-blue-800 border-r border-slate-900 whitespace-nowrap">
                    Rp {formatNumberOnly(sppStats.totalTahunanTerkumpul)}
                  </td>
                  <td className="p-1.5 print:py-1.5 print:px-1 text-right font-mono text-purple-800 whitespace-nowrap">
                    Rp {formatNumberOnly(sppStats.sisaTunggakanTahunan)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Signatures Block */}
          <div className="pt-6 flex justify-between items-start text-xs font-semibold text-slate-800 break-inside-avoid">
            <div className="text-left pl-2">
              <p className="m-0">Mengetahui,</p>
              <p className="font-bold text-slate-900 m-0">Kepala Sekolah</p>
              <div className="h-16" />
              <p className="font-bold underline text-slate-900 m-0">{schoolProfile.kepalaSekolah || '................................'}</p>
              <p className="text-[11px] font-mono text-slate-600 m-0">NIP: {schoolProfile.nipKepalaSekolah || '-'}</p>
            </div>

            <div className="text-left pr-2">
              <p className="m-0">{schoolProfile.kotaProvinsi || 'Purwakarta'}, {formatDateIndonesian(new Date().toISOString().slice(0, 10))}</p>
              <p className="font-bold text-slate-900 m-0">Bendahara Sekolah</p>
              <div className="h-16" />
              <p className="font-bold underline text-slate-900 m-0">{schoolProfile.bendahara || '................................'}</p>
              <p className="text-[11px] font-mono text-slate-600 m-0">NIP: {schoolProfile.nipBendahara || '-'}</p>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: EDIT / TAMBAH DATA SISWA                           */}
      {/* ========================================================= */}
      {isStudentModalOpen && editingStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 no-print">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-5 shadow-2xl space-y-4 text-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="font-bold text-base text-slate-900">
                {editingStudent.id ? 'Edit Data & Nominal Siswa' : 'Tambah Siswa Baru'}
              </h3>
              <button
                onClick={() => setIsStudentModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveStudentSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">NISN / Nomor Induk</label>
                <input
                  type="text"
                  value={editingStudent.nisn}
                  onChange={(e) => setEditingStudent({ ...editingStudent, nisn: e.target.value })}
                  placeholder="005XXXXXXX"
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Lengkap Siswa</label>
                <input
                  type="text"
                  value={editingStudent.nama}
                  onChange={(e) => setEditingStudent({ ...editingStudent, nama: e.target.value })}
                  placeholder="Nama Siswa..."
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Kelas</label>
                <input
                  type="text"
                  value={editingStudent.kelas}
                  onChange={(e) => setEditingStudent({ ...editingStudent, kelas: e.target.value })}
                  placeholder="X IPA 1"
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nominal SPP Bulanan Khusus (Rp)
                </label>
                <input
                  type="number"
                  value={editingStudent.nominalSppBulanan}
                  onChange={(e) => setEditingStudent({ ...editingStudent, nominalSppBulanan: Number(e.target.value) })}
                  placeholder="200000"
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono font-bold text-emerald-800 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Nominal Tagihan Tahunan Khusus (Rp)
                </label>
                <input
                  type="number"
                  value={editingStudent.nominalTagihanTahunan}
                  onChange={(e) => setEditingStudent({ ...editingStudent, nominalTagihanTahunan: Number(e.target.value) })}
                  placeholder="1500000"
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs font-mono font-bold text-blue-800 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Keterangan / Kategori Siswa</label>
                <input
                  type="text"
                  value={editingStudent.keterangan || ''}
                  onChange={(e) => setEditingStudent({ ...editingStudent, keterangan: e.target.value })}
                  placeholder="Contoh: Regular / Beasiswa 50% / Yatim"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsStudentModalOpen(false)}
                  className="px-3 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow-2xs cursor-pointer"
                >
                  Simpan Data Siswa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: INPUT PEMBAYARAN SPP BULANAN                       */}
      {/* ========================================================= */}
      {sppModalData.isOpen && sppModalData.student && sppModalData.month && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 no-print">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-5 shadow-2xl space-y-4 text-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="font-bold text-base text-slate-900">
                  Input Pembayaran SPP Bulanan
                </h3>
                <p className="text-xs text-slate-500">
                  {sppModalData.student.nama} ({sppModalData.student.kelas}) - Bulan {MONTH_NAMES[sppModalData.month - 1]} {sppModalData.year}
                </p>
              </div>
              <button
                onClick={() => setSppModalData({ isOpen: false })}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSppSubmit} className="space-y-3 text-xs">
              {(() => {
                const existingSpp = sppModalData.student && sppModalData.month && sppModalData.year
                  ? getSppPaymentForStudent(sppModalData.student.id, sppModalData.month, sppModalData.year)
                  : null;

                const currentSelMonths = sppModalData.selectedMonths || [sppModalData.month!];

                return (
                  <>
                    {existingSpp && (
                      <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-amber-900 text-xs flex items-center justify-between">
                        <div>
                          <span className="font-bold">Status:</span> Sudah dibayar Rp {formatRupiah(existingSpp.nominalDibayar)} ({formatDateIndonesian(existingSpp.tanggalBayar)})
                        </div>
                      </div>
                    )}

                    {/* Multi-Month Selector Grid */}
                    <div>
                      <label className="block font-semibold text-slate-700 mb-1.5">
                        Bulan Pembayaran ({currentSelMonths.length} Bulan Dipilih):
                      </label>
                      <div className="grid grid-cols-4 gap-1.5 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                        {ACADEMIC_MONTHS.map((m) => {
                          const calYear = startYear + m.yearOffset;
                          const isSelected = currentSelMonths.includes(m.month);
                          const existing = sppModalData.student ? getSppPaymentForStudent(sppModalData.student.id, m.month, calYear) : null;

                          return (
                            <button
                              key={m.name}
                              type="button"
                              onClick={() => {
                                let nextMonths: number[];
                                if (isSelected) {
                                  if (currentSelMonths.length === 1) return; // Keep at least 1 month
                                  nextMonths = currentSelMonths.filter(x => x !== m.month);
                                } else {
                                  nextMonths = [...currentSelMonths, m.month].sort((a, b) => {
                                    const orderA = a >= 7 ? a - 6 : a + 6;
                                    const orderB = b >= 7 ? b - 6 : b + 6;
                                    return orderA - orderB;
                                  });
                                }
                                const monthNamesSelected = nextMonths.map(mx => MONTH_NAMES[mx - 1]).join(', ');
                                const newNominal = (sppModalData.student?.nominalSppBulanan || 0) * nextMonths.length;
                                setSppModalData({
                                  ...sppModalData,
                                  selectedMonths: nextMonths,
                                  nominal: newNominal,
                                  catatan: `Lunas SPP Bulan ${monthNamesSelected} (Tapel ${selectedAcademicYear})`
                                });
                              }}
                              className={`py-1.5 px-2 rounded-lg text-[11px] font-bold transition-all border cursor-pointer text-center ${
                                isSelected
                                  ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs ring-2 ring-emerald-300'
                                  : existing
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                  : 'bg-white text-slate-600 border-slate-200 hover:border-emerald-400 hover:bg-emerald-50/30'
                              }`}
                            >
                              <div>{m.shortName}</div>
                              <div className="text-[9px] font-mono opacity-80">
                                {existing ? 'Lunas' : formatRupiah(sppModalData.student?.nominalSppBulanan || 0)}
                              </div>
                            </button>
                          );
                        })}
                      </div>
                      <p className="text-[11px] text-emerald-800 font-medium mt-1">
                        * Klik bulan di atas untuk bayar/pilih sekaligus beberapa bulan sekaligus dalam 1 total transaksi.
                      </p>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">
                        Total Nominal Pembayaran SPP ({currentSelMonths.length} Bulan) (Rp)
                      </label>
                      <input
                        type="number"
                        value={sppModalData.nominal}
                        onChange={(e) => setSppModalData({ ...sppModalData, nominal: Number(e.target.value) })}
                        required
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2.5 text-base font-bold font-mono text-emerald-800 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Tanggal Pembayaran</label>
                      <input
                        type="date"
                        value={sppModalData.tanggal}
                        onChange={(e) => setSppModalData({ ...sppModalData, tanggal: e.target.value })}
                        required
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 mb-1">Catatan / Keterangan</label>
                      <input
                        type="text"
                        value={sppModalData.catatan}
                        onChange={(e) => setSppModalData({ ...sppModalData, catatan: e.target.value })}
                        placeholder="Catatan..."
                        className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                      />
                    </div>

                    {/* Sync to Cash BKM Checkbox */}
                    <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl flex items-center space-x-2.5">
                      <input
                        type="checkbox"
                        id="chk-sync-cash"
                        checked={sppModalData.syncToCash}
                        onChange={(e) => setSppModalData({ ...sppModalData, syncToCash: e.target.checked })}
                        className="rounded text-emerald-600 focus:ring-emerald-500 cursor-pointer w-4 h-4"
                      />
                      <label htmlFor="chk-sync-cash" className="text-xs text-emerald-900 font-semibold cursor-pointer">
                        Otomatis catat transaksi ini sebagai Kas Masuk (BKM) di Keuangan Utama Sekolah
                      </label>
                    </div>

                    <div className="pt-2 flex items-center justify-between">
                      {existingSpp ? (
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Yakin ingin menghapus pembayaran SPP ${MONTH_NAMES[sppModalData.month! - 1]} ${sppModalData.year} untuk ${sppModalData.student?.nama}?`)) {
                              onDeleteSppPayment(existingSpp.id);
                              setSppModalData({ isOpen: false });
                            }
                          }}
                          className="px-3 py-2 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 font-bold rounded-lg cursor-pointer flex items-center gap-1.5 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Hapus SPP</span>
                        </button>
                      ) : <div />}

                      <div className="flex space-x-2">
                        <button
                          type="button"
                          onClick={() => setSppModalData({ isOpen: false })}
                          className="px-3 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold cursor-pointer"
                        >
                          Batal
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg shadow-2xs cursor-pointer"
                        >
                          Simpan Pembayaran SPP
                        </button>
                      </div>
                    </div>
                  </>
                );
              })()}
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: INPUT PEMBAYARAN TAGIHAN TAHUNAN                   */}
      {/* ========================================================= */}
      {annualModalData.isOpen && annualModalData.student && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 no-print">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-5 shadow-2xl space-y-4 text-slate-900">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="font-bold text-base text-slate-900">
                  Input Pembayaran Tagihan Tahunan
                </h3>
                <p className="text-xs text-slate-500">
                  {annualModalData.student.nama} ({annualModalData.student.kelas}) - Tahun {annualModalData.year}
                </p>
              </div>
              <button
                onClick={() => setAnnualModalData({ isOpen: false })}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAnnualSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nama Tagihan Tahunan</label>
                <input
                  type="text"
                  value={annualModalData.namaTagihan}
                  onChange={(e) => setAnnualModalData({ ...annualModalData, namaTagihan: e.target.value })}
                  placeholder="Uang Gedung / Daftar Ulang / Seragam"
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Nominal Pembayaran (Rp)</label>
                <input
                  type="number"
                  value={annualModalData.nominal}
                  onChange={(e) => setAnnualModalData({ ...annualModalData, nominal: Number(e.target.value) })}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2.5 text-base font-bold font-mono text-blue-800 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Tanggal Pembayaran</label>
                <input
                  type="date"
                  value={annualModalData.tanggal}
                  onChange={(e) => setAnnualModalData({ ...annualModalData, tanggal: e.target.value })}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Catatan / Keterangan</label>
                <input
                  type="text"
                  value={annualModalData.catatan}
                  onChange={(e) => setAnnualModalData({ ...annualModalData, catatan: e.target.value })}
                  placeholder="Cicilan ke-1 / Lunas..."
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Sync to Cash BKM Checkbox */}
              <div className="bg-blue-50 border border-blue-200 p-3 rounded-xl flex items-center space-x-2.5">
                <input
                  type="checkbox"
                  id="chk-sync-cash-ann"
                  checked={annualModalData.syncToCash}
                  onChange={(e) => setAnnualModalData({ ...annualModalData, syncToCash: e.target.checked })}
                  className="rounded text-blue-600 focus:ring-blue-500 cursor-pointer w-4 h-4"
                />
                <label htmlFor="chk-sync-cash-ann" className="text-xs text-blue-900 font-semibold cursor-pointer">
                  Otomatis catat transaksi ini sebagai Kas Masuk (BKM) di Keuangan Utama Sekolah
                </label>
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setAnnualModalData({ isOpen: false })}
                  className="px-3 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-lg shadow-2xs cursor-pointer"
                >
                  Simpan Pembayaran Tahunan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL IMPOR DATA SISWA (EXCEL / CSV) */}
      {isImportModalOpen && (
        <StudentImportModal
          existingCount={students.length}
          onImportSuccess={(importedStudents, mode) => {
            onImportStudents(importedStudents, mode);
            setIsImportModalOpen(false);
          }}
          onClose={() => setIsImportModalOpen(false)}
        />
      )}

      {/* MODAL RINCIAN & HAPUS RIWAYAT PEMBAYARAN SISWA */}
      {historyStudent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 overflow-y-auto no-print">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-2xl p-6 shadow-2xl space-y-5 text-slate-900 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div>
                <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  Rincian & Riwayat Pembayaran Siswa
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  {historyStudent.nama} • {historyStudent.kelas} (NISN: {historyStudent.nisn})
                </p>
              </div>
              <button
                onClick={() => setHistoryStudent(null)}
                className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-1">
              {/* Section 1: Pembayaran SPP Bulanan */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-900 flex items-center gap-1.5 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
                  <Calendar className="w-4 h-4 text-emerald-700" />
                  Riwayat Pembayaran SPP Bulanan
                </h4>
                {getSppPaymentsForStudent(historyStudent.id).length === 0 ? (
                  <p className="text-xs text-slate-400 italic py-2 px-1">Belum ada riwayat pembayaran SPP yang dicatat.</p>
                ) : (
                  <div className="overflow-x-auto border border-slate-200 rounded-xl">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                        <tr>
                          <th className="p-2.5">Bulan & Tahun</th>
                          <th className="p-2.5 text-right">Nominal</th>
                          <th className="p-2.5">Tanggal Bayar</th>
                          <th className="p-2.5">Catatan</th>
                          <th className="p-2.5 text-center">Aksi Hapus</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {getSppPaymentsForStudent(historyStudent.id).map(p => (
                          <tr key={p.id} className="hover:bg-slate-50">
                            <td className="p-2.5 font-bold text-slate-900">
                              {MONTH_NAMES[p.month - 1]} {p.year}
                            </td>
                            <td className="p-2.5 text-right font-mono font-bold text-emerald-700">
                              {formatRupiah(p.nominalDibayar)}
                            </td>
                            <td className="p-2.5 font-mono text-slate-600">
                              {formatDateIndonesian(p.tanggalBayar)}
                            </td>
                            <td className="p-2.5 text-slate-500">{p.catatan || '-'}</td>
                            <td className="p-2.5 text-center">
                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(`Yakin ingin menghapus pembayaran SPP ${MONTH_NAMES[p.month - 1]} ${p.year}?`)) {
                                    onDeleteSppPayment(p.id);
                                  }
                                }}
                                className="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition-colors cursor-pointer border border-red-200 inline-flex items-center gap-1 font-semibold text-[11px]"
                                title="Hapus catatan pembayaran SPP ini"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Hapus</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Section 2: Pembayaran Tagihan Tahunan */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900 flex items-center gap-1.5 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200">
                  <Building2 className="w-4 h-4 text-blue-700" />
                  Riwayat Pembayaran Tagihan Tahunan
                </h4>
                {annualPayments.filter(p => p.studentId === historyStudent.id).length === 0 ? (
                  <p className="text-xs text-slate-400 italic py-2 px-1">Belum ada riwayat pembayaran tagihan tahunan.</p>
                ) : (
                  <div className="overflow-x-auto border border-slate-200 rounded-xl">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px]">
                        <tr>
                          <th className="p-2.5">Nama Tagihan</th>
                          <th className="p-2.5 text-right">Nominal</th>
                          <th className="p-2.5">Tanggal Bayar</th>
                          <th className="p-2.5">Catatan</th>
                          <th className="p-2.5 text-center">Aksi Hapus</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {annualPayments.filter(p => p.studentId === historyStudent.id).map(p => (
                          <tr key={p.id} className="hover:bg-slate-50">
                            <td className="p-2.5 font-bold text-slate-900">
                              {p.namaTagihan || 'Tagihan Tahunan'} ({p.year})
                            </td>
                            <td className="p-2.5 text-right font-mono font-bold text-blue-700">
                              {formatRupiah(p.nominalDibayar)}
                            </td>
                            <td className="p-2.5 font-mono text-slate-600">
                              {formatDateIndonesian(p.tanggalBayar)}
                            </td>
                            <td className="p-2.5 text-slate-500">{p.catatan || '-'}</td>
                            <td className="p-2.5 text-center">
                              <button
                                type="button"
                                onClick={() => {
                                  if (confirm(`Yakin ingin menghapus pembayaran ${p.namaTagihan}?`)) {
                                    onDeleteAnnualPayment(p.id);
                                  }
                                }}
                                className="p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg transition-colors cursor-pointer border border-red-200 inline-flex items-center gap-1 font-semibold text-[11px]"
                                title="Hapus catatan pembayaran tahunan ini"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Hapus</span>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setHistoryStudent(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      </div>

      {/* Modal Cetak Surat Pemberitahuan Per Siswa / Ortuba */}
      <StudentSuratModal
        isOpen={suratModalData.isOpen}
        onClose={() => setSuratModalData({ isOpen: false })}
        students={filteredStudents}
        initialStudentId={suratModalData.studentId}
        sppPayments={sppPayments}
        annualPayments={annualPayments}
        schoolProfile={schoolProfile}
        selectedAcademicYear={selectedAcademicYear}
      />

    </div>
  );
};
