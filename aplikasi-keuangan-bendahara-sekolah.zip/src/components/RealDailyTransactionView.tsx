import React, { useState, useMemo } from 'react';
import { 
  Calendar, 
  PlusCircle, 
  Search, 
  Printer, 
  Edit3, 
  Trash2, 
  CheckCircle2, 
  ArrowUpRight, 
  ArrowDownRight, 
  Wallet, 
  FileText,
  Clock,
  Sparkles,
  ShieldCheck,
  Building2,
  X,
  TrendingUp,
  Download
} from 'lucide-react';
import { Transaction, TransactionType, CategoryData, SchoolProfile } from '../types';
import { formatRupiah, formatDateIndonesian } from '../utils/formatters';
import { EditTransactionModal } from './EditTransactionModal';

interface RealDailyTransactionViewProps {
  transactions: Transaction[];
  categoryData: CategoryData;
  schoolProfile: SchoolProfile;
  onSaveTransaction: (tx: Omit<Transaction, 'id' | 'createdAt'>) => Promise<void>;
  onEditTransaction: (tx: Transaction) => void;
  onDeleteTransaction: (id: string) => void;
  onSelectKwitansi: (tx: Transaction) => void;
  onOpenNewTransaction?: () => void;
}

export const RealDailyTransactionView: React.FC<RealDailyTransactionViewProps> = ({
  transactions,
  categoryData,
  schoolProfile,
  onSaveTransaction,
  onEditTransaction,
  onDeleteTransaction,
  onSelectKwitansi,
  onOpenNewTransaction
}) => {
  // Get today's date in YYYY-MM-DD
  const getTodayStr = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const dd = String(today.getDate()).padStart(2, '0');
    return `${yyyy}-${mm}-${dd}`;
  };

  // Get current month in YYYY-MM
  const getCurrentMonthStr = () => {
    const today = new Date();
    const yyyy = today.getFullYear();
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    return `${yyyy}-${mm}`;
  };

  // Filter Modes: 'month' | 'range' | 'single' | 'all'
  const [dateFilterMode, setDateFilterMode] = useState<'month' | 'range' | 'single' | 'all'>('month');
  const [selectedMonth, setSelectedMonth] = useState<string>(getCurrentMonthStr());
  const [startDate, setStartDate] = useState<string>(`${getCurrentMonthStr()}-01`);
  const [endDate, setEndDate] = useState<string>(getTodayStr());
  const [selectedDate, setSelectedDate] = useState<string>(getTodayStr());

  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);

  // Auto-migrate any existing legacy local unsynced memos into main synced transactions
  React.useEffect(() => {
    try {
      const saved = localStorage.getItem('real_daily_unsynced_memos');
      if (saved) {
        const parsed: Transaction[] = JSON.parse(saved);
        if (parsed && parsed.length > 0) {
          parsed.forEach((memo) => {
            onSaveTransaction({
              tanggal: memo.tanggal,
              jenis: memo.jenis || 'Saldo Awal',
              kategori: memo.kategori || 'Penetapan Saldo Awal',
              uraian: memo.uraian,
              pemasukan: memo.pemasukan || 0,
              pengeluaran: memo.pengeluaran || 0,
              pihak: memo.pihak || 'Bendahara Kas Sekolah',
              nomorBukti: memo.nomorBukti,
              metodePembayaran: memo.metodePembayaran || 'Tunai / Kas',
              isRealDaily: true,
              catatan: 'Migrasi Memo Saldo Awal ke Transaksi Utama'
            });
          });
          localStorage.removeItem('real_daily_unsynced_memos');
        }
      }
    } catch (err) {
      console.error('Error migrating legacy local memos:', err);
    }
  }, []);

  // Form State for Quick Real Daily Entry
  const [tanggal, setTanggal] = useState<string>(getTodayStr());
  const [jenis, setJenis] = useState<TransactionType>('Pemasukan');
  const [kategori, setKategori] = useState<string>('');
  const [uraian, setUraian] = useState<string>('');
  const [nominalStr, setNominalStr] = useState<string>('');
  const [pihak, setPihak] = useState<string>('');
  const [metodePembayaran, setMetodePembayaran] = useState<'Tunai / Kas' | 'Transfer Bank' | 'Cek / Giro'>('Tunai / Kas');
  const [syncedToDashboard, setSyncedToDashboard] = useState<boolean>(true);

  // Transactions list for display (filtered by isRealDaily !== false)
  const allRealDailyTransactions = useMemo(() => {
    return [...transactions]
      .filter(t => t.isRealDaily !== false)
      .sort((a, b) => new Date(b.tanggal).getTime() - new Date(a.tanggal).getTime());
  }, [transactions]);

  // Categories list based on current transaction type
  const availableCategories = useMemo(() => {
    const list = categoryData[jenis] || [];
    return list;
  }, [categoryData, jenis]);

  // Set default category when type changes
  React.useEffect(() => {
    if (availableCategories.length > 0 && (!kategori || !availableCategories.includes(kategori))) {
      setKategori(availableCategories[0]);
    }
  }, [availableCategories, jenis]);

  // Preview generated Nomor Bukti auto
  const nominalValue = useMemo(() => {
    const isNegative = nominalStr.startsWith('-');
    const cleanDigits = nominalStr.replace(/\D/g, '');
    if (!cleanDigits) return 0;
    const parsed = parseInt(cleanDigits, 10);
    if (isNaN(parsed)) return 0;
    return isNegative ? -parsed : parsed;
  }, [nominalStr]);

  // Handle Form Submit
  const handleSubmitRealTx = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uraian.trim()) {
      alert('Mohon isi Uraian Transaksi Harian Real');
      return;
    }
    if (nominalValue === 0) {
      alert('Silakan masukkan nominal transaksi yang valid (tidak boleh 0)');
      return;
    }
    if (jenis !== 'Saldo Awal' && nominalValue < 0) {
      alert('Nominal transaksi harus lebih besar dari 0');
      return;
    }

    setIsSubmitting(true);
    try {
      const isMasuk = jenis === 'Pemasukan' || jenis === 'Saldo Awal';

      // Save transaction with syncedToDashboard flag
      await onSaveTransaction({
        tanggal,
        jenis,
        kategori: kategori || (jenis === 'Saldo Awal' ? 'Penetapan Saldo Awal' : 'Umum'),
        uraian: uraian.trim(),
        pemasukan: isMasuk ? nominalValue : 0,
        pengeluaran: !isMasuk ? nominalValue : 0,
        pihak: pihak.trim() || (jenis === 'Saldo Awal' ? 'Bendahara Kas Sekolah' : (isMasuk ? 'Penyetor Real' : 'Penerima Real')),
        nomorBukti: '-',
        metodePembayaran,
        isRealDaily: true,
        syncedToDashboard,
        catatan: syncedToDashboard ? 'Pencatatan Harian Real (Tersinkronasi)' : 'Pencatatan Harian Real (Tidak Sync Dashboard)'
      });

      if (syncedToDashboard) {
        alert(`Berhasil mencatat ${jenis} di Pantau Kas Real & disinkronkan ke Dashboard & Transaksi Utama!`);
      } else {
        alert(`Berhasil mencatat ${jenis} di Pantau Kas Real (TIDAK disinkronkan ke Dashboard & Transaksi Utama).`);
      }

      // Reset form
      setUraian('');
      setNominalStr('');
      setPihak('');
      // Sync selected date to transaction date
      setSelectedDate(tanggal);
    } catch (err) {
      console.error('Error saving real daily transaction:', err);
      alert('Gagal menyimpan transaksi harian real');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Options for month dropdown (YYYY-MM)
  const monthOptions = useMemo(() => {
    const set = new Set<string>();
    set.add(getCurrentMonthStr());
    allRealDailyTransactions.forEach(t => {
      if (t.tanggal && t.tanggal.length >= 7) {
        set.add(t.tanggal.substring(0, 7));
      }
    });
    const sorted = Array.from(set).sort().reverse();
    const MONTH_NAMES = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];

    return sorted.map(ym => {
      const [year, monthStr] = ym.split('-');
      const monthIdx = parseInt(monthStr, 10) - 1;
      const name = MONTH_NAMES[monthIdx] || monthStr;
      return {
        value: ym,
        label: `${name} ${year}`
      };
    });
  }, [allRealDailyTransactions]);

  // Label for active filtered period
  const activePeriodLabel = useMemo(() => {
    if (dateFilterMode === 'month') {
      const opt = monthOptions.find(m => m.value === selectedMonth);
      return opt ? `Bulan ${opt.label}` : selectedMonth;
    } else if (dateFilterMode === 'range') {
      return `${formatDateIndonesian(startDate)} s/d ${formatDateIndonesian(endDate)}`;
    } else if (dateFilterMode === 'single') {
      return formatDateIndonesian(selectedDate);
    }
    return 'Seluruh Periode Harian';
  }, [dateFilterMode, selectedMonth, startDate, endDate, selectedDate, monthOptions]);

  // Filtered transactions for the view
  const filteredTransactions = useMemo(() => {
    return allRealDailyTransactions.filter(t => {
      // Date filter mode
      if (dateFilterMode === 'month') {
        if (!t.tanggal || !t.tanggal.startsWith(selectedMonth)) {
          return false;
        }
      } else if (dateFilterMode === 'range') {
        if (startDate && t.tanggal < startDate) return false;
        if (endDate && t.tanggal > endDate) return false;
      } else if (dateFilterMode === 'single') {
        if (t.tanggal !== selectedDate) return false;
      }
      // 'all' mode passes all dates

      // Type filter
      if (filterType !== 'all' && t.jenis !== filterType) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchUraian = t.uraian.toLowerCase().includes(q);
        const matchPihak = (t.pihak || '').toLowerCase().includes(q);
        const matchBukti = (t.nomorBukti || '').toLowerCase().includes(q);
        const matchKat = t.kategori.toLowerCase().includes(q);
        if (!matchUraian && !matchPihak && !matchBukti && !matchKat) {
          return false;
        }
      }
      return true;
    });
  }, [allRealDailyTransactions, dateFilterMode, selectedMonth, startDate, endDate, selectedDate, filterType, searchQuery]);

  // Statistics for selected period
  const periodStats = useMemo(() => {
    const txInPeriod = allRealDailyTransactions.filter(t => {
      if (dateFilterMode === 'month') {
        return t.tanggal && t.tanggal.startsWith(selectedMonth);
      } else if (dateFilterMode === 'range') {
        if (startDate && t.tanggal < startDate) return false;
        if (endDate && t.tanggal > endDate) return false;
        return true;
      } else if (dateFilterMode === 'single') {
        return t.tanggal === selectedDate;
      }
      return true; // 'all'
    });

    let totalMasuk = 0;
    let totalKeluar = 0;

    txInPeriod.forEach(t => {
      totalMasuk += t.pemasukan || 0;
      totalKeluar += t.pengeluaran || 0;
    });

    return {
      totalMasuk,
      totalKeluar,
      netCashflow: totalMasuk - totalKeluar,
      count: txInPeriod.length
    };
  }, [allRealDailyTransactions, dateFilterMode, selectedMonth, startDate, endDate, selectedDate]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-teal-900 via-emerald-800 to-slate-900 rounded-2xl p-5 sm:p-6 text-white shadow-xl border border-teal-700/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mt-4 -mr-4 w-40 h-40 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="bg-emerald-500/20 text-emerald-300 text-xs px-2.5 py-1 rounded-full font-mono font-bold border border-emerald-400/30 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                MODUL REAL-TIME BENDAHARA
              </span>
              <span className="bg-amber-400/20 text-amber-300 text-xs px-2.5 py-1 rounded-full font-bold border border-amber-400/30 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                Auto-Sync Riwayat Utama
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
              <Clock className="w-6 h-6 text-emerald-400" />
              Pencatatan Transaksi Harian Real
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100/90 max-w-2xl">
              Catat transaksi masuk & keluar harian secara real-time. Setiap transaksi harian (Pemasukan & Pengeluaran) yang diinput di sini akan <strong className="text-amber-300">otomatis tersimpan & tercatat di Riwayat Transaksi Bendahara</strong> (khusus Saldo Awal dikelola terpisah sebagai penetapan memo & tidak di-sync ke riwayat transaksi operasional).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-print-laporan-harian"
              onClick={() => setShowPrintModal(true)}
              className="bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-bold px-4 py-2.5 rounded-xl text-xs sm:text-sm flex items-center gap-2 transition-all cursor-pointer shadow-lg hover:shadow-emerald-500/20 min-h-[44px]"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak Rekap Kas ({activePeriodLabel})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid Layout: Form Entry + Daily Summary & Transactions List */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Form Input Transaksi Real (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl shadow-md border border-slate-200 overflow-hidden">
            <div className="bg-gradient-to-r from-slate-900 to-emerald-950 px-5 py-4 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <PlusCircle className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-sm sm:text-base">Input Transaksi Real Baru</h3>
              </div>
              <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-mono px-2 py-0.5 rounded border border-emerald-500/30 font-bold">
                AUTO BKM/BKK
              </span>
            </div>

            <form onSubmit={handleSubmitRealTx} className="p-5 space-y-4">
              
              {/* Tanggal & Jenis Transaksi */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Tanggal Transaksi
                  </label>
                  <input
                    type="date"
                    value={tanggal}
                    onChange={(e) => setTanggal(e.target.value)}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 text-xs font-semibold focus:outline-none focus:border-emerald-500 focus:bg-white min-h-[40px]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Jenis Transaksi
                  </label>
                  <select
                    value={jenis}
                    onChange={(e) => setJenis(e.target.value as TransactionType)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 text-xs font-bold focus:outline-none focus:border-emerald-500 focus:bg-white min-h-[40px]"
                  >
                    <option value="Pemasukan">🟢 Pemasukan Kas (Di-sync ke Riwayat)</option>
                    <option value="Pengeluaran">🔴 Pengeluaran Kas (Di-sync ke Riwayat)</option>
                    <option value="Saldo Awal">🔵 Saldo Kas Awal</option>
                  </select>
                </div>
              </div>

              {/* Kategori & Nominal */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Kategori
                  </label>
                  <select
                    value={kategori}
                    onChange={(e) => setKategori(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 text-xs font-semibold focus:outline-none focus:border-emerald-500 focus:bg-white min-h-[40px]"
                  >
                    {availableCategories.map((cat, idx) => (
                      <option key={idx} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Nominal (Rp)
                  </label>
                  <input
                    type="text"
                    value={nominalStr}
                    onChange={(e) => {
                      const input = e.target.value;
                      if (jenis === 'Saldo Awal') {
                        const isNegative = input.startsWith('-');
                        const cleanDigits = input.replace(/\D/g, '');
                        if (!cleanDigits) {
                          setNominalStr(isNegative ? '-' : '');
                        } else {
                          const parsed = parseInt(cleanDigits, 10);
                          setNominalStr(isNegative ? `-${parsed.toLocaleString('id-ID')}` : parsed.toLocaleString('id-ID'));
                        }
                      } else {
                        const val = input.replace(/\D/g, '');
                        setNominalStr(val ? parseInt(val, 10).toLocaleString('id-ID') : '');
                      }
                    }}
                    placeholder={jenis === 'Saldo Awal' ? 'Contoh: 5.000.000 atau -1.500.000 (Defisit)' : 'Contoh: 150.000'}
                    required
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 font-mono text-xs font-bold focus:outline-none focus:border-emerald-500 focus:bg-white min-h-[40px]"
                  />
                </div>
              </div>

              {/* Pihak (Penyetor / Penerima) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {jenis === 'Pemasukan' ? 'Pihak Penyetor / Sumber Dana' : jenis === 'Pengeluaran' ? 'Penerima Uang / Toko / Vendor' : 'Penanggung Jawab / Sumber'}
                </label>
                <input
                  type="text"
                  value={pihak}
                  onChange={(e) => setPihak(e.target.value)}
                  placeholder={jenis === 'Pemasukan' ? 'Contoh: Siswa / Wali Murid / Koperasi' : 'Contoh: Toko ATK Sejahtera / Pak Budi'}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg px-3 py-2 text-slate-900 text-xs focus:outline-none focus:border-emerald-500 focus:bg-white min-h-[40px]"
                />
              </div>

              {/* Uraian Transaksi Real */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Uraian / Keterangan Transaksi Real <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={2}
                  value={uraian}
                  onChange={(e) => setUraian(e.target.value)}
                  placeholder="Contoh: Pembelian spidol white board & kertas HVS A4 untuk ujian harian"
                  required
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-slate-900 text-xs focus:outline-none focus:border-emerald-500 focus:bg-white resize-none"
                />
              </div>

              {/* Metode Pembayaran */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Metode Pembayaran Kas
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Tunai / Kas', 'Transfer Bank', 'Cek / Giro'] as const).map((method) => (
                    <button
                      type="button"
                      key={method}
                      onClick={() => setMetodePembayaran(method)}
                      className={`py-2 px-2 text-[11px] font-bold rounded-lg border text-center transition-all cursor-pointer ${
                        metodePembayaran === method
                          ? 'bg-emerald-800 text-white border-emerald-800 shadow-xs'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              {/* Option: Disinkronkan dengan Dashboard & Transaksi */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <input
                    id="checkbox-daily-sync-dashboard"
                    type="checkbox"
                    checked={syncedToDashboard}
                    onChange={(e) => setSyncedToDashboard(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer"
                  />
                  <label htmlFor="checkbox-daily-sync-dashboard" className="text-xs font-bold text-slate-800 cursor-pointer select-none">
                    Disinkronkan dengan Dashboard &amp; Transaksi
                  </label>
                </div>
                <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                  syncedToDashboard 
                    ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                    : 'bg-amber-100 text-amber-800 border border-amber-300'
                }`}>
                  {syncedToDashboard ? 'Tersinkron Dashboard' : 'Hanya Kas Real'}
                </span>
              </div>

              {/* Informational Sync Notice */}
              <div className={`border rounded-xl p-3 text-xs flex items-start gap-2.5 ${
                !syncedToDashboard
                  ? 'bg-amber-50 border-amber-200 text-amber-900'
                  : jenis === 'Saldo Awal'
                    ? 'bg-blue-50 border-blue-200 text-blue-900'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}>
                <CheckCircle2 className={`w-4 h-4 shrink-0 mt-0.5 ${
                  !syncedToDashboard ? 'text-amber-600' : jenis === 'Saldo Awal' ? 'text-blue-600' : 'text-emerald-600'
                }`} />
                <p className="leading-snug text-[11px]">
                  {!syncedToDashboard ? (
                    <>
                      <strong>Hanya Dicatat di Kas Real:</strong> Transaksi ini tercatat pada Pantau Kas Real harian, tetapi <strong className="underline">TIDAK dimasukkan ke Dashboard Utama &amp; Riwayat Transaksi</strong>.
                    </>
                  ) : jenis === 'Saldo Awal' ? (
                    <>
                      <strong>Saldo Kas Awal Tersinkronasi:</strong> Transaksi Saldo Awal ini otomatis disimpan dan <strong className="text-blue-800">tersinkronasi penuh dengan Dashboard Utama &amp; Laporan Keuangan</strong>.
                    </>
                  ) : (
                    <>
                      <strong>Sistem Otomatis Tersinkronasi:</strong> Transaksi harian real ini langsung disimpan &amp; <strong className="text-emerald-800">otomatis tercatat di Dashboard Bendahara &amp; Laporan Rekap</strong>.
                    </>
                  )}
                </p>
              </div>

              {/* Submit Button & Additional Action */}
              <div className="space-y-2 pt-1">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer disabled:opacity-50 min-h-[44px]"
                >
                  <PlusCircle className="w-5 h-5" />
                  <span>
                    {isSubmitting 
                      ? 'Menyimpan...' 
                      : (syncedToDashboard ? 'Simpan Transaksi Real & Sync Ke Dashboard' : 'Simpan Harian Kas Real (Tanpa Sync)')
                    }
                  </span>
                </button>

                {onOpenNewTransaction && (
                  <button
                    type="button"
                    onClick={onOpenNewTransaction}
                    className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2.5 rounded-xl text-xs flex items-center justify-center gap-2 border border-slate-300 transition-colors cursor-pointer min-h-[40px]"
                  >
                    <PlusCircle className="w-4 h-4 text-emerald-600" />
                    <span>Form Catat Transaksi Lengkap</span>
                  </button>
                )}
              </div>

            </form>
          </div>
        </div>

        {/* Right Column: Date Selector + Daily Stats + Real Transactions Table (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Date Picker & Filter Toolbar */}
          <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-4 space-y-4">
            
            {/* Header & Mode Selector Tabs */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-emerald-700 shrink-0" />
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Periode Pantau Kas Real:
                </span>
              </div>

              {/* Mode Selector Buttons */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl overflow-x-auto">
                <button
                  type="button"
                  onClick={() => setDateFilterMode('month')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    dateFilterMode === 'month'
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  📅 Per Bulan
                </button>
                <button
                  type="button"
                  onClick={() => setDateFilterMode('range')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    dateFilterMode === 'range'
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  🗓️ Rentang Tanggal
                </button>
                <button
                  type="button"
                  onClick={() => setDateFilterMode('single')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    dateFilterMode === 'single'
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  📆 Per Tanggal
                </button>
                <button
                  type="button"
                  onClick={() => setDateFilterMode('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                    dateFilterMode === 'all'
                      ? 'bg-emerald-800 text-white shadow-xs'
                      : 'text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  🌐 Semua Tanggal
                </button>
              </div>
            </div>

            {/* Sub-controls according to active mode */}
            <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl">
              {dateFilterMode === 'month' && (
                <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                  <label className="text-xs font-bold text-slate-700 whitespace-nowrap">
                    Pilih Bulan Kas:
                  </label>
                  <select
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                    className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                  >
                    {monthOptions.map(m => (
                      <option key={m.value} value={m.value}>{m.label}</option>
                    ))}
                  </select>
                  <span className="text-[11px] text-slate-500 italic sm:ml-2">
                    Menampilkan seluruh transaksi harian real untuk bulan ini.
                  </span>
                </div>
              )}

              {dateFilterMode === 'range' && (
                <div className="flex flex-col sm:flex-row sm:items-center gap-3">
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-bold text-slate-700 whitespace-nowrap">Dari Tanggal:</label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                      className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="text-xs font-bold text-slate-700 whitespace-nowrap">Sampai Tanggal:</label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                      className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              )}

              {dateFilterMode === 'single' && (
                <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                  <label className="text-xs font-bold text-slate-700 whitespace-nowrap">Pilih Tanggal:</label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                    className="bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              )}

              {dateFilterMode === 'all' && (
                <div className="text-xs font-semibold text-slate-700 flex items-center gap-2">
                  <span className="bg-emerald-100 text-emerald-800 text-[11px] px-2 py-0.5 rounded font-bold">
                    Mode Semua Tanggal
                  </span>
                  <span>Menampilkan seluruh catatan transaksi harian real tanpa batasan tanggal.</span>
                </div>
              )}
            </div>

            {/* Summary Stats Cards for active period */}
            <div className="space-y-1">
              <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wide flex items-center gap-1.5">
                <span>Ringkasan Kas:</span>
                <span className="text-emerald-800 font-extrabold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  {activePeriodLabel}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
                <div className="bg-emerald-50/70 border border-emerald-200 p-2.5 rounded-xl">
                  <div className="text-[10px] font-bold text-emerald-800 uppercase flex items-center gap-1">
                    <ArrowDownRight className="w-3.5 h-3.5 text-emerald-600" />
                    Pemasukan Real
                  </div>
                  <div className="text-sm font-bold font-mono text-emerald-900 mt-1">
                    {formatRupiah(periodStats.totalMasuk)}
                  </div>
                </div>

                <div className="bg-rose-50/70 border border-rose-200 p-2.5 rounded-xl">
                  <div className="text-[10px] font-bold text-rose-800 uppercase flex items-center gap-1">
                    <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
                    Pengeluaran Real
                  </div>
                  <div className="text-sm font-bold font-mono text-rose-900 mt-1">
                    {formatRupiah(periodStats.totalKeluar)}
                  </div>
                </div>

                <div className="bg-teal-50/70 border border-teal-200 p-2.5 rounded-xl">
                  <div className="text-[10px] font-bold text-teal-800 uppercase flex items-center gap-1">
                    <Wallet className="w-3.5 h-3.5 text-teal-600" />
                    Net Kas Periode
                  </div>
                  <div className={`text-sm font-bold font-mono mt-1 ${periodStats.netCashflow >= 0 ? 'text-teal-900' : 'text-red-700'}`}>
                    {formatRupiah(periodStats.netCashflow)}
                  </div>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-2.5 rounded-xl">
                  <div className="text-[10px] font-bold text-slate-600 uppercase flex items-center gap-1">
                    <FileText className="w-3.5 h-3.5 text-slate-500" />
                    Jumlah Transaksi
                  </div>
                  <div className="text-sm font-bold font-mono text-slate-900 mt-1">
                    {periodStats.count} Item
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Search & Filter Toolbar */}
          <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-4 space-y-3">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari uraian / pihak / no. bukti..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-emerald-500 focus:bg-white"
                />
              </div>

              <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto">
                {['all', 'Pemasukan', 'Pengeluaran', 'Saldo Awal'].map((type) => (
                  <button
                    key={type}
                    onClick={() => setFilterType(type)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                      filterType === type
                        ? 'bg-emerald-800 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {type === 'all' ? 'Semua Jenis' : type}
                  </button>
                ))}
              </div>
            </div>

            {/* Transactions Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-800 text-white font-bold uppercase tracking-wider text-[11px]">
                    <th className="p-2.5 text-center w-10">No</th>
                    <th className="p-2.5 whitespace-nowrap">Tanggal</th>
                    <th className="p-2.5">Uraian Transaksi Real</th>
                    <th className="p-2.5 whitespace-nowrap">Pihak</th>
                    <th className="p-2.5 text-right whitespace-nowrap">Nominal</th>
                    <th className="p-2.5 text-center whitespace-nowrap">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 bg-white">
                  {filteredTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-500 font-medium">
                        <FileText className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                        <p>Tidak ada transaksi harian real ditemukan untuk kriteria ini.</p>
                        <p className="text-[11px] text-slate-400 mt-1">Gunakan form di sebelah kiri untuk menambah transaksi real baru.</p>
                      </td>
                    </tr>
                  ) : (
                    filteredTransactions.map((tx, idx) => {
                      const isMasuk = tx.jenis === 'Pemasukan' || tx.jenis === 'Saldo Awal';
                      const nominal = isMasuk ? tx.pemasukan : tx.pengeluaran;

                      return (
                        <tr key={tx.id} className="hover:bg-slate-50/80 transition-colors">
                          <td className="p-2.5 text-center font-mono text-slate-500 font-semibold">{idx + 1}</td>
                          <td className="p-2.5 whitespace-nowrap text-slate-600 font-medium text-[11px]">
                            {tx.tanggal}
                          </td>
                          <td className="p-2.5">
                            <div className="font-bold text-slate-900 leading-snug">{tx.uraian}</div>
                            <div className="flex items-center gap-2 mt-0.5">
                              <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded border ${
                                tx.jenis === 'Pemasukan' 
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                                  : tx.jenis === 'Pengeluaran'
                                    ? 'bg-rose-50 text-rose-800 border-rose-200'
                                    : 'bg-blue-50 text-blue-800 border-blue-200'
                              }`}>
                                {tx.jenis} - {tx.kategori}
                              </span>
                              {tx.syncedToDashboard === false ? (
                                <span className="text-[10px] bg-amber-100 text-amber-900 border border-amber-300 font-bold px-1.5 py-0.2 rounded">
                                  Hanya Kas Real
                                </span>
                              ) : (
                                <span className="text-[10px] bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold px-1.5 py-0.2 rounded">
                                  Tersinkron Dashboard
                                </span>
                              )}
                              {tx.metodePembayaran && (
                                <span className="text-[10px] text-slate-500 font-mono">
                                  [{tx.metodePembayaran}]
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-2.5 whitespace-nowrap text-slate-700 font-semibold text-[11px]">
                            {tx.pihak || '-'}
                          </td>
                          <td className="p-2.5 text-right whitespace-nowrap">
                            <span className={`font-mono font-bold text-xs ${
                              isMasuk ? 'text-emerald-700' : 'text-rose-700'
                            }`}>
                              {isMasuk ? '+' : '-'}{formatRupiah(nominal)}
                            </span>
                          </td>
                          <td className="p-2.5 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center space-x-1">
                              <button
                                onClick={() => onSelectKwitansi(tx)}
                                title="Cetak Kwitansi / Memo"
                                className="bg-slate-100 hover:bg-emerald-50 text-emerald-800 border border-slate-200 p-1.5 rounded-lg text-xs transition-colors cursor-pointer"
                              >
                                <Printer className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => setEditingTx(tx)}
                                title="Edit Transaksi"
                                className="bg-slate-100 hover:bg-amber-50 text-amber-800 border border-slate-200 p-1.5 rounded-lg text-xs transition-colors cursor-pointer"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => {
                                  if (window.confirm(`Hapus transaksi "${tx.uraian}"? Transaksi ini akan terhapus dari riwayat & dashboard.`)) {
                                    onDeleteTransaction(tx.id);
                                  }
                                }}
                                title="Hapus Transaksi"
                                className="bg-slate-100 hover:bg-rose-50 text-rose-700 border border-slate-200 p-1.5 rounded-lg text-xs transition-colors cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

          </div>

        </div>

      </div>

      {/* Modal Cetak Rekap Kas Real */}
      {showPrintModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto no-print-bg">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-300 w-full max-w-3xl overflow-hidden my-8">
            {/* Modal Header */}
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between no-print">
              <div className="flex items-center space-x-2">
                <Printer className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base">Cetak Rekap Kas Real ({activePeriodLabel})</h3>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => window.print()}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-lg text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                >
                  <Printer className="w-4 h-4" />
                  <span>Cetak Dokumen</span>
                </button>
                <button
                  onClick={() => setShowPrintModal(false)}
                  className="text-slate-400 hover:text-white p-1 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Content */}
            <div className="p-8 text-slate-900 space-y-6 printable-document">
              
              {/* Kop Sekolah */}
              <div className="text-center border-b-2 border-slate-900 pb-4">
                <h2 className="text-xl font-black uppercase tracking-wider text-slate-900">
                  {schoolProfile.namaSekolah || 'SMK NEGERI 1 JAKARTA'}
                </h2>
                <p className="text-xs text-slate-700 font-medium">
                  {schoolProfile.alamat} - Telp: {schoolProfile.telepon || '-'} | Email: {schoolProfile.email || '-'}
                </p>
                <div className="inline-block mt-3 bg-slate-100 border border-slate-300 px-4 py-1 rounded-full font-mono text-xs font-bold uppercase tracking-widest text-slate-800">
                  LAPORAN REKAP KAS REAL BENDAHARA
                </div>
              </div>

              {/* Info Tanggal & Ringkasan */}
              <div className="flex flex-col sm:flex-row justify-between text-xs font-semibold bg-slate-50 p-4 rounded-xl border border-slate-200 gap-2">
                <div>
                  <p className="text-slate-500 uppercase text-[10px]">Periode Laporan Kas Real:</p>
                  <p className="text-slate-900 font-bold text-sm">{activePeriodLabel}</p>
                </div>
                <div className="text-right">
                  <p className="text-slate-500 uppercase text-[10px]">Total Mutasi Periode Ini:</p>
                  <p className="text-slate-900 font-mono font-bold text-xs">
                    Masuk: {formatRupiah(periodStats.totalMasuk)} | Keluar: {formatRupiah(periodStats.totalKeluar)}
                  </p>
                </div>
              </div>

              {/* Tabel Transaksi Real */}
              <table className="w-full text-left text-xs border-collapse border border-slate-300">
                <thead>
                  <tr className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                    <th className="p-2 border-r border-slate-300 text-center w-8">No</th>
                    <th className="p-2 border-r border-slate-300">Uraian Transaksi Real</th>
                    <th className="p-2 border-r border-slate-300 whitespace-nowrap">Pihak</th>
                    <th className="p-2 border-r border-slate-300 text-right whitespace-nowrap">Pemasukan</th>
                    <th className="p-2 text-right whitespace-nowrap">Pengeluaran</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-300">
                  {filteredTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-4 text-center text-slate-500 italic">
                        Tidak ada transaksi harian real pada periode ini.
                      </td>
                    </tr>
                  ) : (
                    filteredTransactions.map((tx, i) => (
                      <tr key={tx.id} className="border-b border-slate-200">
                        <td className="p-2 border-r border-slate-300 text-center font-mono">{i + 1}</td>
                        <td className="p-2 border-r border-slate-300">
                          <div>{tx.uraian}</div>
                          <div className="text-[10px] text-slate-500 font-mono">{tx.tanggal} - [{tx.jenis}]</div>
                        </td>
                        <td className="p-2 border-r border-slate-300">{tx.pihak || '-'}</td>
                        <td className="p-2 border-r border-slate-300 text-right font-mono font-bold text-emerald-800">
                          {tx.pemasukan > 0 ? formatRupiah(tx.pemasukan) : '-'}
                        </td>
                        <td className="p-2 text-right font-mono font-bold text-rose-800">
                          {tx.pengeluaran > 0 ? formatRupiah(tx.pengeluaran) : '-'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                <tfoot>
                  <tr className="bg-slate-100 font-bold border-t-2 border-slate-400">
                    <td colSpan={3} className="p-2 border-r border-slate-300 text-right uppercase">
                      Total Kas Periode:
                    </td>
                    <td className="p-2 border-r border-slate-300 text-right font-mono text-emerald-900">
                      {formatRupiah(periodStats.totalMasuk)}
                    </td>
                    <td className="p-2 text-right font-mono text-rose-900">
                      {formatRupiah(periodStats.totalKeluar)}
                    </td>
                  </tr>
                </tfoot>
              </table>

              {/* Tanda Tangan */}
              <div className="flex justify-between items-start pt-8 text-xs font-semibold text-slate-800 break-inside-avoid">
                <div className="text-left pl-2">
                  <p className="text-slate-600 mb-1">Mengetahui,</p>
                  <p className="font-bold text-slate-900">Kepala Sekolah</p>
                  <div className="h-16" />
                  <p className="font-bold underline text-slate-900">
                    {schoolProfile.kepalaSekolah || '...........................................'}
                  </p>
                  <p className="text-[10px] text-slate-600 font-mono">
                    NIP. {schoolProfile.nipKepalaSekolah || '--------------------'}
                  </p>
                </div>

                <div className="text-left pr-2">
                  <p className="text-slate-600 mb-1">{schoolProfile.kota || 'Jakarta'}, {formatDateIndonesian(getTodayStr())}</p>
                  <p className="font-bold text-slate-900">Bendahara Sekolah</p>
                  <div className="h-16" />
                  <p className="font-bold underline text-slate-900">
                    {schoolProfile.bendahara || '...........................................'}
                  </p>
                  <p className="text-[10px] text-slate-600 font-mono">
                    NIP. {schoolProfile.nipBendahara || '--------------------'}
                  </p>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* Edit Transaction Modal */}
      {editingTx && (
        <EditTransactionModal
          isOpen={!!editingTx}
          transaction={editingTx}
          categoryData={categoryData}
          onClose={() => setEditingTx(null)}
          onSave={(updatedTx) => {
            onEditTransaction(updatedTx);
            setEditingTx(null);
          }}
        />
      )}
    </div>
  );
};
