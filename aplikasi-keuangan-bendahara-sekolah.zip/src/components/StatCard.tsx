import React, { useState, useMemo, useEffect } from 'react';
import { 
  Wallet, 
  ArrowDownLeft, 
  ArrowUpRight, 
  Landmark, 
  CreditCard, 
  Eye, 
  EyeOff, 
  Calendar, 
  Layers, 
  Lock,
  LayoutGrid,
  Rows
} from 'lucide-react';
import { Transaction } from '../types';
import { formatRupiah, getMonthYearName } from '../utils/formatters';

interface StatCardProps {
  totalSaldo: number;
  totalPemasukan: number;
  totalPengeluaran: number;
  saldoTunai: number;
  saldoBank: number;
  transactions?: Transaction[];
}

export const StatCard: React.FC<StatCardProps> = ({
  totalSaldo: initialTotalSaldo,
  totalPemasukan: initialTotalPemasukan,
  totalPengeluaran: initialTotalPengeluaran,
  saldoTunai: initialSaldoTunai,
  saldoBank: initialSaldoBank,
  transactions = []
}) => {
  // Auto-hide state: default true (censored numbers)
  const [isHidden, setIsHidden] = useState<boolean>(true);

  // Panel visibility state (Total Saldo Running s/d Rekening Bank)
  const [isPanelHidden, setIsPanelHidden] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('stat_card_panel_hidden');
      return saved !== null ? saved === 'true' : true; // Default hidden as requested by user
    } catch {
      return true;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('stat_card_panel_hidden', String(isPanelHidden));
    } catch (e) {
      // ignore
    }
  }, [isPanelHidden]);

  // Period mode: 'keseluruhan' or 'per_bulan'
  const [periodMode, setPeriodMode] = useState<'keseluruhan' | 'per_bulan'>('keseluruhan');

  // Display layout mode: 'compact' (streamlined bar) or 'grid' (5 cards)
  const [displayLayout, setDisplayLayout] = useState<'compact' | 'grid'>(() => {
    try {
      const saved = localStorage.getItem('stat_card_layout');
      return saved === 'grid' ? 'grid' : 'compact';
    } catch {
      return 'compact';
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('stat_card_layout', displayLayout);
    } catch (e) {
      // ignore
    }
  }, [displayLayout]);

  // Available unique YYYY-MM periods from transactions
  const availablePeriods = useMemo(() => {
    const setP = new Set<string>();
    transactions.forEach(t => {
      if (t.tanggal && t.tanggal.length >= 7) {
        setP.add(t.tanggal.slice(0, 7));
      }
    });
    const currentP = new Date().toISOString().slice(0, 7);
    setP.add(currentP);
    return Array.from(setP).sort((a, b) => b.localeCompare(a));
  }, [transactions]);

  // Selected month for 'per_bulan' mode
  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    const currentP = new Date().toISOString().slice(0, 7);
    if (transactions.some(t => t.tanggal && t.tanggal.startsWith(currentP))) {
      return currentP;
    }
    return availablePeriods[0] || currentP;
  });

  // Calculate metrics based on period mode
  const { totalPemasukan, totalPengeluaran, totalSaldo, saldoTunai, saldoBank } = useMemo(() => {
    if (periodMode === 'keseluruhan' || !transactions || transactions.length === 0) {
      return {
        totalPemasukan: initialTotalPemasukan,
        totalPengeluaran: initialTotalPengeluaran,
        totalSaldo: initialTotalSaldo,
        saldoTunai: initialSaldoTunai,
        saldoBank: initialSaldoBank
      };
    }

    // Per Bulan calculation
    let masuk = 0;
    let keluar = 0;
    let tunai = 0;
    let bank = 0;

    const filtered = transactions.filter(t => t.tanggal && t.tanggal.startsWith(selectedMonth));
    filtered.forEach(t => {
      masuk += t.pemasukan || 0;
      keluar += t.pengeluaran || 0;

      const isCash = !t.metodePembayaran || t.metodePembayaran === 'Tunai / Kas';
      if (isCash) {
        tunai += (t.pemasukan || 0) - (t.pengeluaran || 0);
      } else {
        bank += (t.pemasukan || 0) - (t.pengeluaran || 0);
      }
    });

    return {
      totalPemasukan: masuk,
      totalPengeluaran: keluar,
      totalSaldo: masuk - keluar,
      saldoTunai: tunai,
      saldoBank: bank
    };
  }, [
    periodMode, 
    selectedMonth, 
    transactions, 
    initialTotalSaldo, 
    initialTotalPemasukan, 
    initialTotalPengeluaran, 
    initialSaldoTunai, 
    initialSaldoBank
  ]);

  const renderVal = (num: number, colorClass: string = 'text-slate-900') => {
    if (isHidden) {
      return (
        <span className="font-mono text-slate-400 select-none tracking-widest flex items-center gap-1">
          <span>••••••••</span>
          <Lock className="w-3.5 h-3.5 inline text-slate-300" />
        </span>
      );
    }
    return <span className={colorClass}>{formatRupiah(num)}</span>;
  };

  if (isPanelHidden) {
    return (
      <div className="mb-6 no-print">
        <div className="bg-white border border-slate-200 rounded-xl p-3 flex items-center justify-between shadow-2xs">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
            <Wallet className="w-4 h-4 text-emerald-600" />
            <span>Ringkasan Saldo Running s/d Rekening Bank (Disembunyikan)</span>
          </div>
          <button
            type="button"
            onClick={() => setIsPanelHidden(false)}
            className="text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Eye className="w-3.5 h-3.5 text-emerald-600" />
            <span>Tampilkan Ringkasan Saldo</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3 mb-6 no-print">
      
      {/* Controls Bar: Period Toggle, Layout Mode, Privacy Toggle & Panel Hide */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        
        {/* Left Side: Opsi Filter Ringkasan (Keseluruhan vs Per Bulan) */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-600 flex items-center gap-1.5 mr-1">
            <Layers className="w-3.5 h-3.5 text-emerald-600" />
            Tampilan Saldo:
          </span>

          <div className="inline-flex bg-slate-100 p-1 rounded-lg">
            <button
              type="button"
              onClick={() => setPeriodMode('keseluruhan')}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                periodMode === 'keseluruhan'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Keseluruhan
            </button>
            <button
              type="button"
              onClick={() => setPeriodMode('per_bulan')}
              className={`px-3 py-1 text-xs font-bold rounded-md transition-all cursor-pointer ${
                periodMode === 'per_bulan'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Per Bulan
            </button>
          </div>

          {/* Month Dropdown if 'per_bulan' */}
          {periodMode === 'per_bulan' && (
            <div className="flex items-center space-x-1.5 bg-emerald-50 border border-emerald-200 rounded-lg px-2.5 py-1">
              <Calendar className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <select
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="bg-transparent text-xs font-bold text-emerald-900 focus:outline-none cursor-pointer"
              >
                {availablePeriods.map(p => (
                  <option key={p} value={p}>
                    {getMonthYearName(p)}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Right Side: Layout Switcher, Hide / Show Numbers & Hide Panel Toggle */}
        <div className="flex flex-wrap items-center gap-2 self-end sm:self-auto">
          
          {/* Layout Mode Switcher */}
          <div className="inline-flex bg-slate-100 p-1 rounded-lg">
            <button
              type="button"
              onClick={() => setDisplayLayout('compact')}
              className={`px-2.5 py-1 text-xs font-bold rounded-md transition-all flex items-center gap-1 cursor-pointer ${
                displayLayout === 'compact'
                  ? 'bg-white text-slate-900 shadow-2xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Tampilan Ringkas / Hemat Tempat (1 Baris)"
            >
              <Rows className="w-3.5 h-3.5 text-emerald-600" />
              <span className="hidden md:inline">Ringkas</span>
            </button>
            <button
              type="button"
              onClick={() => setDisplayLayout('grid')}
              className={`px-2.5 py-1 text-xs font-bold rounded-md transition-all flex items-center gap-1 cursor-pointer ${
                displayLayout === 'grid'
                  ? 'bg-white text-slate-900 shadow-2xs border border-slate-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="Tampilan Kartu Lengkap (Grid 5 Kartu)"
            >
              <LayoutGrid className="w-3.5 h-3.5 text-blue-600" />
              <span className="hidden md:inline">Kartu</span>
            </button>
          </div>

          {isHidden && (
            <span className="text-[10px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full hidden lg:inline-flex items-center gap-1">
              <Lock className="w-3 h-3" />
              Sensor
            </span>
          )}

          <button
            type="button"
            onClick={() => setIsHidden(!isHidden)}
            className="text-xs font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs bg-white text-slate-700 hover:bg-slate-50 border-slate-300"
            title="Sensor Angka Transaksi"
          >
            {isHidden ? (
              <>
                <Eye className="w-4 h-4 text-emerald-600" />
                <span>Buka Sensor</span>
              </>
            ) : (
              <>
                <EyeOff className="w-4 h-4 text-rose-600" />
                <span>Sensor Angka</span>
              </>
            )}
          </button>

          {/* Hide Panel Button */}
          <button
            type="button"
            onClick={() => setIsPanelHidden(true)}
            className="text-xs font-bold px-3 py-1.5 rounded-lg border flex items-center gap-1.5 transition-all cursor-pointer shadow-2xs bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300"
            title="Sembunyikan Seluruh Ringkasan Saldo Running s/d Rekening Bank"
          >
            <EyeOff className="w-4 h-4 text-slate-500" />
            <span>Sembunyikan Panel</span>
          </button>
        </div>

      </div>

      {/* ========================================================= */}
      {/* 1. TAMPILAN RINGKAS (COMPACT SINGLE BAR - SPACE SAVING)    */}
      {/* ========================================================= */}
      {displayLayout === 'compact' && (
        <div id="stat-compact-bar" className="bg-white border border-slate-200 rounded-2xl p-3 sm:p-4 shadow-xs">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-center">
            
            {/* Primary Metric: Total Saldo Running */}
            <div className="md:col-span-4 bg-emerald-900 text-white rounded-xl p-3 flex items-center justify-between shadow-xs">
              <div>
                <span className="text-[10px] font-extrabold tracking-wider text-emerald-300 uppercase block">
                  TOTAL SALDO {periodMode === 'per_bulan' ? `(${getMonthYearName(selectedMonth).toUpperCase()})` : '(RUNNING)'}
                </span>
                <div className="text-lg sm:text-xl font-black font-mono mt-0.5">
                  {renderVal(totalSaldo, 'text-white')}
                </div>
              </div>
              <div className="p-2 bg-white/10 rounded-lg text-emerald-300 shrink-0 border border-white/15">
                <Wallet className="w-5 h-5" />
              </div>
            </div>

            {/* Breakdown Sub-Metrics Grid */}
            <div className="md:col-span-8 grid grid-cols-2 sm:grid-cols-4 gap-2 sm:gap-3">
              
              {/* Pemasukan */}
              <div className="bg-slate-50 border border-slate-200/80 p-2.5 rounded-xl hover:bg-slate-100/60 transition-all">
                <div className="flex items-center space-x-1.5 text-blue-700 font-bold text-[10px] uppercase">
                  <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Pemasukan</span>
                </div>
                <div className="text-xs sm:text-sm font-extrabold font-mono text-emerald-700 mt-1">
                  {renderVal(totalPemasukan, 'text-emerald-700')}
                </div>
              </div>

              {/* Pengeluaran */}
              <div className="bg-slate-50 border border-slate-200/80 p-2.5 rounded-xl hover:bg-slate-100/60 transition-all">
                <div className="flex items-center space-x-1.5 text-rose-700 font-bold text-[10px] uppercase">
                  <ArrowUpRight className="w-3.5 h-3.5 text-rose-600" />
                  <span>Pengeluaran</span>
                </div>
                <div className="text-xs sm:text-sm font-extrabold font-mono text-rose-700 mt-1">
                  {renderVal(totalPengeluaran, 'text-rose-700')}
                </div>
              </div>

              {/* Kas Tunai */}
              <div className="bg-amber-50/60 border border-amber-200/80 p-2.5 rounded-xl hover:bg-amber-50 transition-all">
                <div className="flex items-center space-x-1.5 text-amber-800 font-bold text-[10px] uppercase">
                  <CreditCard className="w-3.5 h-3.5 text-amber-600" />
                  <span>Kas Tunai</span>
                </div>
                <div className="text-xs sm:text-sm font-extrabold font-mono text-amber-900 mt-1">
                  {renderVal(saldoTunai, 'text-amber-900')}
                </div>
              </div>

              {/* Rekening Bank */}
              <div className="bg-purple-50/60 border border-purple-200/80 p-2.5 rounded-xl hover:bg-purple-50 transition-all">
                <div className="flex items-center space-x-1.5 text-purple-800 font-bold text-[10px] uppercase">
                  <Landmark className="w-3.5 h-3.5 text-purple-600" />
                  <span>Rekening Bank</span>
                </div>
                <div className="text-xs sm:text-sm font-extrabold font-mono text-purple-900 mt-1">
                  {renderVal(saldoBank, 'text-purple-900')}
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* 2. TAMPILAN KARTU GRID (5 KARTU INDIVIDUAL LENGKAP)       */}
      {/* ========================================================= */}
      {displayLayout === 'grid' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          
          {/* 1. Total Saldo Running */}
          <div id="stat-card-total-saldo" className="bg-white border border-slate-200 rounded-xl p-4 text-slate-900 shadow-xs relative overflow-hidden group hover:border-emerald-400 transition-all">
            <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-emerald-500/5 rounded-full blur-xl group-hover:bg-emerald-500/10 transition-all" />
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold tracking-wider text-emerald-700 uppercase block">
                  TOTAL SALDO {periodMode === 'per_bulan' ? `(${getMonthYearName(selectedMonth).toUpperCase()})` : '(RUNNING)'}
                </span>
                <h2 className="text-xl font-bold tracking-tight mt-1">
                  {renderVal(totalSaldo, 'text-slate-900')}
                </h2>
                <p className="text-[11px] text-slate-500 mt-1">
                  Pemasukan - Pengeluaran
                </p>
              </div>
              <div className="p-3 bg-emerald-50 rounded-xl text-emerald-700 border border-emerald-200 shrink-0">
                <Wallet className="w-6 h-6" />
              </div>
            </div>
          </div>

          {/* 2. Total Pemasukan */}
          <div id="stat-card-total-pemasukan" className="bg-white border border-slate-200 rounded-xl p-4 text-slate-900 shadow-xs relative overflow-hidden group hover:border-blue-400 transition-all">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold tracking-wider text-blue-700 uppercase block">
                  TOTAL PEMASUKAN
                </span>
                <h2 className="text-xl font-bold tracking-tight mt-1">
                  {renderVal(totalPemasukan, 'text-emerald-600')}
                </h2>
                <p className="text-[11px] text-slate-500 mt-1">
                  Dana BOS, SPP & Lainnya
                </p>
              </div>
              <div className="p-3 bg-blue-50 rounded-xl text-blue-700 border border-blue-200 shrink-0">
                <ArrowDownLeft className="w-6 h-6" />
              </div>
            </div>
          </div>

          {/* 3. Total Pengeluaran */}
          <div id="stat-card-total-pengeluaran" className="bg-white border border-slate-200 rounded-xl p-4 text-slate-900 shadow-xs relative overflow-hidden group hover:border-red-400 transition-all">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold tracking-wider text-red-700 uppercase block">
                  TOTAL PENGELUARAN
                </span>
                <h2 className="text-xl font-bold tracking-tight mt-1">
                  {renderVal(totalPengeluaran, 'text-red-600')}
                </h2>
                <p className="text-[11px] text-slate-500 mt-1">
                  Honor, ATK, Sarpras & Ops
                </p>
              </div>
              <div className="p-3 bg-red-50 rounded-xl text-red-700 border border-red-200 shrink-0">
                <ArrowUpRight className="w-6 h-6" />
              </div>
            </div>
          </div>

          {/* 4. Saldo Kas Tunai */}
          <div id="stat-card-kas-tunai" className="bg-white border border-slate-200 rounded-xl p-4 text-slate-900 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold tracking-wider text-amber-700 uppercase block">
                  KAS TUNAI (BENDAHARA)
                </span>
                <h2 className="text-lg font-bold tracking-tight mt-1">
                  {renderVal(saldoTunai, 'text-amber-600')}
                </h2>
                <p className="text-[11px] text-slate-500 mt-1">
                  Penerimaan Tunai
                </p>
              </div>
              <div className="p-2.5 bg-amber-50 rounded-xl text-amber-700 border border-amber-200 shrink-0">
                <CreditCard className="w-5 h-5" />
              </div>
            </div>
          </div>

          {/* 5. Saldo Rekening Bank */}
          <div id="stat-card-rekening-bank" className="bg-white border border-slate-200 rounded-xl p-4 text-slate-900 shadow-xs relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold tracking-wider text-purple-700 uppercase block">
                  REKENING BANK
                </span>
                <h2 className="text-lg font-bold tracking-tight mt-1">
                  {renderVal(saldoBank, 'text-purple-700')}
                </h2>
                <p className="text-[11px] text-slate-500 mt-1">
                  Transfer / Non-Tunai
                </p>
              </div>
              <div className="p-2.5 bg-purple-50 rounded-xl text-purple-700 border border-purple-200 shrink-0">
                <Landmark className="w-5 h-5" />
              </div>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
