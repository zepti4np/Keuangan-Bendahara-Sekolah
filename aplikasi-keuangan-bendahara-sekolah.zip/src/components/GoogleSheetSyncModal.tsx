import React, { useState, useEffect } from 'react';
import { 
  X, 
  FileSpreadsheet, 
  ExternalLink, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  LogOut, 
  Zap, 
  ShieldCheck,
  Database
} from 'lucide-react';
import { Transaction } from '../types';
import { 
  googleSignIn, 
  logoutGoogle, 
  initAuth, 
  getAccessToken 
} from '../services/firebaseAuth';
import { 
  syncAllTransactionsToSheet, 
  DEFAULT_SPREADSHEET_ID, 
  getSpreadsheetDetails 
} from '../services/googleSheets';
import { User } from 'firebase/auth';

interface GoogleSheetSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  autoSyncEnabled: boolean;
  setAutoSyncEnabled: (enabled: boolean) => void;
}

export const GoogleSheetSyncModal: React.FC<GoogleSheetSyncModalProps> = ({
  isOpen,
  onClose,
  transactions,
  autoSyncEnabled,
  setAutoSyncEnabled
}) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [sheetTitle, setSheetTitle] = useState<string | null>(null);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState<boolean>(false);

  useEffect(() => {
    if (!isOpen) return;
    const unsubscribe = initAuth(
      (u, t) => {
        setUser(u);
        setToken(t);
        fetchDetails(t);
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, [isOpen]);

  const fetchDetails = async (accToken: string) => {
    try {
      const info = await getSpreadsheetDetails(accToken, DEFAULT_SPREADSHEET_ID);
      setSheetTitle(info.title);
    } catch (err: any) {
      console.warn('Could not fetch sheet title', err);
    }
  };

  const handleLogin = async () => {
    setIsLoggingIn(true);
    setStatusMsg(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setToken(res.accessToken);
        setStatusMsg({ type: 'success', text: `Berhasil terhubung dengan Google (${res.user.email})` });
        fetchDetails(res.accessToken);
      }
    } catch (err: any) {
      setStatusMsg({ type: 'error', text: err.message || 'Gagal masuk dengan Google.' });
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    await logoutGoogle();
    setUser(null);
    setToken(null);
    setSheetTitle(null);
    setStatusMsg({ type: 'success', text: 'Berhasil keluar dari akun Google.' });
  };

  const handleSyncNow = async () => {
    const currentToken = token || getAccessToken();
    if (!currentToken) {
      setStatusMsg({ type: 'error', text: 'Silakan masuk dengan akun Google terlebih dahulu.' });
      return;
    }

    const confirmed = window.confirm(
      `Apakah Anda yakin ingin mengirim ${transactions.length} transaksi ke Google Spreadsheet?\n\nSpreadsheet Target: ${DEFAULT_SPREADSHEET_ID}`
    );
    if (!confirmed) return;

    setIsSyncing(true);
    setStatusMsg(null);

    try {
      const result = await syncAllTransactionsToSheet(currentToken, transactions, DEFAULT_SPREADSHEET_ID);
      setStatusMsg({
        type: 'success',
        text: `Sukses! Berhasil menyinkronkan ${result.count} data transaksi ke Spreadsheet "${result.title}".`
      });
    } catch (err: any) {
      setStatusMsg({
        type: 'error',
        text: err.message || 'Gagal menyinkronkan data ke Spreadsheet.'
      });
    } finally {
      setIsSyncing(false);
    }
  };

  if (!isOpen) return null;

  const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${DEFAULT_SPREADSHEET_ID}/edit`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 overflow-y-auto no-print font-sans">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-slate-900">
        
        {/* Header */}
        <div className="bg-slate-50 px-6 py-4 flex items-center justify-between border-b border-slate-200">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-xl bg-emerald-100 text-emerald-700 border border-emerald-200">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-slate-900 leading-tight">Integrasi Google Sheets</h3>
              <p className="text-xs text-slate-500">Sinkronkan data transaksi ke Google Spreadsheet secara langsung</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-200 cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">

          {/* Target Spreadsheet Info Box */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-xl p-4 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-emerald-900 flex items-center gap-1.5">
                <Database className="w-4 h-4 text-emerald-700" />
                Target Spreadsheet Bendahara
              </span>
              <a
                href={spreadsheetUrl}
                target="_blank"
                rel="noreferrer"
                className="text-emerald-700 hover:text-emerald-900 font-semibold flex items-center gap-1 underline cursor-pointer"
              >
                <span>Buka Spreadsheet</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
            <p className="text-slate-600 font-mono text-[11px] truncate bg-white p-2 rounded border border-emerald-200/80">
              ID: {DEFAULT_SPREADSHEET_ID}
            </p>
            {sheetTitle && (
              <p className="text-emerald-800 font-medium text-[11px]">
                Judul File: <span className="font-bold">{sheetTitle}</span>
              </p>
            )}
          </div>

          {/* Status Alert Banner */}
          {statusMsg && (
            <div
              className={`p-3.5 rounded-xl border text-xs flex items-start gap-2.5 ${
                statusMsg.type === 'success'
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                  : 'bg-red-50 border-red-300 text-red-800'
              }`}
            >
              {statusMsg.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              )}
              <span className="flex-1 font-medium">{statusMsg.text}</span>
            </div>
          )}

          {/* User Account Status */}
          {user ? (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || 'Google User'} className="w-10 h-10 rounded-full border border-slate-300" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-sm">
                    {(user.displayName || user.email || 'G')[0].toUpperCase()}
                  </div>
                )}
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{user.displayName || 'Akun Google Terhubung'}</h4>
                  <p className="text-[11px] text-slate-500 font-mono">{user.email}</p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="text-xs font-semibold text-slate-600 hover:text-red-600 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-white flex items-center gap-1 transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Keluar</span>
              </button>
            </div>
          ) : (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 text-center space-y-3">
              <div className="max-w-xs mx-auto text-xs text-slate-600">
                Masuk dengan Akun Google untuk mengizinkan aplikasi menyimpan & memperbarui data ke Google Spreadsheet.
              </div>

              {/* Official Material Sign-in with Google Button */}
              <button
                type="button"
                onClick={handleLogin}
                disabled={isLoggingIn}
                className="gsi-material-button mx-auto shadow-sm hover:shadow transition-all cursor-pointer disabled:opacity-50"
              >
                <div className="gsi-material-button-state"></div>
                <div className="gsi-material-button-content-wrapper">
                  <div className="gsi-material-button-icon">
                    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" style={{ display: 'block' }}>
                      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                    </svg>
                  </div>
                  <span className="gsi-material-button-contents">
                    {isLoggingIn ? 'Menghubungkan...' : 'Masuk dengan Google'}
                  </span>
                </div>
              </button>
            </div>
          )}

          {/* Auto-Sync Settings */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Zap className="w-5 h-5 text-amber-500" />
              <div>
                <span className="text-xs font-bold text-slate-900 block">Otomatis Ekspor Setiap Transaksi Baru</span>
                <span className="text-[11px] text-slate-500 block">Secara otomatis menambahkan entri baru ke Google Sheet saat Anda menyimpan transaksi</span>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                checked={autoSyncEnabled} 
                onChange={(e) => setAutoSyncEnabled(e.target.checked)}
                className="sr-only peer" 
              />
              <div className="w-11 h-6 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Manual Sync Button */}
          <div className="pt-2">
            <button
              id="btn-sync-all-to-sheets"
              onClick={handleSyncNow}
              disabled={isSyncing || !user}
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 shadow transition-all disabled:opacity-50 cursor-pointer"
            >
              {isSyncing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Mengirim Data ({transactions.length} Transaksi)...</span>
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4" />
                  <span>Kirim Semua Transaksi ({transactions.length}) ke Google Sheets</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-3 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <span className="flex items-center gap-1 text-slate-600 font-medium">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            Terhubung via Google Workspace API & OAuth
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>

      </div>
    </div>
  );
};
