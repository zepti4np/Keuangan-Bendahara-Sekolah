import React from 'react';
import { X, Printer, School, FileCheck, ArrowLeft, Scissors, FileText } from 'lucide-react';
import { SchoolProfile, Transaction } from '../types';
import { formatRupiah, terbilang, formatDateIndonesian } from '../utils/formatters';

interface KwitansiModalProps {
  transaction: Transaction | null;
  schoolProfile: SchoolProfile;
  onClose: () => void;
}

interface KwitansiCardProps {
  transaction: Transaction;
  schoolProfile: SchoolProfile;
  categoryLabel: string;
  copyNumber: number;
  isSchoolCopy: boolean;
  isBothCopies?: boolean;
}

const KwitansiSingleSheet: React.FC<KwitansiCardProps> = ({
  transaction,
  schoolProfile,
  categoryLabel,
  copyNumber,
  isSchoolCopy,
  isBothCopies = false,
}) => {
  const isSaldoAwal = transaction.jenis === 'Saldo Awal' || (transaction.nomorBukti && transaction.nomorBukti.startsWith('MEMO'));
  const isMasuk = transaction.jenis === 'Pemasukan' || transaction.jenis === 'Saldo Awal';
  const rawNominal = isMasuk ? transaction.pemasukan : transaction.pengeluaran;
  
  // Detect if Saldo Awal is negative/minus
  const isNegativeSaldoAwal = isSaldoAwal && (rawNominal < 0 || transaction.pemasukan < 0 || (transaction.pemasukan - transaction.pengeluaran < 0));
  const nominal = rawNominal;

  // Header Title & Number Label according to copy type (Sekolah vs Umum / Memo)
  let kwTitle = 'KWITANSI';
  let numberLabel = 'Nomor Kwitansi';

  if (isSaldoAwal) {
    kwTitle = isNegativeSaldoAwal ? 'MEMO PENETAPAN SALDO AWAL (DEFISIT)' : 'MEMO PENETAPAN SALDO AWAL';
    numberLabel = 'Nomor Memo';
  } else if (isSchoolCopy) {
    kwTitle = isMasuk ? 'BUKTI KAS MASUK (BKM)' : 'BUKTI KAS KELUAR (BKK)';
    numberLabel = isMasuk ? 'Nomor BKM' : 'Nomor BKK';
  }

  const rawNumber = transaction.nomorBukti || transaction.id;
  let numberValue = rawNumber;
  if (!isSaldoAwal && !isSchoolCopy) {
    numberValue = (rawNumber.startsWith('BKM') || rawNumber.startsWith('BKK')
      ? rawNumber.replace(/^BKM|^BKK/, 'KW')
      : `KW-${rawNumber}`);
  }

  // Terbilang calculation (If Saldo Awal is minus, add 'Defisit' prefix)
  let terbilangText = '';
  if (isNegativeSaldoAwal) {
    terbilangText = `Defisit ${terbilang(Math.abs(nominal))} Rupiah`;
  } else {
    terbilangText = `${terbilang(nominal)} Rupiah`;
  }

  return (
    <div className="bg-white p-4 sm:p-5 border border-slate-300 text-slate-900 rounded-xl font-serif shadow-2xs relative print:p-2.5 print:border-slate-800 print:rounded-none print:shadow-none break-inside-avoid print:break-inside-avoid kwitansi-card">
      {/* Category Badge Top Right */}
      <div className="absolute top-3 right-3 bg-slate-100 border border-slate-400 text-slate-800 font-sans font-bold text-[9px] sm:text-[10px] px-2 py-0.5 rounded tracking-wide uppercase print:top-2 print:right-2 print:text-[8px] print:px-1.5 print:py-0">
        Lembar {copyNumber}: {categoryLabel}
      </div>

      {/* Kop Surat Header (Logo & Nama Sekolah ONLY, NO Address) */}
      <div className="flex items-center space-x-3 border-b-2 border-slate-900 pb-2 mb-3 print:pb-1 print:mb-1.5 print:space-x-2">
        <div className="h-11 w-11 sm:h-12 sm:w-12 rounded-lg border border-slate-300 bg-slate-50 flex items-center justify-center p-1 shrink-0 overflow-hidden print:h-8 print:w-8 print:p-0.5">
          {schoolProfile.logoUrl ? (
            <img src={schoolProfile.logoUrl} alt="Logo" className="h-full w-full object-contain" />
          ) : (
            <School className="w-7 h-7 text-slate-700 print:w-5 print:h-5" />
          )}
        </div>
        <div>
          <h2 className="text-base sm:text-xl font-bold uppercase tracking-tight text-slate-900 m-0 leading-tight print:text-sm">
            {schoolProfile.namaSekolah || 'SMK NEGERI 1 JAKARTA'}
          </h2>
          <p className="text-[11px] font-sans font-semibold text-emerald-800 mt-0.5 print:text-[9px] print:mt-0">
            {isSaldoAwal ? 'Dokumen Internal Penetapan Saldo Awal' : 'Bukti Transaksi Keuangan Resmi'}
          </p>
        </div>
      </div>

      {/* Kwitansi Title & Number */}
      <div className="text-center mb-3 print:mb-1.5">
        <h3 className="text-sm sm:text-base font-bold underline uppercase text-slate-900 m-0 print:text-xs">
          {kwTitle}
        </h3>
        <p className="text-[11px] font-mono text-slate-700 mt-0.5 print:text-[10px] print:mt-0">
          {numberLabel}: <span className="font-bold">{numberValue}</span>
        </p>
      </div>

      {/* Table Content */}
      <table className="w-full text-xs font-sans mb-3 border-collapse print:text-[10px] print:mb-1.5">
        <tbody>
          {isSaldoAwal ? (
            <>
              <tr className="border-b border-slate-200">
                <td className="py-1 print:py-0.5 font-semibold text-slate-700 w-1/3">
                  Penanggung Jawab / Sumber
                </td>
                <td className="py-1 print:py-0.5 w-4 font-bold">:</td>
                <td className="py-1 print:py-0.5 font-bold text-slate-900">
                  {transaction.pihak || 'Bendahara Kas Sekolah'}
                </td>
              </tr>

              <tr className="border-b border-slate-200">
                <td className="py-1 print:py-0.5 font-semibold text-slate-700">Tanggal Penetapan</td>
                <td className="py-1 print:py-0.5 font-bold">:</td>
                <td className="py-1 print:py-0.5 font-bold text-slate-900">
                  {formatDateIndonesian(transaction.tanggal)}
                </td>
              </tr>

              <tr className="border-b border-slate-200">
                <td className="py-1 print:py-0.5 font-semibold text-slate-700">Jumlah Saldo Awal</td>
                <td className="py-1 print:py-0.5 font-bold">:</td>
                <td className="py-1 print:py-0.5">
                  <div className={`p-1.5 print:p-1 rounded text-xs print:text-[10px] italic font-serif font-bold ${
                    isNegativeSaldoAwal
                      ? 'bg-rose-50 border border-rose-300 text-red-600 print:text-red-600 font-extrabold'
                      : 'bg-slate-50 border border-slate-300 text-slate-900'
                  }`}>
                    {terbilangText}
                  </div>
                </td>
              </tr>

              <tr className="border-b border-slate-200">
                <td className="py-1 print:py-0.5 font-semibold text-slate-700">Maksud & Uraian Memo</td>
                <td className="py-1 print:py-0.5 font-bold">:</td>
                <td className="py-1 print:py-0.5">
                  <span className="font-bold text-emerald-800">
                    [{transaction.jenis}] - {transaction.kategori}
                  </span>
                  <div className="text-xs print:text-[10px] text-slate-800 mt-0.5 leading-snug">
                    {transaction.uraian}
                  </div>
                  {transaction.metodePembayaran && (
                    <div className="text-[10px] print:text-[9px] text-slate-500 font-mono mt-0.5">
                      Akun Kas / Rekening: {transaction.metodePembayaran}
                    </div>
                  )}
                </td>
              </tr>
            </>
          ) : (
            <>
              <tr className="border-b border-slate-200">
                <td className="py-1 print:py-0.5 font-semibold text-slate-700 w-1/3">
                  {isMasuk ? 'Sudah Terima Dari' : 'Dibayarkan Kepada'}
                </td>
                <td className="py-1 print:py-0.5 w-4 font-bold">:</td>
                <td className="py-1 print:py-0.5 font-bold text-slate-900">
                  {transaction.pihak || (isMasuk ? 'Penyetor' : 'Penerima')}
                </td>
              </tr>

              <tr className="border-b border-slate-200">
                <td className="py-1 print:py-0.5 font-semibold text-slate-700">Tanggal Transaksi</td>
                <td className="py-1 print:py-0.5 font-bold">:</td>
                <td className="py-1 print:py-0.5 font-bold text-slate-900">
                  {formatDateIndonesian(transaction.tanggal)}
                </td>
              </tr>

              <tr className="border-b border-slate-200">
                <td className="py-1 print:py-0.5 font-semibold text-slate-700">Uang Sejumlah</td>
                <td className="py-1 print:py-0.5 font-bold">:</td>
                <td className="py-1 print:py-0.5">
                  <div className="bg-slate-50 border border-slate-300 p-1.5 print:p-1 rounded text-xs print:text-[10px] italic font-serif font-bold text-slate-900">
                    {terbilangText}
                  </div>
                </td>
              </tr>

              <tr className="border-b border-slate-200">
                <td className="py-1 print:py-0.5 font-semibold text-slate-700">Untuk Pembayaran</td>
                <td className="py-1 print:py-0.5 font-bold">:</td>
                <td className="py-1 print:py-0.5">
                  <span className="font-bold text-emerald-800">
                    [{transaction.jenis}] - {transaction.kategori}
                  </span>
                  <div className="text-xs print:text-[10px] text-slate-800 mt-0.5 leading-snug">
                    {transaction.uraian}
                  </div>
                  {transaction.metodePembayaran && (
                    <div className="text-[10px] print:text-[9px] text-slate-500 font-mono mt-0.5">
                      Metode: {transaction.metodePembayaran}
                    </div>
                  )}
                </td>
              </tr>
            </>
          )}
        </tbody>
      </table>

      {/* Amount Badge */}
      <div className="mb-3 print:mb-1.5">
        <div className={`inline-block font-mono font-extrabold text-xs sm:text-sm print:text-xs px-3.5 py-1 print:px-2.5 print:py-0.5 rounded-lg border-2 shadow-2xs ${
          isNegativeSaldoAwal
            ? 'bg-rose-50 text-red-600 border-red-600 print:text-red-600 print:border-red-600'
            : 'bg-white text-slate-900 border-slate-900'
        }`}>
          {formatRupiah(nominal)}
        </div>
      </div>

      {/* 3 Signatures Table */}
      <div className="font-sans text-[11px] print:text-[9px] text-center text-slate-800 mt-3 print:mt-1.5">
        <div className="grid grid-cols-3 gap-2">
          
          <div className="text-center">
            <div className="inline-block text-left">
              <p className="text-[10px] print:text-[8px]">Mengetahui,</p>
              <p className="font-bold text-[10px] print:text-[8.5px]">Kepala Sekolah</p>
              <div className="h-10 sm:h-12 print:h-6" />
              <p className="font-bold underline text-[10px] print:text-[8.5px]">{schoolProfile.kepalaSekolah}</p>
              <p className="text-[9px] print:text-[7.5px] font-mono text-slate-600">
                NIP: {schoolProfile.nipKepalaSekolah || '-'}
              </p>
            </div>
          </div>

          <div className="text-center">
            <div className="inline-block text-left">
              <p className="text-[10px] print:text-[8px]">&nbsp;</p>
              <p className="font-bold text-[10px] print:text-[8.5px]">
                {isSaldoAwal ? 'Penanggung Jawab Kas' : (isMasuk ? 'Penyetor' : 'Penerima Uang')}
              </p>
              <div className="h-10 sm:h-12 print:h-6" />
              <p className="font-bold underline text-[10px] print:text-[8.5px]">
                ( {transaction.pihak || '........................'} )
              </p>
            </div>
          </div>

          <div className="text-center">
            <div className="inline-block text-left">
              <p className="text-[10px] print:text-[8px]">
                {schoolProfile.kota || schoolProfile.kotaProvinsi?.split(',')[0] || 'Jakarta'}, {formatDateIndonesian(transaction.tanggal)}
              </p>
              <p className="font-bold text-[10px] print:text-[8.5px]">Bendahara Sekolah</p>
              <div className="h-10 sm:h-12 print:h-6" />
              <p className="font-bold underline text-[10px] print:text-[8.5px]">{schoolProfile.bendahara}</p>
              <p className="text-[9px] print:text-[7.5px] font-mono text-slate-600">
                NIP: {schoolProfile.nipBendahara || '-'}
              </p>
            </div>
          </div>

        </div>
      </div>

      {/* Embedded Physical Receipt / Nota if available */}
      {transaction.buktiNotaUrl && (
        <div className="mt-3 pt-2.5 border-t-2 border-dashed border-slate-300 print:mt-2 print:pt-2 bg-slate-50/90 p-3 rounded-xl border border-slate-200 break-inside-avoid print:break-inside-avoid bukti-attachment-box">
          <div className="flex items-center justify-between font-sans text-xs print:text-[9px] text-slate-700 mb-1.5">
            <span className="font-bold flex items-center gap-1.5 text-emerald-800">
              📎 Lampiran Bukti Fisik Nota / Kwitansi / Struk Asli:
            </span>
            <span className="font-mono text-xs text-slate-500">{transaction.buktiNotaName || 'Nota_Terlampir'}</span>
          </div>
          {!transaction.buktiNotaUrl.startsWith('data:application/pdf') ? (
            <div className={`max-h-[480px] ${isBothCopies ? 'print:max-h-[220px]' : 'print:max-h-[380px]'} overflow-hidden flex justify-center bg-white border border-slate-300 p-2 rounded-xl shadow-sm break-inside-avoid print:break-inside-avoid`}>
              <img
                src={transaction.buktiNotaUrl}
                alt="Bukti Nota Asli"
                className={`max-h-[460px] ${isBothCopies ? 'print:max-h-[200px]' : 'print:max-h-[360px]'} w-auto max-w-full object-contain rounded-lg`}
              />
            </div>
          ) : (
            <div className="bg-white border border-slate-300 p-3 rounded-xl flex items-center gap-3">
              <FileText className="w-8 h-8 text-rose-600 shrink-0" />
              <div>
                <p className="font-bold text-xs text-slate-800">{transaction.buktiNotaName || 'Dokumen PDF'}</p>
                <a
                  href={transaction.buktiNotaUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs font-bold text-emerald-700 hover:underline"
                >
                  Buka/Unduh Dokumen PDF Bukti
                </a>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export const KwitansiModal: React.FC<KwitansiModalProps> = ({
  transaction,
  schoolProfile,
  onClose
}) => {
  const [printOption, setPrintOption] = React.useState<'both' | 'arsip' | 'umum'>('both');

  if (!transaction) return null;

  const isSaldoAwal = transaction.jenis === 'Saldo Awal' || (transaction.nomorBukti && transaction.nomorBukti.startsWith('MEMO'));

  React.useEffect(() => {
    document.title = isSaldoAwal
      ? `Memo_Saldo_Awal_${transaction?.nomorBukti || transaction?.id || 'Doc'}`
      : `Bukti_Kwitansi_${transaction?.nomorBukti || transaction?.id || 'Doc'}`;
    document.body.classList.add('has-kwitansi-open');
    return () => {
      document.title = 'Sistem Keuangan Sekolah';
      document.body.classList.remove('has-kwitansi-open');
    };
  }, [transaction, isSaldoAwal]);

  const handlePrintKwitansi = () => {
    const originalTitle = document.title;
    document.title = isSaldoAwal
      ? `Memo_Saldo_Awal_${transaction.nomorBukti || transaction.id}`
      : `Bukti_Kwitansi_${transaction.nomorBukti || transaction.id}`;
    window.print();
    setTimeout(() => {
      document.title = originalTitle;
    }, 1000);
  };

  const copy1Label = isSaldoAwal 
    ? 'UNTUK ARSIP SEKOLAH (MEMO INTERNAL)' 
    : 'UNTUK ARSIP SEKOLAH (BKM/BKK)';

  const copy2Label = isSaldoAwal 
    ? 'UNTUK DOKUMENTASI BENDAHARA / PENANGGUNG JAWAB' 
    : 'UNTUK PEMBAYAR / UMUM (KWITANSI)';

  const cutLineText = isSaldoAwal
    ? '---------------- POTONG DI SINI (LEMBAR 1: ARSIP SEKOLAH | LEMBAR 2: DOKUMENTASI BENDAHARA) ----------------'
    : '---------------- POTONG DI SINI (LEMBAR 1: ARSIP SEKOLAH | LEMBAR 2: PEMBAYAR / UMUM) ----------------';

  const modalTitle = isSaldoAwal ? 'Pratinjau Memo Bukti Saldo Awal' : 'Pratinjau Bukti Kwitansi';

  const optBothLabel = isSaldoAwal ? 'Arsip & Dokumentasi (2 Rangkap)' : 'Arsip & Umum (2 Rangkap)';
  const optArsipLabel = 'Arsip Sekolah Saja';
  const optUmumLabel = isSaldoAwal ? 'Dokumentasi Bendahara Saja' : 'Pembayar / Umum Saja';

  const printButtonText = printOption === 'both' 
    ? `Cetak 2 Rangkap (${isSaldoAwal ? 'Arsip & Dokumentasi' : 'Arsip & Umum'})` 
    : printOption === 'arsip' 
      ? 'Cetak 1 Rangkap (Arsip Saja)' 
      : `Cetak 1 Rangkap (${isSaldoAwal ? 'Dokumentasi Saja' : 'Umum Saja'})`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto no-print-bg">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden my-6 print:my-0 print:border-none print:shadow-none print:rounded-none print:p-0">
        
        {/* Modal Top Bar (Screen only) */}
        <div className="bg-slate-900 px-6 py-4 flex items-center justify-between text-white border-b border-slate-800 no-print">
          <div className="flex items-center space-x-2">
            <button
              id="btn-back-kwitansi-top"
              onClick={onClose}
              className="mr-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded-lg text-xs flex items-center gap-1 transition-all cursor-pointer border border-slate-700"
              title="Kembali ke Aplikasi"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Kembali</span>
            </button>
            <FileCheck className="w-5 h-5 text-emerald-400" />
            <h3 className="font-bold text-base text-white">{modalTitle}</h3>
          </div>
          <div className="flex items-center space-x-2">
            <button
              id="btn-print-kwitansi-modal"
              onClick={handlePrintKwitansi}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3.5 py-1.5 rounded-lg text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-sm"
            >
              <Printer className="w-4 h-4" />
              <span>{printButtonText}</span>
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 cursor-pointer"
              title="Tutup"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Area */}
        <div className="p-4 sm:p-6 bg-slate-100 space-y-4 print:p-0 print:bg-white print:space-y-1.5" id="printable-kwitansi">
          
          {/* LEMBAR 1: UNTUK ARSIP SEKOLAH */}
          {(printOption === 'both' || printOption === 'arsip') && (
            <KwitansiSingleSheet
              transaction={transaction}
              schoolProfile={schoolProfile}
              categoryLabel={copy1Label}
              copyNumber={1}
              isSchoolCopy={true}
              isBothCopies={printOption === 'both'}
            />
          )}

          {/* Dotted Cut Line Separator (Only if both) */}
          {printOption === 'both' && (
            <>
              <div className="flex items-center justify-center space-x-2 text-slate-400 my-3 text-xs font-mono font-bold tracking-widest no-print">
                <Scissors className="w-4 h-4 text-slate-500" />
                <span>{cutLineText}</span>
              </div>
              <div className="hidden print:block border-b border-dashed border-slate-400 my-1.5 text-center text-[8px] font-mono text-slate-500">
                {cutLineText}
              </div>
            </>
          )}

          {/* LEMBAR 2: UNTUK PEMBAYAR / UMUM / DOKUMENTASI */}
          {(printOption === 'both' || printOption === 'umum') && (
            <KwitansiSingleSheet
              transaction={transaction}
              schoolProfile={schoolProfile}
              categoryLabel={copy2Label}
              copyNumber={printOption === 'both' ? 2 : 1}
              isSchoolCopy={false}
              isBothCopies={printOption === 'both'}
            />
          )}

        </div>

        {/* Option Bar (Screen Only - Placed at Bottom) */}
        <div className="bg-slate-800 px-6 py-3 border-t border-slate-700 flex flex-wrap items-center justify-between gap-3 text-xs text-white no-print">
          <div className="font-semibold text-slate-300 flex items-center gap-1.5">
            <span>Pilihan Lembar Cetak:</span>
          </div>
          <div className="flex items-center space-x-1.5 bg-slate-900/80 p-1 rounded-xl border border-slate-700">
            <button
              id="opt-print-both"
              type="button"
              onClick={() => setPrintOption('both')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                printOption === 'both'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              {optBothLabel}
            </button>
            <button
              id="opt-print-arsip"
              type="button"
              onClick={() => setPrintOption('arsip')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                printOption === 'arsip'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              {optArsipLabel}
            </button>
            <button
              id="opt-print-umum"
              type="button"
              onClick={() => setPrintOption('umum')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
                printOption === 'umum'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              {optUmumLabel}
            </button>
          </div>
        </div>

        {/* Modal Bottom Footer (Screen Only) */}
        <div className="bg-slate-100 px-6 py-3.5 border-t border-slate-200 flex items-center justify-between no-print">
          <button
            id="btn-back-kwitansi-bottom"
            onClick={onClose}
            className="bg-slate-800 hover:bg-slate-700 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-sm transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali</span>
          </button>
          
          <button
            id="btn-print-kwitansi-modal-bottom"
            onClick={handlePrintKwitansi}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-xl text-xs flex items-center gap-2 cursor-pointer shadow-sm transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>{printButtonText}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
