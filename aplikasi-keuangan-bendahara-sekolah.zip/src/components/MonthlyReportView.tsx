import React, { useState, useMemo } from 'react';
import { Calendar, Printer, FileText, Wallet, ArrowDownLeft, ArrowUpRight, ArrowRightLeft, School, ChevronDown, ChevronUp, Layers, Filter, CheckSquare } from 'lucide-react';
import { SchoolProfile, Transaction } from '../types';
import { formatRupiah, getMonthYearName, formatDateIndonesian } from '../utils/formatters';

interface MonthlyReportViewProps {
  transactions: Transaction[];
  schoolProfile: SchoolProfile;
}

interface CategoryGroup {
  kategori: string;
  total: number;
  count: number;
  items: Transaction[];
}

export const MonthlyReportView: React.FC<MonthlyReportViewProps> = ({
  transactions,
  schoolProfile
}) => {
  // Extract all available periods from transactions
  const availablePeriods = useMemo(() => {
    const periodsSet = new Set<string>();
    transactions.forEach(t => {
      if (t.tanggal && t.tanggal.length >= 7) {
        periodsSet.add(t.tanggal.slice(0, 7));
      }
    });
    const currentP = new Date().toISOString().slice(0, 7);
    periodsSet.add(currentP);
    return Array.from(periodsSet).sort((a, b) => b.localeCompare(a));
  }, [transactions]);

  // Default period: current month or latest available period in transactions
  const defaultPeriod = useMemo(() => {
    const currentP = new Date().toISOString().slice(0, 7);
    if (transactions.some(t => t.tanggal && t.tanggal.startsWith(currentP))) {
      return currentP;
    }
    return availablePeriods[0] || currentP;
  }, [transactions, availablePeriods]);

  const [selectedPeriod, setSelectedPeriod] = useState<string>(defaultPeriod);
  const [showCategoryDetails, setShowCategoryDetails] = useState<boolean>(true);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  const toggleCategoryExpand = (catKey: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [catKey]: !prev[catKey]
    }));
  };

  // Filter transactions by selected month (YYYY-MM) or 'all'
  const reportData = useMemo(() => {
    let monthTxs: Transaction[] = [];
    if (selectedPeriod === 'all') {
      monthTxs = [...transactions];
    } else {
      monthTxs = transactions.filter(t => t.tanggal && t.tanggal.startsWith(selectedPeriod));
    }

    // Grouping by category with detailed transaction list
    const saldoAwalMap: Record<string, CategoryGroup> = {};
    const pemasukanMap: Record<string, CategoryGroup> = {};
    const pengeluaranMap: Record<string, CategoryGroup> = {};
    const mutasiMap: Record<string, CategoryGroup> = {};

    let totalSaldoAwal = 0;
    let totalPemasukan = 0;
    let totalPengeluaran = 0;

    // Sort transactions by date ASC
    const sortedTxs = [...monthTxs].sort((a, b) => (a.tanggal || '').localeCompare(b.tanggal || ''));

    sortedTxs.forEach(t => {
      const kat = t.kategori || 'Pengeluaran Lain-lain';

      if (t.jenis === 'Saldo Awal') {
        if (!saldoAwalMap[kat]) {
          saldoAwalMap[kat] = { kategori: kat, total: 0, count: 0, items: [] };
        }
        saldoAwalMap[kat].total += t.pemasukan;
        saldoAwalMap[kat].count += 1;
        saldoAwalMap[kat].items.push(t);
        totalSaldoAwal += t.pemasukan;
      } else if (t.jenis === 'Pemasukan') {
        if (!pemasukanMap[kat]) {
          pemasukanMap[kat] = { kategori: kat, total: 0, count: 0, items: [] };
        }
        pemasukanMap[kat].total += t.pemasukan;
        pemasukanMap[kat].count += 1;
        pemasukanMap[kat].items.push(t);
        totalPemasukan += t.pemasukan;
      } else if (t.jenis === 'Pengeluaran') {
        if (!pengeluaranMap[kat]) {
          pengeluaranMap[kat] = { kategori: kat, total: 0, count: 0, items: [] };
        }
        pengeluaranMap[kat].total += t.pengeluaran;
        pengeluaranMap[kat].count += 1;
        pengeluaranMap[kat].items.push(t);
        totalPengeluaran += t.pengeluaran;
      } else if (t.jenis === 'Mutasi Kas') {
        if (!mutasiMap[kat]) {
          mutasiMap[kat] = { kategori: kat, total: 0, count: 0, items: [] };
        }
        const amt = t.pemasukan > 0 ? t.pemasukan : t.pengeluaran;
        mutasiMap[kat].total += amt;
        mutasiMap[kat].count += 1;
        mutasiMap[kat].items.push(t);
      }
    });

    const saldoAwalList = Object.values(saldoAwalMap).sort((a, b) => b.total - a.total);
    const pemasukanList = Object.values(pemasukanMap).sort((a, b) => b.total - a.total);
    const pengeluaranList = Object.values(pengeluaranMap).sort((a, b) => b.total - a.total);
    const mutasiList = Object.values(mutasiMap).sort((a, b) => b.total - a.total);

    const saldoAkhir = totalSaldoAwal + totalPemasukan - totalPengeluaran;

    return {
      period: selectedPeriod,
      monthName: selectedPeriod === 'all' ? 'Semua Data Transaksi' : getMonthYearName(selectedPeriod),
      saldoAwalList,
      pemasukanList,
      pengeluaranList,
      mutasiList,
      totalSaldoAwal,
      totalPemasukan,
      totalPengeluaran,
      saldoAkhir,
      transactionCount: monthTxs.length
    };
  }, [transactions, selectedPeriod]);

  const handlePrint = () => {
    document.body.classList.add('has-landscape-print');
    const originalTitle = document.title;
    document.title = `Laporan_Keuangan_${reportData.monthName.replace(/\s+/g, '_')}_${selectedPeriod}`;
    window.print();
    setTimeout(() => {
      document.body.classList.remove('has-landscape-print');
      document.title = originalTitle;
    }, 1000);
  };

  return (
    <div className="space-y-6">
      
      {/* Month Filter & Control Panel (Screen Only) */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 text-slate-900 shadow-sm no-print space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h3 className="font-bold text-lg text-slate-900 flex items-center gap-2">
              <FileText className="w-5 h-5 text-emerald-600" />
              Laporan Rekapitulasi Kas & Rincian Kategori
            </h3>
            <p className="text-xs text-slate-500">
              Menampilkan rekap keuangan bulanan serta rincian item per kategori (termasuk hasil impor data Excel)
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Period Selector Dropdown */}
            <div className="flex items-center space-x-2 bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5">
              <Calendar className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="text-xs text-slate-600 font-medium whitespace-nowrap">Periode Laporan:</span>
              <select
                id="select-periode-laporan"
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value)}
                className="bg-transparent text-sm text-slate-900 font-bold focus:outline-none cursor-pointer pr-1"
              >
                <option value="all">Semua Bulan ({transactions.length} Data Transaksi)</option>
                {availablePeriods.map(p => (
                  <option key={p} value={p}>
                    {getMonthYearName(p)}
                  </option>
                ))}
              </select>
            </div>

            {/* Toggle Rincian Kategori */}
            <button
              type="button"
              onClick={() => setShowCategoryDetails(!showCategoryDetails)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold border flex items-center gap-1.5 transition-all cursor-pointer ${
                showCategoryDetails
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300 shadow-xs'
                  : 'bg-slate-50 text-slate-700 border-slate-300 hover:bg-slate-100'
              }`}
            >
              <CheckSquare className={`w-4 h-4 ${showCategoryDetails ? 'text-emerald-600' : 'text-slate-400'}`} />
              <span>Rincian Item Kategori: {showCategoryDetails ? 'Aktif' : 'Sembunyi'}</span>
            </button>

            {/* Print Button */}
            <button
              id="btn-cetak-laporan"
              onClick={handlePrint}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2 rounded-lg text-sm flex items-center space-x-2 shadow-sm transition-all active:scale-95 cursor-pointer ml-auto md:ml-0"
            >
              <Printer className="w-4 h-4" />
              <span>Cetak / PDF Laporan</span>
            </button>
          </div>
        </div>

        {/* Quick Month Shortcuts if current selected has 0 transactions */}
        {reportData.transactionCount === 0 && (
          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-900 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Tidak ada data transaksi untuk bulan <strong>{reportData.monthName}</strong>. Pilih periode berikut yang memiliki data impor:</span>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              {availablePeriods.slice(0, 5).map(p => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setSelectedPeriod(p)}
                  className="px-2.5 py-1 bg-white border border-amber-300 text-amber-900 rounded font-semibold text-[11px] hover:bg-amber-100 transition-all cursor-pointer"
                >
                  {getMonthYearName(p)}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Printable Report Document Container */}
      <div className="bg-white text-slate-900 rounded-xl p-6 sm:p-10 shadow-2xl border border-slate-200 print:p-0 print:border-none print:shadow-none print:bg-white print:text-black font-sans">
        
        {/* Kop Surat Header */}
        <div className="border-b-2 border-slate-900 pb-4 mb-6 flex items-center justify-between gap-4">
          <div className="w-14 h-14 sm:w-16 sm:h-16 shrink-0 flex items-center justify-center">
            {schoolProfile.logoUrl ? (
              <img src={schoolProfile.logoUrl} alt="Logo Sekolah" className="max-h-full max-w-full object-contain" />
            ) : (
              <School className="w-10 h-10 sm:w-12 sm:h-12 text-emerald-800 print:text-black" />
            )}
          </div>
          <div className="flex-1 text-center">
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 uppercase leading-tight">
              {schoolProfile.namaSekolah || 'SMK NEGERI 1 JAKARTA'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 font-medium mt-0.5">
              {schoolProfile.alamat} | Telp: {schoolProfile.telepon || '-'}
            </p>
            <p className="text-xs text-slate-500 font-mono">
              Email: {schoolProfile.email || '-'}
            </p>
          </div>
          <div className="w-14 h-14 sm:w-16 sm:h-16 shrink-0 hidden sm:flex items-center justify-center opacity-0 print:opacity-0 pointer-events-none">
            {/* Balancer to keep title centered */}
            <School className="w-10 h-10" />
          </div>
        </div>

        {/* Report Title */}
        <div className="text-center mb-6">
          <h2 className="text-lg sm:text-xl font-bold uppercase tracking-wide text-slate-900">
            LAPORAN REKAPITULASI KEUANGAN KAS BENDAHARA
          </h2>
          <p className="text-sm font-semibold text-emerald-800 print:text-black mt-0.5">
            PERIODE: {reportData.monthName.toUpperCase()}
          </p>
          <p className="text-xs text-slate-500 mt-0.5 font-medium">
            Total {reportData.transactionCount} Transaksi Tercatat
          </p>
        </div>

        {/* Report Tables Breakdown */}
        <div className="space-y-6">
          
          {/* 1. SALDO AWAL */}
          <div className="border border-slate-300 rounded-lg overflow-hidden">
            <div className="bg-blue-800 text-white px-4 py-2 font-bold text-sm flex items-center justify-between">
              <span className="flex items-center gap-2">
                <Wallet className="w-4 h-4" />
                I. SALDO AWAL BULAN
              </span>
              <span className="font-mono">{formatRupiah(reportData.totalSaldoAwal)}</span>
            </div>

            {reportData.saldoAwalList.length === 0 ? (
              <div className="p-4 text-center text-slate-500 italic text-xs">
                Tidak ada data saldo awal tercatat untuk periode ini
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {reportData.saldoAwalList.map((catGroup, idx) => {
                  const catKey = `saldo_${catGroup.kategori}`;
                  const isExpanded = expandedCategories[catKey] ?? showCategoryDetails;

                  return (
                    <div key={idx} className="bg-white">
                      {/* Category Header Row */}
                      <div
                        onClick={() => toggleCategoryExpand(catKey)}
                        className="px-4 py-2.5 bg-blue-50/50 hover:bg-blue-100/50 flex items-center justify-between cursor-pointer border-b border-slate-200"
                      >
                        <div className="flex items-center gap-2">
                          <Layers className="w-3.5 h-3.5 text-blue-700" />
                          <span className="font-bold text-slate-900 text-sm">{catGroup.kategori}</span>
                          <span className="text-xs text-blue-800 bg-blue-100 font-semibold px-2 py-0.5 rounded-full">
                            {catGroup.count} transaksi
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-slate-900 text-sm">
                            {formatRupiah(catGroup.total)}
                          </span>
                          <span className="no-print text-slate-400">
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </span>
                        </div>
                      </div>

                      {/* Items Sub-table */}
                      <div className={`p-2 bg-slate-50/70 border-b border-slate-200 overflow-x-auto ${isExpanded ? 'block' : 'hidden print:block'}`}>
                        <table className="w-full text-xs text-left text-slate-800 border border-slate-200 rounded overflow-hidden">
                          <thead className="bg-slate-100 text-slate-700 font-semibold uppercase text-[10px] tracking-wider">
                            <tr>
                              <th className="px-2.5 py-1.5 w-8 text-center">No</th>
                              <th className="px-2.5 py-1.5">Tanggal</th>
                              <th className="px-2.5 py-1.5">No. Bukti</th>
                              <th className="px-2.5 py-1.5">Uraian / Keterangan</th>
                              <th className="px-2.5 py-1.5">Pihak Terkait</th>
                              <th className="px-2.5 py-1.5 text-right">Nominal</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 bg-white">
                            {catGroup.items.map((item, itemIdx) => (
                              <tr key={item.id || itemIdx} className="hover:bg-slate-50">
                                <td className="px-2.5 py-1 text-center font-mono text-slate-500">{itemIdx + 1}</td>
                                <td className="px-2.5 py-1 whitespace-nowrap">{formatDateIndonesian(item.tanggal)}</td>
                                <td className="px-2.5 py-1 font-mono text-[11px] text-slate-600 whitespace-nowrap">{item.nomorBukti || '-'}</td>
                                <td className="px-2.5 py-1 font-medium">{item.uraian}</td>
                                <td className="px-2.5 py-1 text-slate-600">{item.pihak || '-'}</td>
                                <td className="px-2.5 py-1 text-right font-mono font-bold text-blue-900">{formatRupiah(item.pemasukan)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })}

                <div className="bg-slate-100 px-4 py-2.5 flex justify-between font-bold text-sm text-slate-900 border-t-2 border-slate-300">
                  <span>TOTAL SALDO AWAL</span>
                  <span className="font-mono text-blue-800 print:text-black">{formatRupiah(reportData.totalSaldoAwal)}</span>
                </div>
              </div>
            )}
          </div>

          {/* 2. PEMASUKAN */}
          <div className="border border-slate-300 rounded-lg overflow-hidden">
            <div className="bg-emerald-800 text-white px-4 py-2 font-bold text-sm flex items-center justify-between">
              <span className="flex items-center gap-2">
                <ArrowDownLeft className="w-4 h-4" />
                II. PEMASUKAN KAS (INCOME)
              </span>
              <span className="font-mono">{formatRupiah(reportData.totalPemasukan)}</span>
            </div>

            {reportData.pemasukanList.length === 0 ? (
              <div className="p-4 text-center text-slate-500 italic text-xs">
                Tidak ada rincian pemasukan tercatat untuk periode ini
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {reportData.pemasukanList.map((catGroup, idx) => {
                  const catKey = `pemasukan_${catGroup.kategori}`;
                  const isExpanded = expandedCategories[catKey] ?? showCategoryDetails;

                  return (
                    <div key={idx} className="bg-white">
                      {/* Category Header Row */}
                      <div
                        onClick={() => toggleCategoryExpand(catKey)}
                        className="px-4 py-2.5 bg-emerald-50/50 hover:bg-emerald-100/50 flex items-center justify-between cursor-pointer border-b border-slate-200"
                      >
                        <div className="flex items-center gap-2">
                          <Layers className="w-3.5 h-3.5 text-emerald-700" />
                          <span className="font-bold text-slate-900 text-sm">{catGroup.kategori}</span>
                          <span className="text-xs text-emerald-800 bg-emerald-100 font-semibold px-2 py-0.5 rounded-full">
                            {catGroup.count} transaksi
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-slate-900 text-sm">
                            {formatRupiah(catGroup.total)}
                          </span>
                          <span className="no-print text-slate-400">
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </span>
                        </div>
                      </div>

                      {/* Items Sub-table */}
                      <div className={`p-2 bg-slate-50/70 border-b border-slate-200 overflow-x-auto ${isExpanded ? 'block' : 'hidden print:block'}`}>
                        <table className="w-full text-xs text-left text-slate-800 border border-slate-200 rounded overflow-hidden">
                          <thead className="bg-slate-100 text-slate-700 font-semibold uppercase text-[10px] tracking-wider">
                            <tr>
                              <th className="px-2.5 py-1.5 w-8 text-center">No</th>
                              <th className="px-2.5 py-1.5">Tanggal</th>
                              <th className="px-2.5 py-1.5">No. Bukti</th>
                              <th className="px-2.5 py-1.5">Uraian / Keterangan</th>
                              <th className="px-2.5 py-1.5">Terima Dari</th>
                              <th className="px-2.5 py-1.5 text-right">Nominal</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 bg-white">
                            {catGroup.items.map((item, itemIdx) => (
                              <tr key={item.id || itemIdx} className="hover:bg-slate-50">
                                <td className="px-2.5 py-1 text-center font-mono text-slate-500">{itemIdx + 1}</td>
                                <td className="px-2.5 py-1 whitespace-nowrap">{formatDateIndonesian(item.tanggal)}</td>
                                <td className="px-2.5 py-1 font-mono text-[11px] text-slate-600 whitespace-nowrap">{item.nomorBukti || '-'}</td>
                                <td className="px-2.5 py-1 font-medium">{item.uraian}</td>
                                <td className="px-2.5 py-1 text-slate-600">{item.pihak || '-'}</td>
                                <td className="px-2.5 py-1 text-right font-mono font-bold text-emerald-800">{formatRupiah(item.pemasukan)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })}

                <div className="bg-slate-100 px-4 py-2.5 flex justify-between font-bold text-sm text-slate-900 border-t-2 border-slate-300">
                  <span>TOTAL PEMASUKAN</span>
                  <span className="font-mono text-emerald-800 print:text-black">{formatRupiah(reportData.totalPemasukan)}</span>
                </div>
              </div>
            )}
          </div>

          {/* 3. PENGELUARAN */}
          <div className="border border-slate-300 rounded-lg overflow-hidden">
            <div className="bg-red-800 text-white px-4 py-2 font-bold text-sm flex items-center justify-between">
              <span className="flex items-center gap-2">
                <ArrowUpRight className="w-4 h-4" />
                III. PENGELUARAN KAS (EXPENSE)
              </span>
              <span className="font-mono">{formatRupiah(reportData.totalPengeluaran)}</span>
            </div>

            {reportData.pengeluaranList.length === 0 ? (
              <div className="p-4 text-center text-slate-500 italic text-xs">
                Tidak ada rincian pengeluaran tercatat untuk periode ini
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {reportData.pengeluaranList.map((catGroup, idx) => {
                  const catKey = `pengeluaran_${catGroup.kategori}`;
                  const isExpanded = expandedCategories[catKey] ?? showCategoryDetails;

                  return (
                    <div key={idx} className="bg-white">
                      {/* Category Header Row */}
                      <div
                        onClick={() => toggleCategoryExpand(catKey)}
                        className="px-4 py-2.5 bg-red-50/50 hover:bg-red-100/50 flex items-center justify-between cursor-pointer border-b border-slate-200"
                      >
                        <div className="flex items-center gap-2">
                          <Layers className="w-3.5 h-3.5 text-red-700" />
                          <span className="font-bold text-slate-900 text-sm">{catGroup.kategori}</span>
                          <span className="text-xs text-red-800 bg-red-100 font-semibold px-2 py-0.5 rounded-full">
                            {catGroup.count} transaksi
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-slate-900 text-sm">
                            {formatRupiah(catGroup.total)}
                          </span>
                          <span className="no-print text-slate-400">
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </span>
                        </div>
                      </div>

                      {/* Items Sub-table */}
                      <div className={`p-2 bg-slate-50/70 border-b border-slate-200 overflow-x-auto ${isExpanded ? 'block' : 'hidden print:block'}`}>
                        <table className="w-full text-xs text-left text-slate-800 border border-slate-200 rounded overflow-hidden">
                          <thead className="bg-slate-100 text-slate-700 font-semibold uppercase text-[10px] tracking-wider">
                            <tr>
                              <th className="px-2.5 py-1.5 w-8 text-center">No</th>
                              <th className="px-2.5 py-1.5">Tanggal</th>
                              <th className="px-2.5 py-1.5">No. Bukti</th>
                              <th className="px-2.5 py-1.5">Uraian / Belanja</th>
                              <th className="px-2.5 py-1.5">Dibayarkan Kepada</th>
                              <th className="px-2.5 py-1.5 text-right">Nominal</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 bg-white">
                            {catGroup.items.map((item, itemIdx) => (
                              <tr key={item.id || itemIdx} className="hover:bg-slate-50">
                                <td className="px-2.5 py-1 text-center font-mono text-slate-500">{itemIdx + 1}</td>
                                <td className="px-2.5 py-1 whitespace-nowrap">{formatDateIndonesian(item.tanggal)}</td>
                                <td className="px-2.5 py-1 font-mono text-[11px] text-slate-600 whitespace-nowrap">{item.nomorBukti || '-'}</td>
                                <td className="px-2.5 py-1 font-medium">{item.uraian}</td>
                                <td className="px-2.5 py-1 text-slate-600">{item.pihak || '-'}</td>
                                <td className="px-2.5 py-1 text-right font-mono font-bold text-red-800">{formatRupiah(item.pengeluaran)}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })}

                <div className="bg-slate-100 px-4 py-2.5 flex justify-between font-bold text-sm text-slate-900 border-t-2 border-slate-300">
                  <span>TOTAL PENGELUARAN</span>
                  <span className="font-mono text-red-800 print:text-black">{formatRupiah(reportData.totalPengeluaran)}</span>
                </div>
              </div>
            )}
          </div>

          {/* 4. MUTASI KAS (If Any) */}
          {reportData.mutasiList.length > 0 && (
            <div className="border border-slate-300 rounded-lg overflow-hidden">
              <div className="bg-amber-800 text-white px-4 py-2 font-bold text-sm flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <ArrowRightLeft className="w-4 h-4" />
                  IV. REKAP MUTASI KAS
                </span>
              </div>
              <div className="divide-y divide-slate-200">
                {reportData.mutasiList.map((catGroup, idx) => {
                  const catKey = `mutasi_${catGroup.kategori}`;
                  const isExpanded = expandedCategories[catKey] ?? showCategoryDetails;

                  return (
                    <div key={idx} className="bg-white">
                      <div
                        onClick={() => toggleCategoryExpand(catKey)}
                        className="px-4 py-2.5 bg-amber-50/50 hover:bg-amber-100/50 flex items-center justify-between cursor-pointer border-b border-slate-200"
                      >
                        <div className="flex items-center gap-2">
                          <Layers className="w-3.5 h-3.5 text-amber-700" />
                          <span className="font-bold text-slate-900 text-sm">{catGroup.kategori}</span>
                          <span className="text-xs text-amber-800 bg-amber-100 font-semibold px-2 py-0.5 rounded-full">
                            {catGroup.count} transaksi
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="font-mono font-bold text-slate-900 text-sm">
                            {formatRupiah(catGroup.total)}
                          </span>
                          <span className="no-print text-slate-400">
                            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                          </span>
                        </div>
                      </div>

                      <div className={`p-2 bg-slate-50/70 border-b border-slate-200 overflow-x-auto ${isExpanded ? 'block' : 'hidden print:block'}`}>
                        <table className="w-full text-xs text-left text-slate-800 border border-slate-200 rounded overflow-hidden">
                          <thead className="bg-slate-100 text-slate-700 font-semibold uppercase text-[10px] tracking-wider">
                            <tr>
                              <th className="px-2.5 py-1.5 w-8 text-center">No</th>
                              <th className="px-2.5 py-1.5">Tanggal</th>
                              <th className="px-2.5 py-1.5">No. Bukti</th>
                              <th className="px-2.5 py-1.5">Uraian / Keterangan</th>
                              <th className="px-2.5 py-1.5 text-right">Nominal</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 bg-white">
                            {catGroup.items.map((item, itemIdx) => (
                              <tr key={item.id || itemIdx} className="hover:bg-slate-50">
                                <td className="px-2.5 py-1 text-center font-mono text-slate-500">{itemIdx + 1}</td>
                                <td className="px-2.5 py-1 whitespace-nowrap">{formatDateIndonesian(item.tanggal)}</td>
                                <td className="px-2.5 py-1 font-mono text-[11px] text-slate-600 whitespace-nowrap">{item.nomorBukti || '-'}</td>
                                <td className="px-2.5 py-1 font-medium">{item.uraian}</td>
                                <td className="px-2.5 py-1 text-right font-mono font-bold text-amber-800">
                                  {formatRupiah(item.pemasukan > 0 ? item.pemasukan : item.pengeluaran)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 5. SALDO AKHIR BULAN INI */}
          <div className="bg-emerald-800 text-white rounded-lg p-5 flex flex-col sm:flex-row items-center justify-between border-2 border-emerald-900 print:bg-white print:text-black print:border-black shadow-sm">
            <div>
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-200 print:text-black">
                SALDO AKHIR PERIODE (ENDING BALANCE)
              </span>
              <p className="text-xs text-emerald-100/90 print:text-slate-700 mt-0.5">
                Rumus: (Total Saldo Awal + Total Pemasukan) - Total Pengeluaran
              </p>
            </div>
            <div className="mt-3 sm:mt-0 text-right">
              <span className="text-2xl sm:text-3xl font-black font-mono text-white print:text-black">
                {formatRupiah(reportData.saldoAkhir)}
              </span>
            </div>
          </div>
        </div>

        {/* Signatures Section */}
        <div className="mt-12 pt-6 border-t border-slate-300 break-inside-avoid">
          <div className="flex justify-between items-start text-sm">
            
            {/* Mengetahui Kepala Sekolah */}
            <div className="text-left pl-2">
              <p className="text-xs text-slate-600">Mengetahui,</p>
              <p className="font-bold text-slate-900">Kepala Sekolah</p>
              <div className="h-16" />
              <p className="font-bold underline text-slate-900">
                {schoolProfile.kepalaSekolah || '................................'}
              </p>
              <p className="text-xs text-slate-600 font-mono">
                NIP: {schoolProfile.nipKepalaSekolah || '-'}
              </p>
            </div>

            {/* Bendahara Sekolah */}
            <div className="text-left pr-2">
              <p className="text-xs text-slate-600">
                {schoolProfile.kota || schoolProfile.kotaProvinsi?.split(',')[0] || 'Jakarta'}, {formatDateIndonesian(new Date().toISOString().slice(0, 10))}
              </p>
              <p className="font-bold text-slate-900">Bendahara Sekolah</p>
              <div className="h-16" />
              <p className="font-bold underline text-slate-900">
                {schoolProfile.bendahara || '................................'}
              </p>
              <p className="text-xs text-slate-600 font-mono">
                NIP: {schoolProfile.nipBendahara || '-'}
              </p>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
