import React, { useState, useRef } from 'react';
import { X, Save, School, User, MapPin, Phone, Mail, Award, Download, Upload, Database, Image as ImageIcon, Trash2 } from 'lucide-react';
import { SchoolProfile } from '../types';

interface SettingsModalProps {
  schoolProfile: SchoolProfile;
  onSave: (updated: SchoolProfile) => void;
  onClose: () => void;
  onOpenBackupRestore?: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  schoolProfile,
  onSave,
  onClose,
  onOpenBackupRestore
}) => {
  const [formData, setFormData] = useState<SchoolProfile>(schoolProfile);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const logoYayasanInputRef = useRef<HTMLInputElement | null>(null);

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Ukuran file logo maksimal 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, logoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveLogo = () => {
    setFormData(prev => ({ ...prev, logoUrl: '' }));
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleLogoYayasanUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert('Ukuran file logo yayasan maksimal 2MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, logoYayasanUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveLogoYayasan = () => {
    setFormData(prev => ({ ...prev, logoYayasanUrl: '' }));
    if (logoYayasanInputRef.current) {
      logoYayasanInputRef.current.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs no-print">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col text-slate-900 my-auto overflow-hidden">
        
        {/* Sticky Header */}
        <div className="bg-slate-50 px-5 sm:px-6 py-3.5 flex items-center justify-between border-b border-slate-200 shrink-0">
          <div className="flex items-center space-x-2">
            <School className="w-5 h-5 text-emerald-600" />
            <h3 className="font-bold text-base sm:text-lg text-slate-900">Pengaturan Profil Sekolah & Pejabat</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 p-1.5 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
            title="Tutup"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Content */}
        <form id="form-settings-sekolah" onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          
          {/* Section 1: Identitas Sekolah */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-emerald-700 uppercase tracking-wider flex items-center gap-1.5">
              <School className="w-3.5 h-3.5 text-emerald-600" />
              <span>Identitas Sekolah / Instansi</span>
            </h4>

            {/* Upload Logo Sekolah & Yayasan */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Logo Sekolah */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Logo Sekolah / Instansi (Kanan Kop)
                </label>
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2.5">
                  <div className="flex items-center space-x-3">
                    <div className="h-12 w-12 rounded-xl bg-white border border-slate-300 flex items-center justify-center overflow-hidden shrink-0 shadow-2xs">
                      {formData.logoUrl ? (
                        <img src={formData.logoUrl} alt="Logo Sekolah" className="h-full w-full object-contain p-1" />
                      ) : (
                        <School className="w-6 h-6 text-emerald-600" />
                      )}
                    </div>

                    <div className="space-y-1 flex-1">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleLogoUpload}
                        className="hidden"
                        id="input-logo-sekolah-file"
                      />
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-2.5 py-1 rounded-lg text-xs flex items-center gap-1 cursor-pointer shadow-2xs transition-all"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>{formData.logoUrl ? 'Ganti' : 'Upload'}</span>
                        </button>

                        {formData.logoUrl && (
                          <button
                            type="button"
                            onClick={handleRemoveLogo}
                            className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 font-semibold px-2 py-1 rounded-lg text-xs flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div>
                    <input
                      id="input-logo-url-text"
                      type="text"
                      value={formData.logoUrl || ''}
                      onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
                      placeholder="URL logo sekolah (https://...)"
                      className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-[11px] text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* Logo Yayasan */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Logo Yayasan (Kiri Kop Surat Ortuba)
                </label>
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 space-y-2.5">
                  <div className="flex items-center space-x-3">
                    <div className="h-12 w-12 rounded-xl bg-white border border-slate-300 flex items-center justify-center overflow-hidden shrink-0 shadow-2xs">
                      {formData.logoYayasanUrl ? (
                        <img src={formData.logoYayasanUrl} alt="Logo Yayasan" className="h-full w-full object-contain p-1" />
                      ) : (
                        <School className="w-6 h-6 text-slate-700" />
                      )}
                    </div>

                    <div className="space-y-1 flex-1">
                      <input
                        ref={logoYayasanInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleLogoYayasanUpload}
                        className="hidden"
                        id="input-logo-yayasan-file"
                      />
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => logoYayasanInputRef.current?.click()}
                          className="bg-slate-800 hover:bg-slate-700 text-white font-bold px-2.5 py-1 rounded-lg text-xs flex items-center gap-1 cursor-pointer shadow-2xs transition-all"
                        >
                          <ImageIcon className="w-3.5 h-3.5" />
                          <span>{formData.logoYayasanUrl ? 'Ganti' : 'Upload'}</span>
                        </button>

                        {formData.logoYayasanUrl && (
                          <button
                            type="button"
                            onClick={handleRemoveLogoYayasan}
                            className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-300 font-semibold px-2 py-1 rounded-lg text-xs flex items-center gap-1 cursor-pointer transition-all"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  <div>
                    <input
                      id="input-logo-yayasan-url-text"
                      type="text"
                      value={formData.logoYayasanUrl || ''}
                      onChange={(e) => setFormData({ ...formData, logoYayasanUrl: e.target.value })}
                      placeholder="URL logo yayasan (https://...)"
                      className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-[11px] text-slate-900 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Nama & Alamat */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Sekolah / Instansi *</label>
                <input
                  id="input-nama-sekolah"
                  type="text"
                  value={formData.namaSekolah}
                  onChange={(e) => setFormData({ ...formData, namaSekolah: e.target.value })}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Alamat Lengkap *</label>
                <input
                  id="input-alamat-sekolah"
                  type="text"
                  value={formData.alamat}
                  onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Kota / Kabupaten */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Kota / Kabupaten (Titik Tanggal Kwitansi) *
                </label>
                <input
                  id="input-kota-sekolah"
                  type="text"
                  value={formData.kota || ''}
                  onChange={(e) => setFormData({ ...formData, kota: e.target.value })}
                  placeholder="Contoh: Jakarta Pusat, Ciamis"
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Kota & Provinsi Lengkap</label>
                <input
                  id="input-kota-provinsi-sekolah"
                  type="text"
                  value={formData.kotaProvinsi || ''}
                  onChange={(e) => setFormData({ ...formData, kotaProvinsi: e.target.value })}
                  placeholder="Contoh: Kota Jakarta Pusat, DKI Jakarta"
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Telepon & Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Telepon</label>
                <input
                  id="input-telepon-sekolah"
                  type="text"
                  value={formData.telepon}
                  onChange={(e) => setFormData({ ...formData, telepon: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Email</label>
                <input
                  id="input-email-sekolah"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Pejabat Penandatangan */}
          <div className="pt-3 border-t border-slate-200 space-y-3">
            <h4 className="text-xs font-bold text-emerald-700 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-emerald-600" />
              <span>Pejabat Penandatangan (Laporan & Kwitansi)</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Kepala Sekolah *</label>
                <input
                  id="input-kepala-sekolah"
                  type="text"
                  value={formData.kepalaSekolah}
                  onChange={(e) => setFormData({ ...formData, kepalaSekolah: e.target.value })}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">NIP Kepala Sekolah</label>
                <input
                  id="input-nip-kepala-sekolah"
                  type="text"
                  value={formData.nipKepalaSekolah}
                  onChange={(e) => setFormData({ ...formData, nipKepalaSekolah: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Nama Bendahara Sekolah *</label>
                <input
                  id="input-bendahara-sekolah"
                  type="text"
                  value={formData.bendahara}
                  onChange={(e) => setFormData({ ...formData, bendahara: e.target.value })}
                  required
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">NIP Bendahara Sekolah</label>
                <input
                  id="input-nip-bendahara-sekolah"
                  type="text"
                  value={formData.nipBendahara}
                  onChange={(e) => setFormData({ ...formData, nipBendahara: e.target.value })}
                  className="w-full bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs font-mono text-slate-900 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Backup & AutoSave */}
          {onOpenBackupRestore && (
            <div className="pt-2 border-t border-slate-200">
              <div className="bg-purple-50 border border-purple-200 rounded-xl p-3 flex items-center justify-between gap-3">
                <div className="flex items-center space-x-2.5 min-w-0">
                  <Database className="w-5 h-5 text-purple-700 shrink-0" />
                  <div className="min-w-0">
                    <h5 className="font-bold text-xs text-purple-900 truncate">Cadangan & Ekspor Data</h5>
                    <p className="text-[11px] text-purple-800 truncate">
                      Tersimpan di browser & Firestore cloud.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenBackupRestore();
                  }}
                  className="bg-purple-700 hover:bg-purple-800 text-white font-bold px-3 py-1.5 rounded-lg text-xs shadow-2xs transition-all cursor-pointer whitespace-nowrap shrink-0"
                >
                  Backup / Restore
                </button>
              </div>
            </div>
          )}

        </form>

        {/* Sticky Footer */}
        <div className="bg-slate-50 px-5 sm:px-6 py-3.5 border-t border-slate-200 flex items-center justify-end space-x-3 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
          >
            Batal
          </button>
          <button
            id="btn-save-settings"
            type="submit"
            form="form-settings-sekolah"
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-lg text-xs flex items-center gap-1.5 shadow transition-all cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Simpan Profil</span>
          </button>
        </div>

      </div>
    </div>
  );
};

