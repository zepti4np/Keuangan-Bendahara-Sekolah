export type TransactionType = 'Saldo Awal' | 'Pemasukan' | 'Pengeluaran' | 'Mutasi Kas';

export interface Transaction {
  id: string;
  tanggal: string; // YYYY-MM-DD
  jenis: TransactionType;
  kategori: string;
  uraian: string;
  pemasukan: number;
  pengeluaran: number;
  pihak?: string; // Sudah Terima Dari / Dibayarkan Kepada
  nomorBukti?: string; // e.g., BKM/2026/07/001 or BKK/2026/07/001
  metodePembayaran?: 'Tunai / Kas' | 'Transfer Bank' | 'Cek / Giro';
  catatan?: string;
  isRealDaily?: boolean;
  syncedToDashboard?: boolean;
  buktiNotaUrl?: string; // Data URL dari foto/PDF bukti fisik nota/faktur/kwitansi BKK/BKM
  buktiNotaName?: string; // Nama berkas bukti e.g. "nota_pembelian_spidol.jpg"
  createdAt: string;
}

export interface SchoolProfile {
  namaSekolah: string;
  alamat: string;
  kota: string; // Kota / Kabupaten untuk cetak laporan & kwitansi
  kotaProvinsi: string;
  telepon: string;
  email: string;
  kepalaSekolah: string;
  nipKepalaSekolah: string;
  bendahara: string;
  nipBendahara: string;
  logoUrl?: string;
  logoYayasanUrl?: string;
}

export interface CategoryData {
  'Saldo Awal': string[];
  'Pemasukan': string[];
  'Pengeluaran': string[];
  'Mutasi Kas': string[];
}

export interface CategorySummary {
  kategori: string;
  total: number;
  count: number;
}

export interface MonthlyReportData {
  period: string; // YYYY-MM
  monthName: string;
  saldoAwal: CategorySummary[];
  pemasukan: CategorySummary[];
  pengeluaran: CategorySummary[];
  mutasi: CategorySummary[];
  totalSaldoAwal: number;
  totalPemasukan: number;
  totalPengeluaran: number;
  saldoAkhir: number;
}

export interface Student {
  id: string;
  nisn: string;
  nama: string;
  kelas: string;
  nominalSppBulanan: number; // nominal SPP bulanan khusus siswa
  nominalTagihanTahunan: number; // nominal tagihan tahunan khusus siswa
  keterangan?: string;
}

export interface SppPayment {
  id: string;
  studentId: string;
  year: number; // e.g. 2026
  month: number; // 1 to 12
  nominalDibayar: number;
  tanggalBayar: string; // YYYY-MM-DD
  metodePembayaran?: 'Tunai / Kas' | 'Transfer Bank' | 'Cek / Giro';
  catatan?: string;
}

export interface AnnualFeePayment {
  id: string;
  studentId: string;
  year: number; // e.g. 2026
  namaTagihan: string; // e.g. "Uang Gedung / Daftar Ulang"
  nominalDibayar: number;
  tanggalBayar: string; // YYYY-MM-DD
  metodePembayaran?: 'Tunai / Kas' | 'Transfer Bank' | 'Cek / Giro';
  catatan?: string;
}
