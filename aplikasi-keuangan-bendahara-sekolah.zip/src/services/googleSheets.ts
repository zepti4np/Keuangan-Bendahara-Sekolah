import { Transaction } from '../types';

export const DEFAULT_SPREADSHEET_ID = '12qSF8NamDe5KJg4aJUFLXn6dA742V0--dqItLaYv8m0';

export interface SheetInfo {
  title: string;
  sheetName: string;
}

/**
 * Test spreadsheet connection and get details
 */
export async function getSpreadsheetDetails(
  accessToken: string,
  spreadsheetId: string = DEFAULT_SPREADSHEET_ID
): Promise<SheetInfo> {
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}`,
    {
      headers: { Authorization: `Bearer ${accessToken}` }
    }
  );

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Gagal mengakses Spreadsheet (${response.status})`);
  }

  const data = await response.json();
  const title = data.properties?.title || 'Spreadsheet Kas';
  const sheetName = data.sheets?.[0]?.properties?.title || 'Sheet1';

  return { title, sheetName };
}

/**
 * Format a Transaction object into a row array for Google Sheets
 */
export function formatTransactionRow(t: Transaction): (string | number)[] {
  return [
    t.tanggal || '',
    t.jenis || '',
    t.kategori || '',
    t.uraian || '',
    t.pemasukan || 0,
    t.pengeluaran || 0,
    t.pihak || '',
    t.nomorBukti || '',
    t.metodePembayaran || 'Tunai / Kas',
    t.catatan || '',
    t.id || ''
  ];
}

/**
 * Header row for the Google Sheet
 */
export const SHEET_HEADERS = [
  'Tanggal',
  'Jenis Transaksi',
  'Kategori',
  'Uraian',
  'Pemasukan (Rp)',
  'Pengeluaran (Rp)',
  'Terima/Bayar Kepada',
  'Nomor Bukti',
  'Metode Pembayaran',
  'Catatan',
  'ID Transaksi'
];

/**
 * Append a single transaction to Google Sheets
 */
export async function appendTransactionToSheet(
  accessToken: string,
  transaction: Transaction,
  spreadsheetId: string = DEFAULT_SPREADSHEET_ID,
  sheetName: string = 'Sheet1'
): Promise<void> {
  const rowData = formatTransactionRow(transaction);

  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetName)}!A:K:append?valueInputOption=USER_ENTERED`;

  const response = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      values: [rowData]
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Gagal menambahkan data ke Spreadsheet (${response.status})`);
  }
}

/**
 * Export/Sync all transactions to Google Sheets (Header + Rows)
 */
export async function syncAllTransactionsToSheet(
  accessToken: string,
  transactions: Transaction[],
  spreadsheetId: string = DEFAULT_SPREADSHEET_ID,
  sheetName: string = 'Sheet1'
): Promise<{ count: number; title: string }> {
  // 1. Get sheet info
  const info = await getSpreadsheetDetails(accessToken, spreadsheetId);
  const targetSheet = info.sheetName || sheetName;

  // 2. Prepare all values: Header + Transaction Rows
  const values = [
    SHEET_HEADERS,
    ...transactions.map(formatTransactionRow)
  ];

  // 3. Update range A1:K{values.length}
  const range = `${encodeURIComponent(targetSheet)}!A1:K${values.length}`;
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}?valueInputOption=USER_ENTERED`;

  const response = await fetch(url, {
    method: 'PUT',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      range,
      majorDimension: 'ROWS',
      values
    })
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error?.message || `Gagal sinkronisasi data ke Spreadsheet (${response.status})`);
  }

  return { count: transactions.length, title: info.title };
}
