import { initializeApp, getApps } from 'firebase/app';
import { 
  getFirestore, 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  onSnapshot, 
  writeBatch
} from 'firebase/firestore';
import { Transaction, SchoolProfile, CategoryData, Student, SppPayment, AnnualFeePayment } from '../types';
import firebaseConfig from '../../firebase-applet-config.json';

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// Initialize Firestore targeting the applet database ID if present
export const db = firebaseConfig.firestoreDatabaseId 
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

const COLLECTION_TRANSACTIONS = 'transactions';
const COLLECTION_SCHOOL = 'school_profile';
const COLLECTION_CATEGORIES = 'categories';
const COLLECTION_STUDENTS = 'students';
const COLLECTION_SPP_PAYMENTS = 'spp_payments';
const COLLECTION_ANNUAL_PAYMENTS = 'annual_payments';

/**
 * Subscribe to real-time transaction updates from Firestore
 */
export const subscribeTransactions = (
  userId: string,
  onUpdate: (transactions: Transaction[]) => void,
  onError?: (err: any) => void
) => {
  const colRef = collection(db, `users_data/${userId}/${COLLECTION_TRANSACTIONS}`);
  return onSnapshot(
    colRef,
    (snapshot) => {
      const txs: Transaction[] = [];
      snapshot.forEach((docSnap) => {
        txs.push(docSnap.data() as Transaction);
      });
      // Sort newest first
      txs.sort((a, b) => (b.tanggal || '').localeCompare(a.tanggal || ''));
      onUpdate(txs);
    },
    (err) => {
      console.error('Error fetching transactions from Firestore:', err);
      if (onError) onError(err);
    }
  );
};

/**
 * Save single transaction to Firestore
 */
export const saveTransactionToCloud = async (userId: string, transaction: Transaction) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_TRANSACTIONS}`, transaction.id);
  await setDoc(docRef, transaction, { merge: true });
};

/**
 * Delete transaction from Firestore
 */
export const deleteTransactionFromCloud = async (userId: string, transactionId: string) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_TRANSACTIONS}`, transactionId);
  await deleteDoc(docRef);
};

/**
 * Bulk save transactions (e.g. after Excel import or backup restore)
 */
export const bulkSaveTransactionsToCloud = async (
  userId: string, 
  transactions: Transaction[], 
  overwrite: boolean = false
) => {
  const chunkSize = 400;
  for (let i = 0; i < transactions.length; i += chunkSize) {
    const chunk = transactions.slice(i, i + chunkSize);
    const batch = writeBatch(db);
    chunk.forEach(t => {
      const docRef = doc(db, `users_data/${userId}/${COLLECTION_TRANSACTIONS}`, t.id);
      batch.set(docRef, t, { merge: !overwrite });
    });
    await batch.commit();
  }
};

/**
 * Subscribe to School Profile
 */
export const subscribeSchoolProfile = (
  userId: string,
  onUpdate: (profile: SchoolProfile) => void
) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_SCHOOL}`, 'profile');
  return onSnapshot(docRef, (docSnap) => {
    if (docSnap.exists()) {
      onUpdate(docSnap.data() as SchoolProfile);
    }
  });
};

/**
 * Save School Profile
 */
export const saveSchoolProfileToCloud = async (userId: string, profile: SchoolProfile) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_SCHOOL}`, 'profile');
  await setDoc(docRef, profile, { merge: true });
};

/**
 * Subscribe to Categories
 */
export const subscribeCategories = (
  userId: string,
  onUpdate: (categories: CategoryData) => void
) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_CATEGORIES}`, 'data');
  return onSnapshot(docRef, (docSnap) => {
    if (docSnap.exists()) {
      onUpdate(docSnap.data() as CategoryData);
    }
  });
};

/**
 * Save Categories
 */
export const saveCategoriesToCloud = async (userId: string, categories: CategoryData) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_CATEGORIES}`, 'data');
  await setDoc(docRef, categories, { merge: true });
};

/**
 * Subscribe to Students
 */
export const subscribeStudents = (
  userId: string,
  onUpdate: (students: Student[]) => void
) => {
  const colRef = collection(db, `users_data/${userId}/${COLLECTION_STUDENTS}`);
  return onSnapshot(colRef, (snapshot) => {
    const list: Student[] = [];
    snapshot.forEach((docSnap) => {
      list.push(docSnap.data() as Student);
    });
    list.sort((a, b) => a.nama.localeCompare(b.nama, 'id', { sensitivity: 'base' }));
    onUpdate(list);
  });
};

/**
 * Bulk save students
 */
export const bulkSaveStudentsToCloud = async (userId: string, students: Student[]) => {
  const chunkSize = 400;
  for (let i = 0; i < students.length; i += chunkSize) {
    const chunk = students.slice(i, i + chunkSize);
    const batch = writeBatch(db);
    chunk.forEach(s => {
      const docRef = doc(db, `users_data/${userId}/${COLLECTION_STUDENTS}`, s.id);
      batch.set(docRef, s, { merge: true });
    });
    await batch.commit();
  }
};

export const saveStudentToCloud = async (userId: string, student: Student) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_STUDENTS}`, student.id);
  await setDoc(docRef, student, { merge: true });
};

export const deleteStudentFromCloud = async (userId: string, studentId: string) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_STUDENTS}`, studentId);
  await deleteDoc(docRef);
};

/**
 * Subscribe to SPP Payments
 */
export const subscribeSppPayments = (
  userId: string,
  onUpdate: (payments: SppPayment[]) => void
) => {
  const colRef = collection(db, `users_data/${userId}/${COLLECTION_SPP_PAYMENTS}`);
  return onSnapshot(colRef, (snapshot) => {
    const list: SppPayment[] = [];
    snapshot.forEach((docSnap) => {
      list.push(docSnap.data() as SppPayment);
    });
    onUpdate(list);
  });
};

/**
 * Bulk save SPP Payments
 */
export const bulkSaveSppPaymentsToCloud = async (userId: string, payments: SppPayment[]) => {
  const chunkSize = 400;
  for (let i = 0; i < payments.length; i += chunkSize) {
    const chunk = payments.slice(i, i + chunkSize);
    const batch = writeBatch(db);
    chunk.forEach(p => {
      const docRef = doc(db, `users_data/${userId}/${COLLECTION_SPP_PAYMENTS}`, p.id);
      batch.set(docRef, p, { merge: true });
    });
    await batch.commit();
  }
};

export const saveSppPaymentToCloud = async (userId: string, payment: SppPayment) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_SPP_PAYMENTS}`, payment.id);
  await setDoc(docRef, payment, { merge: true });
};

export const deleteSppPaymentFromCloud = async (userId: string, paymentId: string) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_SPP_PAYMENTS}`, paymentId);
  await deleteDoc(docRef);
};

/**
 * Subscribe to Annual Fee Payments
 */
export const subscribeAnnualPayments = (
  userId: string,
  onUpdate: (payments: AnnualFeePayment[]) => void
) => {
  const colRef = collection(db, `users_data/${userId}/${COLLECTION_ANNUAL_PAYMENTS}`);
  return onSnapshot(colRef, (snapshot) => {
    const list: AnnualFeePayment[] = [];
    snapshot.forEach((docSnap) => {
      list.push(docSnap.data() as AnnualFeePayment);
    });
    onUpdate(list);
  });
};

/**
 * Bulk save Annual Fee Payments
 */
export const bulkSaveAnnualPaymentsToCloud = async (userId: string, payments: AnnualFeePayment[]) => {
  const chunkSize = 400;
  for (let i = 0; i < payments.length; i += chunkSize) {
    const chunk = payments.slice(i, i + chunkSize);
    const batch = writeBatch(db);
    chunk.forEach(p => {
      const docRef = doc(db, `users_data/${userId}/${COLLECTION_ANNUAL_PAYMENTS}`, p.id);
      batch.set(docRef, p, { merge: true });
    });
    await batch.commit();
  }
};

export const saveAnnualPaymentToCloud = async (userId: string, payment: AnnualFeePayment) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_ANNUAL_PAYMENTS}`, payment.id);
  await setDoc(docRef, payment, { merge: true });
};

export const deleteAnnualPaymentFromCloud = async (userId: string, paymentId: string) => {
  const docRef = doc(db, `users_data/${userId}/${COLLECTION_ANNUAL_PAYMENTS}`, paymentId);
  await deleteDoc(docRef);
};

